# GuruKelas Android — MVP v0.2 Presensi

Aplikasi Android native untuk satu guru, dengan data utama tersimpan lokal menggunakan Room/SQLite.

## Format impor Excel
File `.xlsx`, sheet pertama, header:
`NIS | Nama | Kelas | Jenis Kelamin`

Contoh:
- `001 | Andi Saputra | XI TJKT 1 | Laki-laki`
- `002 | Siti Aminah | XI TJKT 1 | Perempuan`

Kolom dikenali berdasarkan header. Jika header tidak dikenali, urutan A-D digunakan. Jenis kelamin menerima nilai `L`, `Laki-laki`, `Pria`, `P`, `Perempuan`, atau `Wanita`. Baris tidak lengkap dan NIS duplikat akan dilewati. Impor ulang tidak memperbarui data siswa yang sudah ada; siswa dengan NIS yang sama dilewati agar tidak berubah diam-diam.

**Penting:** format NIS sebagai teks di Excel agar angka nol di awal tetap ada.

## Membuka dan membangun APK
1. Ekstrak ZIP.
2. Buka folder `GuruKelasAndroid` di Android Studio.
3. Gunakan JDK 17 dan Android SDK Platform 35.
4. Tunggu Gradle Sync dan jalankan di emulator/perangkat.
5. Pilih Build > Build APK(s). APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Status fitur
- Database lokal untuk kelas, siswa (termasuk jenis kelamin), presensi, agenda: tersedia.
- Tambah/tampilkan kelas dan siswa: tersedia.
- Impor Excel `.xlsx`: ditambahkan pada versi starter ini, perlu diuji dengan file nyata.
- Agenda mengajar: tersedia.
- Presensi per siswa: tersedia; pilih kelas dan tanggal, isi Hadir/Sakit/Izin/Alpa, lalu simpan. Status pada tanggal yang sama dapat diedit setelah memuat ulang presensi.
- Laporan presensi harian PDF: tersedia untuk tanggal yang dipilih, termasuk daftar siswa yang memiliki catatan presensi dan ringkasan status.
- Rekap presensi bulanan PDF: tersedia per tanggal dalam bulan yang dipilih.
- Laporan agenda PDF: tersedia tanpa kolom tanda tangan guru sesuai permintaan.
- Backup/restore dan pengujian build/perangkat: belum dilakukan.

**Status prototipe:** source code ini belum diverifikasi melalui build Android Studio atau diuji pada HP. Sebelum digunakan untuk data penting, lakukan build dan uji alur impor, presensi, serta PDF. Database masih memakai destructive migration untuk tahap pengembangan; perubahan skema di versi mendatang dapat menghapus data lokal. Buat cadangan sebelum memasang versi yang mengubah database.
