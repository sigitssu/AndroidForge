package id.guru.agenda.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------- Data contoh (statis) ----------------
private class AgendaItem(
    val kelas: String, val jam: String, val topik: String,
    val hadir: Int, val sakit: Int, val izin: Int, val alpa: Int
)

private val agendaDummy = listOf(
    AgendaItem("XII TKJ 1", "07:30 - 09:00", "Fungsi Patch Cord Fiber Optic", 34, 1, 0, 0),
    AgendaItem("XI RPL 2", "09:15 - 11:30", "Fundamental Kotlin & Material", 32, 0, 2, 1)
)

// ---------------- Tab Agenda ----------------
@Composable
fun AgendaTab() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(agendaDummy) { AgendaCard(it) }
    }
}

@Composable
private fun AgendaCard(a: AgendaItem) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(a.kelas, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MdOnSurface)
                Surface(shape = RoundedCornerShape(8.dp), color = MdSecondaryContainer) {
                    Text(
                        a.jam, Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MdOnSurface
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Topik Pembelajaran:", fontSize = 12.sp, color = Gray500)
            Spacer(Modifier.height(4.dp))
            Text(a.topik, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Gray800)
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = MdSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat(a.hadir, "Hadir", MdPrimary)
                Stat(a.sakit, "Sakit", MdError)
                Stat(a.izin, "Izin", MdTertiary)
                Stat(a.alpa, "Alpa", AlpaRed)
            }
        }
    }
}

@Composable
private fun Stat(value: Int, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Gray600)
    }
}

// ---------------- Tab Laporan ----------------
@Composable
fun LaporanTab() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Pertemuan", "24", Modifier.weight(1f))
            StatCard("Rata-rata hadir", "94%", Modifier.weight(1f))
        }
        Text("Filter laporan", fontWeight = FontWeight.SemiBold, color = Gray800)
        FilterField("Kelas", "XII TKJ 1")
        FilterField("Mata Pelajaran", "Jaringan Dasar")
        FilterField("Periode", "Semester Ganjil 2026/2027")
        Spacer(Modifier.weight(1f))
        Button(onClick = { }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Outlined.PictureAsPdf, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Buat Laporan PDF")
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
            Text(label, fontSize = 12.sp, color = Gray600)
        }
    }
}

@Composable
private fun FilterField(label: String, value: String) {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 11.sp, color = Gray500)
                Text(value, fontSize = 15.sp, color = Gray800)
            }
            Icon(Icons.Outlined.ArrowDropDown, contentDescription = null, tint = Gray500)
        }
    }
}

// ---------------- Layar detail (Pengaturan & menu drawer) ----------------
private class ListRow(val title: String, val sub: String, val icon: ImageVector)

private fun rowsFor(title: String): List<ListRow> = when (title) {
    "Tahun Ajaran" -> listOf(
        ListRow("2026/2027 - Ganjil", "Aktif", Icons.Outlined.DateRange),
        ListRow("2025/2026 - Genap", "Selesai", Icons.Outlined.DateRange),
        ListRow("2025/2026 - Ganjil", "Selesai", Icons.Outlined.DateRange)
    )
    "Daftar Kelas" -> listOf(
        ListRow("XII TKJ 1", "35 siswa", Icons.Outlined.Class),
        ListRow("XI RPL 2", "35 siswa", Icons.Outlined.Class),
        ListRow("X TKJ 2", "34 siswa", Icons.Outlined.Class)
    )
    "Daftar Siswa" -> listOf(
        ListRow("Ahmad Fauzi", "NIS 2026001", Icons.Outlined.Person),
        ListRow("Bella Safitri", "NIS 2026002", Icons.Outlined.Person),
        ListRow("Citra Lestari", "NIS 2026003", Icons.Outlined.Person),
        ListRow("Dimas Prakoso", "NIS 2026004", Icons.Outlined.Person)
    )
    "Daftar Mata Pelajaran" -> listOf(
        ListRow("Jaringan Dasar", "2 kelas", Icons.AutoMirrored.Outlined.MenuBook),
        ListRow("Pemrograman Mobile", "1 kelas", Icons.AutoMirrored.Outlined.MenuBook)
    )
    else -> emptyList()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(title: String, onBack: () -> Unit) {
    Scaffold(
        containerColor = AppBg,
        topBar = {
            TopAppBar(
                title = { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Gray800) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = {
            when (title) {
                "Pengaturan", "Backup & Restore" -> Unit
                "Daftar Siswa" -> ExtendedFloatingActionButton(onClick = { }) {
                    Icon(Icons.Outlined.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Impor Excel")
                }
                else -> FloatingActionButton(
                    onClick = { },
                    shape = RoundedCornerShape(16.dp),
                    containerColor = MdPrimary,
                    contentColor = Color.White
                ) { Icon(Icons.Filled.Add, contentDescription = "Tambah") }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            when (title) {
                "Pengaturan" -> SettingsCard(
                    listOf(
                        Icons.Outlined.Palette to "Tema Aplikasi",
                        Icons.Outlined.Notifications to "Notifikasi",
                        Icons.Outlined.Info to "Tentang Aplikasi"
                    )
                )
                "Backup & Restore" -> SettingsCard(
                    listOf(Icons.Outlined.Backup to "Cadangkan data", Icons.Outlined.Restore to "Pulihkan data")
                )
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(rowsFor(title)) { r ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            ListItem(
                                headlineContent = { Text(r.title, fontWeight = FontWeight.Medium) },
                                supportingContent = { Text(r.sub) },
                                leadingContent = { Icon(r.icon, contentDescription = null, tint = MdPrimary) },
                                trailingContent = { Icon(Icons.Outlined.MoreVert, contentDescription = null, tint = Gray500) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(rows: List<Pair<ImageVector, String>>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            rows.forEachIndexed { index, row ->
                Row(
                    Modifier.fillMaxWidth().clickable { }.padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(row.first, contentDescription = null, tint = Gray600)
                    Spacer(Modifier.width(16.dp))
                    Text(row.second, Modifier.weight(1f), fontWeight = FontWeight.Medium, color = Gray800)
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Gray500)
                }
                if (index < rows.lastIndex) HorizontalDivider(color = Gray100)
            }
        }
    }
}
