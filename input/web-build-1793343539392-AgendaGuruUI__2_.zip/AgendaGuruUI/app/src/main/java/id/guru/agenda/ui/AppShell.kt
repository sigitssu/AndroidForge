package id.guru.agenda.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment as AssignmentFilled
import androidx.compose.material.icons.automirrored.outlined.Assignment as AssignmentOutlined
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday as CalendarFilled
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private class NavItem(val label: String, val on: ImageVector, val off: ImageVector)

private val navItems = listOf(
    NavItem("Agenda", Icons.Filled.CalendarFilled, Icons.Outlined.CalendarToday),
    NavItem("Laporan", Icons.AutoMirrored.Filled.AssignmentFilled, Icons.AutoMirrored.Outlined.AssignmentOutlined),
    NavItem("Pengaturan", Icons.Outlined.Settings, Icons.Outlined.Settings)
)

private val drawerItems: List<Pair<String, ImageVector>> = listOf(
    "Tahun Ajaran" to Icons.Outlined.DateRange,
    "Daftar Kelas" to Icons.Outlined.Class,
    "Daftar Siswa" to Icons.Outlined.Group,
    "Daftar Mata Pelajaran" to Icons.AutoMirrored.Outlined.MenuBook,
    "Backup & Restore" to Icons.Outlined.CloudSync
)

@Composable
fun AgendaGuruApp() {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detailVisible by rememberSaveable { mutableStateOf(false) }
    var detailTitle by rememberSaveable { mutableStateOf("") }

    fun openDetail(title: String) {
        detailTitle = title
        detailVisible = true
    }

    Box(Modifier.fillMaxSize()) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(300.dp),
                    drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                    drawerContainerColor = MdSurface
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(MdPrimaryContainer)
                            .padding(24.dp)
                    ) {
                        Text("Menu Utama", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                        Text("SMK Negeri 1", fontSize = 14.sp, color = MdOnPrimaryContainer.copy(alpha = 0.8f))
                    }
                    drawerItems.forEachIndexed { index, item ->
                        if (index == drawerItems.lastIndex) {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gray200)
                        }
                        NavigationDrawerItem(
                            label = { Text(item.first) },
                            icon = { Icon(item.second, contentDescription = null, tint = Gray600) },
                            selected = false,
                            shape = RectangleShape,
                            onClick = {
                                scope.launch { drawerState.close() }
                                openDetail(item.first)
                            }
                        )
                    }
                }
            }
        ) {
            MainScaffold(
                tab = tab,
                onTab = { tab = it },
                onMenu = { scope.launch { drawerState.open() } },
                onSettings = { openDetail("Pengaturan") }
            )
        }
        AnimatedVisibility(
            visible = detailVisible,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it }
        ) {
            DetailScreen(detailTitle) { detailVisible = false }
        }
    }
    BackHandler(enabled = detailVisible) { detailVisible = false }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(tab: Int, onTab: (Int) -> Unit, onMenu: () -> Unit, onSettings: () -> Unit) {
    var profileMenu by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = AppBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (tab == 0) "Agenda Hari Ini" else "Laporan",
                        fontSize = 20.sp, fontWeight = FontWeight.Medium
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, contentDescription = "Menu") }
                },
                actions = {
                    Box(Modifier.padding(end = 16.dp)) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .border(2.dp, MdPrimary, CircleShape)
                                .clip(CircleShape)
                                .background(Color(0xFFD0BCFF))
                                .clickable { profileMenu = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("PB", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MdOnPrimaryContainer)
                        }
                        DropdownMenu(
                            expanded = profileMenu,
                            onDismissRequest = { profileMenu = false },
                            modifier = Modifier.width(128.dp)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Ubah") },
                                leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                                onClick = { profileMenu = false }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MdPrimaryContainer,
                    titleContentColor = MdOnPrimaryContainer,
                    navigationIconContentColor = MdOnPrimaryContainer,
                    actionIconContentColor = MdOnPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(
                    onClick = { },
                    shape = RoundedCornerShape(16.dp),
                    containerColor = MdPrimary,
                    contentColor = Color.White
                ) { Icon(Icons.Filled.Add, contentDescription = "Tambah agenda") }
            }
        },
        bottomBar = {
            Column {
                HorizontalDivider(color = Gray200)
                NavigationBar(containerColor = MdSurface) {
                    navItems.forEachIndexed { i, item ->
                        val selected = i < 2 && tab == i
                        NavigationBarItem(
                            selected = selected,
                            onClick = { if (i == 2) onSettings() else onTab(i) },
                            icon = { Icon(if (selected) item.on else item.off, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MdOnSurface,
                                selectedTextColor = MdOnSurface,
                                indicatorColor = MdSecondaryContainer,
                                unselectedIconColor = Gray600,
                                unselectedTextColor = Gray600
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (tab == 0) AgendaTab() else LaporanTab()
        }
    }
}
