package id.guru.agenda.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

val LocaleId: Locale = Locale.forLanguageTag("id-ID")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageScaffold(
    title: String,
    pop: () -> Unit,
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = AppBg,
        topBar = {
            TopAppBar(
                title = { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Gray800) },
                navigationIcon = {
                    IconButton(onClick = pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        floatingActionButton = fab,
        content = content
    )
}

@Composable
fun FormScaffold(title: String, pop: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    PageScaffold(title, pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            content()
            Spacer(Modifier.height(8.dp))
            Button(onClick = pop, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Simpan") }
        }
    }
}

@Composable
fun AddFab(onClick: () -> Unit) {
    FloatingActionButton(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        containerColor = MdPrimary,
        contentColor = Color.White
    ) { Icon(Icons.Filled.Add, contentDescription = "Tambah") }
}

/** Dropdown bergaya outlined (label mengambang, panah, menu selebar kolom, item terpilih disorot). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterField(
    label: String,
    value: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var open by remember { mutableStateOf(false) }
    if (!enabled) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            enabled = false,
            singleLine = true,
            label = { Text(label) },
            shape = RoundedCornerShape(12.dp),
            trailingIcon = { Icon(Icons.Outlined.ArrowDropDown, contentDescription = null) },
            colors = OutlinedTextFieldDefaults.colors(
                disabledTextColor = Gray500,
                disabledBorderColor = Gray200,
                disabledLabelColor = Gray500,
                disabledTrailingIconColor = Gray500
            ),
            modifier = modifier.fillMaxWidth()
        )
    } else {
        ExposedDropdownMenuBox(
            expanded = open,
            onExpandedChange = { open = it },
            modifier = modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = {},
                readOnly = true,
                singleLine = true,
                label = { Text(label) },
                shape = RoundedCornerShape(12.dp),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = open) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { opt ->
                    DropdownMenuItem(
                        text = { Text(opt) },
                        onClick = { onSelect(opt); open = false },
                        modifier = Modifier.background(
                            if (opt == value) MdSurfaceVariant.copy(alpha = 0.5f) else Color.Transparent
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AppTextField(label: String, value: String, onChange: (String) -> Unit, number: Boolean = false, multiline: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = !multiline,
        minLines = if (multiline) 3 else 1,
        shape = RoundedCornerShape(12.dp),
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text),
        modifier = Modifier.fillMaxWidth()
    )
}

/** Segmented control (pilihan bergaya switch). */
@Composable
fun SegmentedControl(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    selectedColors: Map<String, Color> = emptyMap()
) {
    Row(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(MdSurfaceVariant.copy(alpha = 0.6f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { opt ->
            val isSel = opt == selected
            val bg by animateColorAsState(
                targetValue = if (isSel) (selectedColors[opt] ?: MdPrimary) else Color.Transparent,
                label = "segmen"
            )
            Box(
                Modifier.weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(bg)
                    .clickable { onSelect(opt) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    opt, fontSize = 13.sp,
                    fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (isSel) Color.White else Gray600
                )
            }
        }
    }
}

@Composable
fun SegmentedField(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column {
        Text(label, fontSize = 12.sp, color = Gray500)
        Spacer(Modifier.height(6.dp))
        SegmentedControl(options, selected, onSelect)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, value: String, onChange: (String) -> Unit, pattern: String = "d MMMM yyyy") {
    var show by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text(label) },
            shape = RoundedCornerShape(12.dp),
            trailingIcon = { Icon(Icons.Outlined.CalendarMonth, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )
        Box(Modifier.matchParentSize().clickable { show = true })
    }
    if (show) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let {
                        onChange(
                            Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                                .format(DateTimeFormatter.ofPattern(pattern, LocaleId))
                        )
                    }
                    show = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Batal") } }
        ) { DatePicker(state = state) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    var show by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text(label) },
            shape = RoundedCornerShape(12.dp),
            trailingIcon = { Icon(Icons.Outlined.Schedule, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )
        Box(Modifier.matchParentSize().clickable { show = true })
    }
    if (show) {
        val parts = value.split(":")
        val state = rememberTimePickerState(
            initialHour = parts.getOrNull(0)?.toIntOrNull() ?: 7,
            initialMinute = parts.getOrNull(1)?.toIntOrNull() ?: 0,
            is24Hour = true
        )
        Dialog(onDismissRequest = { show = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MdSurface,
                tonalElevation = 6.dp,
                modifier = Modifier.width(IntrinsicSize.Min)
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text("Pilih waktu", fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(bottom = 20.dp))
                    TimePicker(state = state)
                    Row(Modifier.fillMaxWidth()) {
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { show = false }) { Text("Batal") }
                        TextButton(onClick = {
                            onChange("%02d:%02d".format(state.hour, state.minute))
                            show = false
                        }) { Text("OK") }
                    }
                }
            }
        }
    }
}

class SheetAction(val icon: ImageVector, val label: String, val onClick: () -> Unit)

/** Menu aksi yang naik dari bawah (seperti YouTube). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionSheet(onDismiss: () -> Unit, actions: List<SheetAction>) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MdSurface) {
        actions.forEach { a ->
            Row(
                Modifier.fillMaxWidth().clickable(onClick = a.onClick).padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(a.icon, contentDescription = null, tint = Gray600)
                Spacer(Modifier.width(24.dp))
                Text(a.label, fontSize = 16.sp, color = Gray800)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

class SettingItem(val icon: ImageVector, val label: String, val onClick: () -> Unit)

@Composable
fun SettingsCard(items: List<SettingItem>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            items.forEachIndexed { index, item ->
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = item.onClick).padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(item.icon, contentDescription = null, tint = Gray600)
                    Spacer(Modifier.width(16.dp))
                    Text(item.label, Modifier.weight(1f), fontWeight = FontWeight.Medium, color = Gray800)
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Gray500)
                }
                if (index < items.lastIndex) HorizontalDivider(color = Gray100)
            }
        }
    }
}
