package id.guru.agenda.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private data class NavItem(val label: String, val on: ImageVector, val off: ImageVector)
private val navItems = listOf(
    NavItem("Agenda", Icons.Filled.CalendarToday, Icons.Outlined.CalendarToday),
    NavItem("Laporan", Icons.Filled.Analytics, Icons.Outlined.Analytics),
    NavItem("Pengaturan", Icons.Filled.Settings, Icons.Outlined.Settings)
)
private val drawerItems = listOf(
    "Tahun Ajaran" to Icons.Outlined.CalendarMonth,
    "Daftar Kelas" to Icons.Outlined.MeetingRoom,
    "Daftar Siswa" to Icons.Outlined.Group,
    "Daftar Mata Pelajaran" to Icons.Outlined.MenuBook,
    "Backup & Restore" to Icons.Outlined.Backup
)

@Composable
fun AgendaGuruApp() {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detailVisible by rememberSaveable { mutableStateOf(false) }
    var detailTitle by rememberSaveable { mutableStateOf("") }
    fun open(t: String) { detailTitle = t; detailVisible = true }

    Box(Modifier.fillMaxSize()) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = androidx.compose.ui.graphics.Color.White) {
                    Column(Modifier.fillMaxWidth().background(Indigo50).padding(24.dp)) {
                        Text("AgendaGuru", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Indigo700)
                        Text("Menu Utama", fontSize = 14.sp, color = Slate500)
                    }
                    Spacer(Modifier.height(8.dp))
                    drawerItems.forEachIndexed { i, (label, icon) ->
                        if (i == drawerItems.lastIndex) HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                        NavigationDrawerItem(
                            label = { Text(label, fontWeight = FontWeight.Medium) },
                            icon = { Icon(icon, null) },
                            selected = false,
                            onClick = { scope.launch { drawerState.close() }; open(label) },
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                }
            }
        ) {
            MainScaffold(tab, { tab = it }, onMenu = { scope.launch { drawerState.open() } }, onSettings = { open("Pengaturan") })
        }
        AnimatedVisibility(detailVisible, enter = slideInHorizontally { it }, exit = slideOutHorizontally { it }) {
            DetailScreen(detailTitle) { detailVisible = false }
        }
    }
    BackHandler(detailVisible) { detailVisible = false }
    BackHandler(drawerState.isOpen) { scope.launch { drawerState.close() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(tab: Int, onTab: (Int) -> Unit, onMenu: () -> Unit, onSettings: () -> Unit) {
    var profileMenu by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (tab == 0) "Agenda Hari Ini" else "Laporan", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = { IconButton(onMenu) { Icon(Icons.Default.Menu, "Menu") } },
                actions = {
                    Box {
                        Box(
                            Modifier.padding(end = 12.dp).size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton({ profileMenu = true }) { Text("PB", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        }
                        DropdownMenu(profileMenu, { profileMenu = false }) {
                            DropdownMenuItem({ Text("Ubah Profil") }, { profileMenu = false },
                                leadingIcon = { Icon(Icons.Outlined.Edit, null) })
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Indigo100, titleContentColor = Indigo900, navigationIconContentColor = Indigo900)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = androidx.compose.ui.graphics.Color.White) {
                navItems.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i && i < 2,
                        onClick = { if (i == 2) onSettings() else onTab(i) },
                        icon = { Icon(if (tab == i && i < 2) n.on else n.off, n.label) },
                        label = { Text(n.label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) { if (tab == 0) AgendaTab() else LaporanTab() }
    }
}
