package id.guru.agenda.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Grade
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

private class RowData(
    val title: String,
    val sub: String,
    val icon: ImageVector,
    val editRoute: Route,
    val penilaianRoute: Route? = null
)

private fun addRoute(title: String): Route? = when (title) {
    "Tahun Ajaran" -> Route.TahunForm(null)
    "Daftar Kelas" -> Route.KelasForm(null)
    "Daftar Mata Pelajaran" -> Route.MapelForm(null)
    "Daftar Nilai" -> Route.NilaiForm(null)
    else -> null
}

@Composable
fun MasterListScreen(title: String, push: (Route) -> Unit, pop: () -> Unit) {
    var sheetRow by remember { mutableStateOf<RowData?>(null) }
    var kelasSiswa by remember { mutableStateOf(kelasList.first().nama) }
    var kelasNilai by remember { mutableStateOf(kelasList.first().nama) }
    var mapelNilai by remember {
        mutableStateOf(mapelList.firstOrNull { it.kelas == kelasList.first().nama }?.nama ?: "")
    }
    val mapelOpsiNilai = mapelList.filter { it.kelas == kelasNilai }.map { it.nama }

    val rows: List<RowData> = when (title) {
        "Tahun Ajaran" -> tahunAjaranList.map {
            RowData(it.label, it.awal + " - " + it.akhir + (if (it.aktif) "  •  Aktif" else ""), Icons.Outlined.DateRange, Route.TahunForm(it))
        }
        "Daftar Kelas" -> kelasList.map {
            RowData(it.nama, "${it.jumlah} siswa", Icons.Outlined.Class, Route.KelasForm(it))
        }
        "Daftar Siswa" -> siswaList.filter { it.kelas == kelasSiswa }.map {
            RowData(it.nama, "NIS ${it.nis}  •  ${it.jk}", Icons.Outlined.Person, Route.SiswaForm(it))
        }
        "Daftar Mata Pelajaran" -> mapelList.map {
            RowData(it.nama, it.kelas, Icons.AutoMirrored.Outlined.MenuBook, Route.MapelForm(it))
        }
        "Daftar Nilai" -> nilaiList.filter { it.kelas == kelasNilai && it.mapel == mapelNilai }.map {
            val jumlah = kelasList.firstOrNull { k -> k.nama == it.kelas }?.jumlah ?: 0
            RowData(it.nama, "$jumlah siswa", Icons.Outlined.Grade, Route.NilaiForm(it), Route.Penilaian(it))
        }
        else -> emptyList()
    }

    PageScaffold(
        title = title,
        pop = pop,
        fab = {
            when (title) {
                "Backup & Restore" -> Unit
                "Daftar Siswa" -> ExtendedFloatingActionButton(onClick = { }) {
                    Icon(Icons.Outlined.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Impor Excel")
                }
                else -> AddFab { addRoute(title)?.let(push) }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (title == "Backup & Restore") {
                Column(Modifier.padding(16.dp)) {
                    SettingsCard(
                        listOf(
                            SettingItem(Icons.Outlined.Backup, "Cadangkan data") { },
                            SettingItem(Icons.Outlined.Restore, "Pulihkan data") { }
                        )
                    )
                }
            } else {
                if (title == "Daftar Siswa") {
                    FilterField(
                        "Kelas", kelasSiswa, kelasList.map { it.nama }, { kelasSiswa = it },
                        Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)
                    )
                }
                if (title == "Daftar Nilai") {
                    Column(
                        Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FilterField(
                            "Kelas", kelasNilai, kelasList.map { it.nama },
                            { k ->
                                kelasNilai = k
                                mapelNilai = mapelList.firstOrNull { it.kelas == k }?.nama ?: ""
                            }
                        )
                        FilterField("Mata Pelajaran", mapelNilai, mapelOpsiNilai, { mapelNilai = it })
                    }
                }
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(rows) { r ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            ListItem(
                                headlineContent = { Text(r.title, fontWeight = FontWeight.Medium) },
                                supportingContent = { Text(r.sub) },
                                leadingContent = { Icon(r.icon, contentDescription = null, tint = MdPrimary) },
                                trailingContent = {
                                    IconButton(onClick = { sheetRow = r }) {
                                        Icon(Icons.Outlined.MoreVert, contentDescription = "Opsi", tint = Gray500)
                                    }
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                            )
                        }
                    }
                }
            }
        }
    }

    sheetRow?.let { r ->
        ActionSheet(
            onDismiss = { sheetRow = null },
            actions = buildList {
                add(SheetAction(Icons.Outlined.Edit, "Ubah") { sheetRow = null; push(r.editRoute) })
                r.penilaianRoute?.let { rute ->
                    add(SheetAction(Icons.Outlined.Grade, "Penilaian") { sheetRow = null; push(rute) })
                }
                add(SheetAction(Icons.Outlined.Delete, "Hapus") { sheetRow = null })
            }
        )
    }
}
