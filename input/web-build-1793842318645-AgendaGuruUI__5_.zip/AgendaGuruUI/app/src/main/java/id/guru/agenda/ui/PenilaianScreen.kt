package id.guru.agenda.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

private fun formatNilai(d: Double): String = if (d % 1.0 == 0.0) d.toInt().toString() else "%.1f".format(d)

@Composable
fun PenilaianScreen(n: NilaiItem, pop: () -> Unit) {
    val siswa = siswaList.filter { it.kelas == n.kelas }
    val contoh = listOf("85", "78", "92", "70", "88", "81", "95", "67", "74")
    val nilai = remember {
        mutableStateMapOf<String, String>().apply {
            siswa.forEachIndexed { i, s -> put(s.nis, contoh[i % contoh.size]) }
        }
    }
    val angka = siswa.mapNotNull { nilai[it.nis]?.toDoubleOrNull() }
    val terbesar = angka.maxOrNull()?.let { formatNilai(it) } ?: "-"
    val terkecil = angka.minOrNull()?.let { formatNilai(it) } ?: "-"
    val rataRata = if (angka.isEmpty()) "-" else "%.1f".format(angka.average())

    PageScaffold("Penilaian", pop) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("${n.nama} • ${n.kelas}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                            Text(n.mapel, fontSize = 13.sp, color = Gray600)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                StatText(terbesar, "Terbesar", MdPrimary)
                                StatText(terkecil, "Terkecil", MdError)
                                StatText(rataRata, "Rata-rata", MdTertiary)
                            }
                        }
                    }
                }
                items(siswa) { s ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.nama, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray800)
                                Text("NIS ${s.nis}", fontSize = 12.sp, color = Gray500)
                            }
                            OutlinedTextField(
                                value = nilai[s.nis] ?: "",
                                onValueChange = { v ->
                                    if (v.length <= 5 && v.all { c -> c.isDigit() || c == '.' }) nilai[s.nis] = v
                                },
                                placeholder = { Text("Nilai", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                textStyle = TextStyle(textAlign = TextAlign.Center, fontSize = 16.sp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.width(96.dp)
                            )
                        }
                    }
                }
            }
            Surface(color = Color.White, shadowElevation = 8.dp) {
                Button(
                    onClick = pop,
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
                ) { Text("Simpan") }
            }
        }
    }
}
