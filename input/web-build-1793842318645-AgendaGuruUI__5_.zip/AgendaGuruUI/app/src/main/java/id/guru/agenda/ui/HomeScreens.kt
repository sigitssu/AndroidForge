package id.guru.agenda.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.Grade
import androidx.compose.material.icons.outlined.IosShare
import androidx.compose.material.icons.outlined.HowToReg
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val ListPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)

@Composable
fun AgendaActionSheet(a: AgendaItem, push: (Route) -> Unit, onDismiss: () -> Unit) {
    ActionSheet(
        onDismiss = onDismiss,
        actions = listOf(
            SheetAction(Icons.Outlined.Edit, "Ubah") { onDismiss(); push(Route.AgendaForm(a)) },
            SheetAction(Icons.Outlined.HowToReg, "Presensi Siswa") { onDismiss(); push(Route.Presensi(a)) },
            SheetAction(Icons.Outlined.Delete, "Hapus") { onDismiss() }
        )
    )
}

// ---------------- Beranda ----------------
@Composable
fun BerandaTab(push: (Route) -> Unit) {
    var sheet by remember { mutableStateOf<AgendaItem?>(null) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = ListPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { WaktuCard() }
        item { RekapRow() }
        items(agendaToday) { a -> AgendaCard(a, showMeta = false, onMore = { sheet = a }) }
    }
    sheet?.let { AgendaActionSheet(it, push) { sheet = null } }
}

@Composable
private fun WaktuCard() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }
    val tanggal = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", LocaleId))
    val waktu = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    Box(
        Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(MdPrimary, Indigo500)))
    ) {
        Icon(
            Icons.Outlined.Schedule, contentDescription = null,
            modifier = Modifier.align(Alignment.BottomEnd).offset(x = 8.dp, y = 16.dp).size(100.dp),
            tint = Color.White.copy(alpha = 0.1f)
        )
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.CalendarMonth, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(tanggal, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Indigo100)
                Text(waktu, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
private fun RekapRow() {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.EventAvailable, contentDescription = null, tint = MdOnPrimaryContainer, modifier = Modifier.size(28.dp))
                Spacer(Modifier.height(4.dp))
                Text("${agendaToday.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                Text("KEGIATAN", fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp, color = MdOnPrimaryContainer.copy(alpha = 0.8f))
            }
        }
        Card(
            Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MdSecondaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Timer, contentDescription = null, tint = MdTertiary, modifier = Modifier.size(28.dp))
                Spacer(Modifier.height(4.dp))
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)) { append("3.5") }
                        withStyle(SpanStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium)) { append("J") }
                    },
                    color = Gray800
                )
                Text("DURASI", fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp, color = Gray600)
            }
        }
    }
}

// ---------------- Kartu agenda ----------------
@Composable
fun AgendaCard(a: AgendaItem, showMeta: Boolean, onMore: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(8.dp), color = MdSecondaryContainer) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Schedule, contentDescription = null, tint = MdOnSurface, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(a.jam, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MdOnSurface)
                    }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onMore, modifier = Modifier.size(32.dp).offset(x = 8.dp)) {
                    Icon(Icons.Outlined.MoreVert, contentDescription = "Opsi", tint = Gray500)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(a.kelas, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MdOnSurface)
            if (showMeta) {
                Spacer(Modifier.height(2.dp))
                Text("${a.mapel} • ${a.tanggal}", fontSize = 12.sp, color = Gray500)
            }
            Spacer(Modifier.height(12.dp))
            Text("Topik Pembelajaran:", fontSize = 12.sp, color = Gray500)
            Spacer(Modifier.height(4.dp))
            Text(a.topik, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Gray800)
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = MdSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat(a.hadir, "Hadir", MdPrimary)
                Stat(a.sakit, "Sakit", MdError)
                Stat(a.izin, "Izin", MdTertiary)
                Stat(a.alpa, "Alpa", AlpaRed)
            }
        }
    }
}

@Composable
fun Stat(value: Int, label: String, color: Color) = StatText("$value", label, color)

@Composable
fun StatText(value: String, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Gray600)
    }
}

// ---------------- Tab Agenda ----------------
private const val SEMUA_KELAS = "Semua Kelas"
private const val SEMUA_MAPEL = "Semua Mata Pelajaran"

@Composable
fun AgendaTab(push: (Route) -> Unit) {
    var kelas by remember { mutableStateOf(SEMUA_KELAS) }
    var mapel by remember { mutableStateOf(SEMUA_MAPEL) }
    var sheet by remember { mutableStateOf<AgendaItem?>(null) }
    val hasil = agendaAll.filter {
        (kelas == SEMUA_KELAS || it.kelas == kelas) && (mapel == SEMUA_MAPEL || it.mapel == mapel)
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterField("Kelas", kelas, listOf(SEMUA_KELAS) + kelasList.map { it.nama }, { kelas = it })
            FilterField("Mata Pelajaran", mapel, listOf(SEMUA_MAPEL) + mapelList.map { it.nama }, { mapel = it })
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (hasil.isEmpty()) {
                item {
                    Text(
                        "Belum ada agenda untuk pilihan ini", Modifier.fillMaxWidth().padding(top = 32.dp),
                        color = Gray500, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
            items(hasil) { a -> AgendaCard(a, showMeta = true, onMore = { sheet = a }) }
        }
    }
    sheet?.let { AgendaActionSheet(it, push) { sheet = null } }
}

// ---------------- Tab Laporan ----------------
@Composable
fun LaporanTab() {
    var jenis by remember { mutableStateOf("Agenda") }
    var kelas by remember { mutableStateOf(kelasList.first().nama) }
    var mapel by remember { mutableStateOf(mapelList.first().nama) }
    val periodeOpsi = listOf("Semester Ganjil 2026/2027", "Semester Genap 2025/2026", "Semester Ganjil 2025/2026")
    var periode by remember { mutableStateOf(periodeOpsi.first()) }
    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SegmentedField("Jenis Laporan", listOf("Agenda", "Penilaian"), jenis) { jenis = it }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (jenis == "Agenda") {
                    StatCard(Icons.Outlined.CalendarMonth, "Pertemuan", "24", Modifier.weight(1f))
                    StatCard(Icons.Outlined.HowToReg, "Rata-rata hadir", "94%", Modifier.weight(1f))
                } else {
                    StatCard(Icons.Outlined.Grade, "Penilaian", "3", Modifier.weight(1f))
                    StatCard(Icons.Outlined.BarChart, "Rata-rata nilai", "82.5", Modifier.weight(1f))
                }
            }
            Text("Filter laporan", fontWeight = FontWeight.SemiBold, color = Gray800)
            FilterField("Kelas", kelas, kelasList.map { it.nama }, { kelas = it })
            FilterField("Mata Pelajaran", mapel, mapelList.map { it.nama }, { mapel = it })
            FilterField("Periode", periode, periodeOpsi, { periode = it })
        }
        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp).height(52.dp)
        ) {
            Icon(Icons.Outlined.IosShare, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Buat Laporan")
        }
    }
}

@Composable
private fun StatCard(icon: ImageVector, label: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MdPrimary, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
            Text(label, fontSize = 12.sp, color = Gray600)
        }
    }
}
