package id.guru.agenda.ui

// Data contoh (statis) - hanya untuk tampilan
class AgendaItem(
    val kelas: String, val mapel: String, val tanggal: String, val jam: String, val topik: String,
    val hadir: Int, val sakit: Int, val izin: Int, val alpa: Int,
    val catatan: String = ""
)
class TahunAjaran(val label: String, val awal: String, val akhir: String, val semester: String, val aktif: Boolean)
class KelasItem(val nama: String, val jumlah: Int)
class SiswaItem(val nis: String, val nama: String, val jk: String, val kelas: String)
class MapelItem(val nama: String, val kelas: String)
class NilaiItem(val nama: String, val kelas: String, val mapel: String)

val agendaAll = listOf(
    AgendaItem("XII TKJ 1", "Jaringan Dasar", "Senin, 2 November 2026", "07:30 - 09:00", "Fungsi Patch Cord Fiber Optic", 34, 1, 0, 0, "Praktik di Lab TKJ"),
    AgendaItem("XI RPL 2", "Pemrograman Mobile", "Senin, 2 November 2026", "09:15 - 11:30", "Fundamental Kotlin & Material", 32, 0, 2, 1, "Tugas proyek dikumpulkan minggu depan"),
    AgendaItem("XII TKJ 1", "Administrasi Infrastruktur Jaringan", "Rabu, 28 Oktober 2026", "10:00 - 11:30", "Konfigurasi VLAN", 35, 0, 0, 0),
    AgendaItem("XII TKJ 1", "Jaringan Dasar", "Senin, 26 Oktober 2026", "07:30 - 09:00", "Konektor RJ45 dan Crimping", 35, 0, 0, 0),
    AgendaItem("XI RPL 2", "Pemrograman Mobile", "Senin, 26 Oktober 2026", "09:15 - 11:30", "Pengenalan Android Studio", 33, 1, 1, 0)
)
val agendaToday = agendaAll.take(2)

val tahunAjaranList = listOf(
    TahunAjaran("2026/2027 - Ganjil", "13 Juli 2026", "19 Desember 2026", "Ganjil", true),
    TahunAjaran("2025/2026 - Genap", "5 Januari 2026", "20 Juni 2026", "Genap", false),
    TahunAjaran("2025/2026 - Ganjil", "14 Juli 2025", "20 Desember 2025", "Ganjil", false)
)
val kelasList = listOf(KelasItem("XII TKJ 1", 35), KelasItem("XI RPL 2", 35), KelasItem("X TKJ 2", 34))
val mapelList = listOf(
    MapelItem("Jaringan Dasar", "XII TKJ 1"),
    MapelItem("Pemrograman Mobile", "XI RPL 2"),
    MapelItem("Administrasi Infrastruktur Jaringan", "XII TKJ 1"),
    MapelItem("Simulasi dan Komunikasi Digital", "X TKJ 2")
)
val nilaiList = listOf(
    NilaiItem("Tugas 1", "XII TKJ 1", "Jaringan Dasar"),
    NilaiItem("Tugas 2", "XII TKJ 1", "Jaringan Dasar"),
    NilaiItem("UTS", "XII TKJ 1", "Jaringan Dasar"),
    NilaiItem("Tugas 1", "XII TKJ 1", "Administrasi Infrastruktur Jaringan"),
    NilaiItem("Kuis 1", "XII TKJ 1", "Administrasi Infrastruktur Jaringan"),
    NilaiItem("Tugas 1", "XI RPL 2", "Pemrograman Mobile"),
    NilaiItem("Tugas 2", "XI RPL 2", "Pemrograman Mobile"),
    NilaiItem("UTS", "XI RPL 2", "Pemrograman Mobile"),
    NilaiItem("Tugas 1", "X TKJ 2", "Simulasi dan Komunikasi Digital")
)
val siswaList = listOf(
    SiswaItem("2026001", "Ahmad Fauzi", "Laki-laki", "XII TKJ 1"),
    SiswaItem("2026002", "Bella Safitri", "Perempuan", "XII TKJ 1"),
    SiswaItem("2026003", "Citra Lestari", "Perempuan", "XII TKJ 1"),
    SiswaItem("2026004", "Dimas Prakoso", "Laki-laki", "XII TKJ 1"),
    SiswaItem("2026101", "Eko Saputra", "Laki-laki", "XI RPL 2"),
    SiswaItem("2026102", "Fitri Handayani", "Perempuan", "XI RPL 2"),
    SiswaItem("2026103", "Galih Pratama", "Laki-laki", "XI RPL 2"),
    SiswaItem("2026201", "Hana Maharani", "Perempuan", "X TKJ 2"),
    SiswaItem("2026202", "Indra Wijaya", "Laki-laki", "X TKJ 2")
)

// Rute navigasi (halaman yang ditumpuk di atas halaman utama)
sealed interface Route {
    data object Profil : Route
    data object Pengaturan : Route
    data object Tema : Route
    data object Tentang : Route
    data class AgendaForm(val item: AgendaItem?) : Route
    data class Presensi(val item: AgendaItem) : Route
    data class NilaiForm(val item: NilaiItem?) : Route
    data class Penilaian(val item: NilaiItem) : Route
    data class Master(val title: String) : Route
    data class TahunForm(val item: TahunAjaran?) : Route
    data class KelasForm(val item: KelasItem?) : Route
    data class SiswaForm(val item: SiswaItem?) : Route
    data class MapelForm(val item: MapelItem?) : Route
}
