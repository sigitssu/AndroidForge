package com.edu.teacherlog

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.edu.teacherlog.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnClasses.setOnClickListener {
            startActivity(Intent(this, ClassDetailActivity::class.java))
        }
        binding.btnAgenda.setOnClickListener {
            startActivity(Intent(this, AgendaActivity::class.java))
        }
        binding.btnReports.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
    }
}