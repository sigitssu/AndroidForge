# Teacher Agenda & Presensi Android App

Aplikasi Android berbasis Kotlin dengan Material Design 3 untuk pengelolaan kelas, data siswa, mata pelajaran, agenda mengajar, presensi siswa, serta ekspor laporan PDF.

## Struktur Project:
- **`app/src/main/java/com/edu/teacherlog/`**: Kode sumber Kotlin (MainActivity, Aktivitas Kelas, Agenda, Presensi, Database Room, & Export PDF).
- **`app/src/main/res/`**: Layout XML Material Design, warna, dan tema.
- **`build.gradle.kts`**: Konfigurasi dependencies (Room DB, Apache POI untuk file Excel `.xlsx`, Material Components).

## Cara Penggunaan di AndroidForge UI / Platform Build:
1. Ekstrak file zip ini.
2. Upload folder atau impor ke workspace AndroidForge UI.
3. Build project menjadi APK siap install.