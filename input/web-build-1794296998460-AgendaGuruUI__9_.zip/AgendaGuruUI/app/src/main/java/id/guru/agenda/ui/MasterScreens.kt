package id.guru.agenda.ui

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Grade
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import id.guru.agenda.MainViewModel
import id.guru.agenda.data.*
import id.guru.agenda.util.Fmt
import id.guru.agenda.util.HasilLaporan

private class Baris(val judul: String, val sub: String, val ikon: ImageVector)

private val PaddingDaftar = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)

@Composable
private fun KartuBaris(b: Baris, onMore: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        ListItem(
            headlineContent = { Text(b.judul, fontWeight = FontWeight.Medium) },
            supportingContent = { Text(b.sub) },
            leadingContent = { Icon(b.ikon, contentDescription = null, tint = MdPrimary) },
            trailingContent = {
                IconButton(onClick = onMore) { Icon(Icons.Outlined.MoreVert, contentDescription = "Opsi", tint = Gray500) }
            },
            colors = ListItemDefaults.colors(
                containerColor = Color.Transparent, headlineColor = Gray800, supportingColor = Gray600
            )
        )
    }
}

@Composable
private fun TengahBox(padding: PaddingValues, isi: @Composable () -> Unit) {
    Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { isi() }
}

@Composable
private fun TahunKosong(push: (Route) -> Unit) {
    KeadaanKosong(
        icon = Icons.Outlined.DateRange,
        judul = "Belum ada tahun ajaran",
        deskripsi = "Buat tahun ajaran terlebih dahulu. Data kelas, siswa, mata pelajaran, dan nilai disimpan per tahun ajaran.",
        labelAksi = "Buat Tahun Ajaran",
        onAksi = { push(Route.TahunForm(null)) }
    )
}

@Composable
fun MasterScreen(vm: MainViewModel, title: String, push: (Route) -> Unit, pop: () -> Unit) {
    when (title) {
        "Tahun Ajaran" -> DaftarTahunAjaran(vm, push, pop)
        "Daftar Kelas" -> DaftarKelas(vm, push, pop)
        "Daftar Siswa" -> DaftarSiswa(vm, push, pop)
        "Daftar Mata Pelajaran" -> DaftarMapel(vm, push, pop)
        "Daftar Nilai" -> DaftarNilai(vm, push, pop)
        else -> BackupRestore(vm, pop)
    }
}

// ------------------------------------------------------------------ Tahun Ajaran
@Composable
private fun DaftarTahunAjaran(vm: MainViewModel, push: (Route) -> Unit, pop: () -> Unit) {
    val ctx = LocalContext.current
    val daftar by vm.semuaTahun.collectAsState()
    var menu by remember { mutableStateOf<TahunAjaran?>(null) }
    var hapus by remember { mutableStateOf<TahunAjaran?>(null) }

    PageScaffold("Tahun Ajaran", pop, fab = { AddFab { push(Route.TahunForm(null)) } }) { padding ->
        if (daftar.isEmpty()) {
            TengahBox(padding) {
                KeadaanKosong(
                    icon = Icons.Outlined.DateRange,
                    judul = "Belum ada tahun ajaran",
                    deskripsi = "Ketuk tombol + untuk membuat tahun ajaran. Tahun ajaran baru otomatis menjadi tahun ajaran aktif dan menjadi acuan data lainnya."
                )
            }
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingDaftar, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(daftar, key = { it.id }) { t ->
                    val sub = Fmt.tanggal(t.awal) + " - " + Fmt.tanggal(t.akhir) + (if (t.aktif) "  •  Aktif" else "")
                    KartuBaris(Baris(t.label(), sub, Icons.Outlined.DateRange)) { menu = t }
                }
            }
        }
    }
    menu?.let { t ->
        ActionSheet(
            onDismiss = { menu = null },
            actions = buildList {
                add(SheetAction(Icons.Outlined.Edit, "Ubah") { menu = null; push(Route.TahunForm(t)) })
                if (!t.aktif) {
                    add(
                        SheetAction(Icons.Outlined.CheckCircle, "Aktifkan") {
                            menu = null
                            vm.aktifkanTahun(t) { err -> ctx.toast(err ?: "Tahun ajaran ${t.label()} diaktifkan") }
                        }
                    )
                }
                add(SheetAction(Icons.Outlined.Delete, "Hapus") { menu = null; hapus = t })
            }
        )
    }
    hapus?.let { t ->
        KonfirmasiDialog(
            judul = "Hapus tahun ajaran?",
            pesan = "Tahun ajaran ${t.label()} beserta seluruh kelas, siswa, mata pelajaran, agenda, presensi, dan nilai di dalamnya akan dihapus." +
                (if (t.aktif) " Tahun ajaran terakhir yang tersisa akan menjadi tahun ajaran aktif." else ""),
            onOk = {
                hapus = null
                vm.hapusTahun(t) { err -> ctx.toast(err ?: "Tahun ajaran dihapus") }
            },
            onBatal = { hapus = null }
        )
    }
}

// ------------------------------------------------------------------ Kelas
@Composable
private fun DaftarKelas(vm: MainViewModel, push: (Route) -> Unit, pop: () -> Unit) {
    val ctx = LocalContext.current
    val tahun by vm.tahunAktif.collectAsState()
    val daftar by vm.kelas.collectAsState()
    var menu by remember { mutableStateOf<KelasView?>(null) }
    var hapus by remember { mutableStateOf<KelasView?>(null) }

    PageScaffold(
        "Daftar Kelas", pop,
        fab = {
            AddFab { if (tahun == null) ctx.toast("Buat tahun ajaran terlebih dahulu") else push(Route.KelasForm(null)) }
        }
    ) { padding ->
        if (tahun == null) {
            TengahBox(padding) { TahunKosong(push) }
        } else if (daftar.isEmpty()) {
            TengahBox(padding) {
                KeadaanKosong(
                    icon = Icons.Outlined.Class,
                    judul = "Belum ada kelas",
                    deskripsi = "Ketuk tombol + untuk menambah kelas pada tahun ajaran ${tahun?.label() ?: ""}."
                )
            }
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingDaftar, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(daftar, key = { it.id }) { k ->
                    KartuBaris(Baris(k.nama, "${k.jumlah} siswa", Icons.Outlined.Class)) { menu = k }
                }
            }
        }
    }
    menu?.let { k ->
        ActionSheet(
            onDismiss = { menu = null },
            actions = listOf(
                SheetAction(Icons.Outlined.Edit, "Ubah") { menu = null; push(Route.KelasForm(k)) },
                SheetAction(Icons.Outlined.Delete, "Hapus") { menu = null; hapus = k }
            )
        )
    }
    hapus?.let { k ->
        KonfirmasiDialog(
            judul = "Hapus kelas?",
            pesan = "Kelas ${k.nama} beserta ${k.jumlah} siswa, agenda, presensi, dan nilainya akan dihapus.",
            onOk = {
                hapus = null
                vm.hapusKelas(k) { err -> ctx.toast(err ?: "Kelas dihapus") }
            },
            onBatal = { hapus = null }
        )
    }
}

// ------------------------------------------------------------------ Siswa
@Composable
private fun DaftarSiswa(vm: MainViewModel, push: (Route) -> Unit, pop: () -> Unit) {
    val ctx = LocalContext.current
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    var kelasId by remember { mutableLongStateOf(-1L) }
    val kelasPilih = kelas.firstOrNull { it.id == kelasId } ?: kelas.firstOrNull()
    val siswa by remember(kelasPilih?.id) { vm.siswaFlow(kelasPilih?.id ?: -1L) }.collectAsState(initial = emptyList<Siswa>())
    var menu by remember { mutableStateOf<Siswa?>(null) }
    var hapus by remember { mutableStateOf<Siswa?>(null) }
    var hasilImpor by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val k = kelasPilih
        if (uri != null && k != null) vm.imporSiswa(k.id, uri) { pesan -> hasilImpor = pesan }
    }
    val impor = {
        picker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream"))
    }

    PageScaffold(
        "Daftar Siswa", pop,
        fab = {
            if (tahun != null && kelasPilih != null) {
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SmallFloatingActionButton(
                        onClick = { push(Route.SiswaForm(null, kelasPilih.id)) },
                        containerColor = MdPrimaryContainer,
                        contentColor = MdOnPrimaryContainer
                    ) { Icon(Icons.Filled.Add, contentDescription = "Tambah siswa") }
                    ExtendedFloatingActionButton(onClick = impor, containerColor = MdPrimary, contentColor = OnPrimary) {
                        Icon(Icons.Outlined.UploadFile, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Impor Excel")
                    }
                }
            }
        }
    ) { padding ->
        if (tahun == null) {
            TengahBox(padding) { TahunKosong(push) }
        } else if (kelasPilih == null) {
            TengahBox(padding) {
                KeadaanKosong(
                    icon = Icons.Outlined.Class,
                    judul = "Belum ada kelas",
                    deskripsi = "Tambahkan kelas terlebih dahulu, lalu impor atau tambahkan siswa ke kelas tersebut.",
                    labelAksi = "Tambah Kelas",
                    onAksi = { push(Route.KelasForm(null)) }
                )
            }
        } else {
            Column(Modifier.padding(padding).fillMaxSize()) {
                PilihField(
                    "Kelas", kelas, kelasPilih, { it.nama }, { kelasId = it.id },
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)
                )
                if (siswa.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        KeadaanKosong(
                            icon = Icons.Outlined.Group,
                            judul = "Belum ada siswa",
                            deskripsi = "Impor dari Excel dengan kolom NIS, Nama Siswa, dan Jenis Kelamin (L/P), atau tambahkan siswa satu per satu.",
                            labelAksi = "Impor dari Excel",
                            onAksi = impor
                        )
                    }
                } else {
                    LazyColumn(contentPadding = PaddingDaftar, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(siswa, key = { it.id }) { s ->
                            KartuBaris(Baris(s.nama, "NIS ${s.nis}  •  ${s.jk}", Icons.Outlined.Person)) { menu = s }
                        }
                    }
                }
            }
        }
    }
    menu?.let { s ->
        ActionSheet(
            onDismiss = { menu = null },
            actions = listOf(
                SheetAction(Icons.Outlined.Edit, "Ubah") { menu = null; push(Route.SiswaForm(s, s.kelasId)) },
                SheetAction(Icons.Outlined.Delete, "Hapus") { menu = null; hapus = s }
            )
        )
    }
    hapus?.let { s ->
        KonfirmasiDialog(
            judul = "Hapus siswa?",
            pesan = "Siswa ${s.nama} beserta data presensi dan nilainya akan dihapus.",
            onOk = {
                hapus = null
                vm.hapusSiswa(s) { err -> ctx.toast(err ?: "Siswa dihapus") }
            },
            onBatal = { hapus = null }
        )
    }
    hasilImpor?.let { pesan -> InfoDialog("Hasil impor", pesan, onTutup = { hasilImpor = null }) }
}

// ------------------------------------------------------------------ Mata pelajaran
@Composable
private fun DaftarMapel(vm: MainViewModel, push: (Route) -> Unit, pop: () -> Unit) {
    val ctx = LocalContext.current
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    val daftar by vm.mapel.collectAsState()
    var menu by remember { mutableStateOf<MapelView?>(null) }
    var hapus by remember { mutableStateOf<MapelView?>(null) }

    PageScaffold(
        "Daftar Mata Pelajaran", pop,
        fab = {
            AddFab {
                when {
                    tahun == null -> ctx.toast("Buat tahun ajaran terlebih dahulu")
                    kelas.isEmpty() -> ctx.toast("Tambahkan kelas terlebih dahulu")
                    else -> push(Route.MapelForm(null))
                }
            }
        }
    ) { padding ->
        if (tahun == null) {
            TengahBox(padding) { TahunKosong(push) }
        } else if (daftar.isEmpty()) {
            TengahBox(padding) {
                KeadaanKosong(
                    icon = Icons.AutoMirrored.Outlined.MenuBook,
                    judul = "Belum ada mata pelajaran",
                    deskripsi = if (kelas.isEmpty()) "Tambahkan kelas terlebih dahulu, lalu tambahkan mata pelajaran dan pilih kelas yang diajar."
                    else "Ketuk tombol + untuk menambah mata pelajaran. Satu mata pelajaran dapat diajarkan di beberapa kelas.",
                    labelAksi = if (kelas.isEmpty()) "Tambah Kelas" else null,
                    onAksi = if (kelas.isEmpty()) ({ push(Route.KelasForm(null)) }) else null
                )
            }
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingDaftar, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(daftar, key = { it.id }) { m ->
                    val sub = if (m.kelas.isEmpty()) "Belum ada kelas" else m.kelas.joinToString(", ") { it.kelasNama }
                    KartuBaris(Baris(m.nama, sub, Icons.AutoMirrored.Outlined.MenuBook)) { menu = m }
                }
            }
        }
    }
    menu?.let { m ->
        ActionSheet(
            onDismiss = { menu = null },
            actions = listOf(
                SheetAction(Icons.Outlined.Edit, "Ubah") { menu = null; push(Route.MapelForm(m)) },
                SheetAction(Icons.Outlined.Delete, "Hapus") { menu = null; hapus = m }
            )
        )
    }
    hapus?.let { m ->
        KonfirmasiDialog(
            judul = "Hapus mata pelajaran?",
            pesan = "Mata pelajaran ${m.nama} beserta agenda, presensi, dan daftar nilainya akan dihapus.",
            onOk = {
                hapus = null
                vm.hapusMapel(m) { err -> ctx.toast(err ?: "Mata pelajaran dihapus") }
            },
            onBatal = { hapus = null }
        )
    }
}

// ------------------------------------------------------------------ Daftar nilai
@Composable
private fun DaftarNilai(vm: MainViewModel, push: (Route) -> Unit, pop: () -> Unit) {
    val ctx = LocalContext.current
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    val mapel by vm.mapel.collectAsState()
    val nilai by vm.nilai.collectAsState()
    var kelasId by remember { mutableLongStateOf(-1L) }
    var mapelId by remember { mutableLongStateOf(-1L) }
    var menu by remember { mutableStateOf<NilaiView?>(null) }
    var hapus by remember { mutableStateOf<NilaiView?>(null) }

    val kelasPilih = kelas.firstOrNull { it.id == kelasId } ?: kelas.firstOrNull()
    val opsiMapel = mapel.filter { m -> m.kelas.any { it.kelasId == kelasPilih?.id } }
    val mapelPilih = opsiMapel.firstOrNull { it.id == mapelId } ?: opsiMapel.firstOrNull()
    val daftar = nilai.filter { it.kelasId == kelasPilih?.id && it.mapelId == mapelPilih?.id }

    PageScaffold(
        "Daftar Nilai", pop,
        fab = {
            AddFab {
                when {
                    tahun == null -> ctx.toast("Buat tahun ajaran terlebih dahulu")
                    kelas.isEmpty() -> ctx.toast("Tambahkan kelas terlebih dahulu")
                    mapel.none { it.kelas.isNotEmpty() } -> ctx.toast("Tambahkan mata pelajaran terlebih dahulu")
                    else -> push(Route.NilaiForm(null))
                }
            }
        }
    ) { padding ->
        if (tahun == null) {
            TengahBox(padding) { TahunKosong(push) }
        } else if (kelasPilih == null) {
            TengahBox(padding) {
                KeadaanKosong(
                    icon = Icons.Outlined.Class,
                    judul = "Belum ada kelas",
                    deskripsi = "Tambahkan kelas, siswa, dan mata pelajaran terlebih dahulu sebelum membuat daftar nilai.",
                    labelAksi = "Tambah Kelas",
                    onAksi = { push(Route.KelasForm(null)) }
                )
            }
        } else {
            Column(Modifier.padding(padding).fillMaxSize()) {
                Column(
                    Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PilihField("Kelas", kelas, kelasPilih, { it.nama }, { kelasId = it.id; mapelId = -1L })
                    PilihField(
                        "Mata Pelajaran", opsiMapel, mapelPilih, { it.nama }, { mapelId = it.id },
                        kosong = "Belum ada mata pelajaran"
                    )
                }
                if (mapelPilih == null) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        KeadaanKosong(
                            icon = Icons.AutoMirrored.Outlined.MenuBook,
                            judul = "Belum ada mata pelajaran",
                            deskripsi = "Kelas ${kelasPilih.nama} belum memiliki mata pelajaran. Tambahkan mata pelajaran dan pilih kelas ini.",
                            labelAksi = "Tambah Mata Pelajaran",
                            onAksi = { push(Route.MapelForm(null)) }
                        )
                    }
                } else if (daftar.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        KeadaanKosong(
                            icon = Icons.Outlined.Grade,
                            judul = "Belum ada daftar nilai",
                            deskripsi = "Ketuk tombol + untuk menambah daftar nilai seperti Tugas 1, Tugas 2, atau UTS."
                        )
                    }
                } else {
                    LazyColumn(contentPadding = PaddingDaftar, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(daftar, key = { it.id }) { n ->
                            KartuBaris(Baris(n.nama, "${kelasPilih.jumlah} siswa", Icons.Outlined.Grade)) { menu = n }
                        }
                    }
                }
            }
        }
    }
    menu?.let { n ->
        ActionSheet(
            onDismiss = { menu = null },
            actions = listOf(
                SheetAction(Icons.Outlined.Edit, "Ubah") { menu = null; push(Route.NilaiForm(n)) },
                SheetAction(Icons.Outlined.Grade, "Penilaian") { menu = null; push(Route.Penilaian(n)) },
                SheetAction(Icons.Outlined.Delete, "Hapus") { menu = null; hapus = n }
            )
        )
    }
    hapus?.let { n ->
        KonfirmasiDialog(
            judul = "Hapus daftar nilai?",
            pesan = "Daftar nilai \"${n.nama}\" (${n.kelasNama} - ${n.mapelNama}) beserta seluruh nilai siswa akan dihapus.",
            onOk = {
                hapus = null
                vm.hapusNilai(n) { err -> ctx.toast(err ?: "Daftar nilai dihapus") }
            },
            onBatal = { hapus = null }
        )
    }
}

// ------------------------------------------------------------------ Backup & Restore
@Composable
private fun BackupRestore(vm: MainViewModel, pop: () -> Unit) {
    val ctx = LocalContext.current
    val mintaIzin = rememberMintaIzinSimpan()
    var hasil by remember { mutableStateOf<HasilLaporan?>(null) }
    var uriPulih by remember { mutableStateOf<Uri?>(null) }
    var galat by remember { mutableStateOf<String?>(null) }
    var selesaiPulih by remember { mutableStateOf(false) }
    var sibuk by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) uriPulih = uri
    }

    PageScaffold("Backup & Restore", pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "Cadangkan seluruh data (tahun ajaran, kelas, siswa, mata pelajaran, agenda, presensi, dan nilai) ke folder Download. " +
                    "Foto profil tidak ikut dicadangkan.",
                fontSize = 14.sp, color = Gray600
            )
            SettingsCard(
                listOf(
                    SettingItem(Icons.Outlined.Backup, "Cadangkan data") {
                        if (!sibuk) {
                            mintaIzin {
                                sibuk = true
                                vm.cadangkan { h -> sibuk = false; hasil = h }
                            }
                        }
                    },
                    SettingItem(Icons.Outlined.Restore, "Pulihkan data") {
                        if (!sibuk) picker.launch(arrayOf("*/*"))
                    }
                )
            )
            if (sibuk) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Memproses...", color = Gray600)
                }
            }
        }
    }

    hasil?.let { h ->
        InfoDialog(
            judul = if (h.sukses) "Berhasil" else "Gagal",
            pesan = h.pesan,
            onTutup = { hasil = null }
        )
    }
    uriPulih?.let { u ->
        KonfirmasiDialog(
            judul = "Pulihkan data?",
            pesan = "Seluruh data saat ini akan diganti dengan data dari file cadangan. Tindakan ini tidak dapat dibatalkan.",
            labelOk = "Pulihkan",
            onOk = {
                uriPulih = null
                sibuk = true
                vm.pulihkan(u) { err ->
                    sibuk = false
                    if (err == null) selesaiPulih = true else galat = err
                }
            },
            onBatal = { uriPulih = null }
        )
    }
    galat?.let { g -> InfoDialog("Gagal memulihkan", g, onTutup = { galat = null }) }
    if (selesaiPulih) {
        InfoDialog(
            judul = "Data dipulihkan",
            pesan = "Data berhasil dipulihkan. Aplikasi akan ditutup, silakan buka kembali untuk melihat data.",
            onTutup = {
                (ctx as? Activity)?.finishAffinity()
                Runtime.getRuntime().exit(0)
            }
        )
    }
}
