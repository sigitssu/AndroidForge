package id.guru.agenda.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.SettingsBrightness
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import id.guru.agenda.MainViewModel
import id.guru.agenda.R

@Composable
fun PengaturanScreen(push: (Route) -> Unit, pop: () -> Unit) {
    PageScaffold("Pengaturan", pop) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            SettingsCard(
                listOf(
                    SettingItem(Icons.Outlined.Palette, "Tema Aplikasi") { push(Route.Tema) },
                    SettingItem(Icons.Outlined.Info, "Tentang Aplikasi") { push(Route.Tentang) }
                )
            )
        }
    }
}

// ------------------------------------------------------------------ Tema Aplikasi
@Composable
fun TemaScreen(vm: MainViewModel, pop: () -> Unit) {
    val tema = vm.tema
    var editor by remember { mutableStateOf(false) }

    PageScaffold("Tema Aplikasi", pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Tema Warna", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Gray800)
                    Spacer(Modifier.height(12.dp))
                    ThemeSwitch(tema.mode) { tema.aturMode(it) }
                    Spacer(Modifier.height(24.dp))
                    Text("Warna Aplikasi", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Gray800)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WarnaPreset.forEachIndexed { i, c ->
                            ColorDot(c, tema.warnaIndex == i) { tema.aturWarna(i) }
                        }
                        if (tema.warnaKustom != 0) {
                            ColorDot(Color(tema.warnaKustom), tema.warnaIndex == INDEKS_KUSTOM) { tema.aturWarna(INDEKS_KUSTOM) }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    HorizontalDivider(color = Gray100)
                    Row(
                        Modifier.fillMaxWidth().clickable { editor = true }.padding(top = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(
                                Brush.sweepGradient(
                                    listOf(
                                        Color(0xFFFF5A6E), Color(0xFFFFD54F), Color(0xFF66CC8A), Color(0xFF22D3EE),
                                        Color(0xFF3B82F6), Color(0xFFD946EF), Color(0xFFFF5A6E)
                                    )
                                )
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Brush, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Text("Buka Editor", Modifier.weight(1f), fontWeight = FontWeight.Medium, color = Gray600)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Gray500)
                    }
                }
            }
            Text(
                "Pilihan tema dan warna langsung diterapkan ke seluruh tampilan aplikasi dan tersimpan otomatis.",
                fontSize = 12.sp, color = Gray500
            )
        }
    }
    if (editor) {
        EditorWarnaDialog(
            awal = tema.seed(),
            onTerapkan = { tema.aturKustom(it.toArgb()); editor = false },
            onBatal = { editor = false }
        )
    }
}

@Composable
private fun ThemeSwitch(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Icons.Outlined.LightMode to "Terang",
        Icons.Outlined.DarkMode to "Gelap",
        Icons.Outlined.SettingsBrightness to "Sistem"
    )
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(MdSurfaceVariant.copy(alpha = 0.6f)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, item ->
            val dipilih = i == selected
            val bobot by animateFloatAsState(if (dipilih) 1.9f else 1f, label = "bobot")
            Row(
                Modifier.weight(bobot)
                    .clip(RoundedCornerShape(50))
                    .background(if (dipilih) MdPrimary else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.first, contentDescription = item.second, tint = if (dipilih) OnPrimary else Gray600, modifier = Modifier.size(20.dp))
                if (dipilih) {
                    Spacer(Modifier.width(6.dp))
                    Text(item.second, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = OnPrimary)
                }
            }
        }
    }
}

@Composable
private fun ColorDot(color: Color, dipilih: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).clip(CircleShape)
            .then(if (dipilih) Modifier.border(2.dp, color.copy(alpha = 0.5f), CircleShape) else Modifier)
            .clickable(onClick = onClick)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            if (dipilih) {
                val putih = androidx.core.graphics.ColorUtils.calculateContrast(Color.White.toArgb(), color.toArgb()) >= 3.0
                Icon(Icons.Filled.Check, contentDescription = null, tint = if (putih) Color.White else Color(0xFF1D1B20), modifier = Modifier.size(16.dp))
            }
        }
    }
}

private fun hexDari(c: Color): String = String.format("#%06X", c.toArgb() and 0xFFFFFF)

@Composable
private fun EditorWarnaDialog(awal: Color, onTerapkan: (Color) -> Unit, onBatal: () -> Unit) {
    val hsv0 = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(awal.toArgb(), it) } }
    var h by remember { mutableFloatStateOf(hsv0[0]) }
    var s by remember { mutableFloatStateOf(hsv0[1].coerceIn(0.2f, 1f)) }
    var v by remember { mutableFloatStateOf(hsv0[2].coerceIn(0.25f, 1f)) }
    val warna = Color.hsv(h, s, v)
    var hex by remember { mutableStateOf(hexDari(Color.hsv(hsv0[0], hsv0[1].coerceIn(0.2f, 1f), hsv0[2].coerceIn(0.25f, 1f)))) }
    var galatHex by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onBatal,
        title = { Text("Editor Warna") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(12.dp)).background(warna))
                Text("Warna", fontSize = 12.sp, color = Gray600)
                Slider(value = h, onValueChange = { h = it; hex = hexDari(Color.hsv(h, s, v)); galatHex = null }, valueRange = 0f..360f)
                Text("Kepekatan", fontSize = 12.sp, color = Gray600)
                Slider(value = s, onValueChange = { s = it; hex = hexDari(Color.hsv(h, s, v)); galatHex = null }, valueRange = 0.2f..1f)
                Text("Kecerahan", fontSize = 12.sp, color = Gray600)
                Slider(value = v, onValueChange = { v = it; hex = hexDari(Color.hsv(h, s, v)); galatHex = null }, valueRange = 0.25f..1f)
                OutlinedTextField(
                    value = hex,
                    onValueChange = { t ->
                        val bersih = t.uppercase().filter { it.isDigit() || it in 'A'..'F' || it == '#' }.take(7)
                        hex = bersih
                        val isi = bersih.removePrefix("#")
                        if (isi.length == 6) {
                            val tmp = FloatArray(3)
                            android.graphics.Color.colorToHSV(android.graphics.Color.parseColor("#$isi"), tmp)
                            h = tmp[0]
                            s = tmp[1].coerceIn(0.2f, 1f)
                            v = tmp[2].coerceIn(0.25f, 1f)
                            galatHex = null
                        } else {
                            galatHex = "Gunakan format #RRGGBB"
                        }
                    },
                    label = { Text("Kode warna (hex)") },
                    singleLine = true,
                    isError = galatHex != null,
                    supportingText = if (galatHex != null) ({ Text(galatHex ?: "") }) else null,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Warna ini dipakai sebagai warna utama dan diterapkan ke seluruh tampilan aplikasi.", fontSize = 12.sp, color = Gray500)
            }
        },
        confirmButton = {
            TextButton(onClick = { if (galatHex == null) onTerapkan(warna) }) { Text("Terapkan") }
        },
        dismissButton = { TextButton(onClick = onBatal) { Text("Batal") } }
    )
}

// ------------------------------------------------------------------ Tentang Aplikasi
private const val EMAIL_DEVELOPER = "sigitutomo25@gmail.com"

/** Membuka aplikasi email dengan tujuan dan subjek yang sudah terisi. */
private fun kirimEmail(ctx: Context) {
    val subjek = "Aplikasi Agenda Guru"
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:$EMAIL_DEVELOPER?subject=" + Uri.encode(subjek))
        putExtra(Intent.EXTRA_EMAIL, arrayOf(EMAIL_DEVELOPER))
        putExtra(Intent.EXTRA_SUBJECT, subjek)
    }
    try {
        ctx.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        ctx.toast("Tidak ada aplikasi email yang terpasang")
    }
}

@Composable
fun TentangScreen(pop: () -> Unit) {
    val ctx = LocalContext.current
    val versi = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0"
        } catch (e: Exception) {
            "1.0.0"
        }
    }
    PageScaffold("Tentang Aplikasi", pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.size(112.dp).clip(RoundedCornerShape(32.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF42A8FF), Color(0xFF6285F8), Color(0xFF8B66FB)))),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_launcher_foreground),
                    contentDescription = "Ikon Agenda Guru",
                    modifier = Modifier.requiredSize(168.dp)
                )
            }
            Text("Agenda Guru", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Gray800)
            Text("Versi $versi", fontSize = 14.sp, color = Gray500)
            Text(
                "Aplikasi pencatat agenda mengajar, presensi siswa, dan penilaian untuk guru. " +
                    "Data tersimpan di perangkat dan laporannya dapat dibuat dalam bentuk PDF atau Excel.",
                textAlign = TextAlign.Center, fontSize = 14.sp, color = Gray600
            )
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    InfoRow(Icons.Outlined.EventAvailable, "Fitur utama", "Agenda mengajar, presensi siswa, dan penilaian")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.Storage, "Penyimpanan", "Lokal di perangkat")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.UploadFile, "Impor data siswa", "File Excel (.xlsx)")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.Description, "Laporan", "PDF atau Excel")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.Code, "Dibuat dengan", "Kotlin & Material Design 3")
                }
            }
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Email, contentDescription = null, tint = MdPrimary)
                        Spacer(Modifier.width(12.dp))
                        Text("Hubungi Developer", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Gray800)
                    }
                    Text(
                        "Jika merasa aplikasi ini bermanfaat dan ingin memberikan apresiasi, Anda dapat menghubungi developer melalui email.",
                        fontSize = 14.sp, color = Gray600
                    )
                    Button(onClick = { kirimEmail(ctx) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Icon(Icons.Outlined.Email, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Kirim Email")
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MdPrimary)
        Spacer(Modifier.width(16.dp))
        Column {
            Text(label, fontSize = 12.sp, color = Gray500)
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray800)
        }
    }
}
