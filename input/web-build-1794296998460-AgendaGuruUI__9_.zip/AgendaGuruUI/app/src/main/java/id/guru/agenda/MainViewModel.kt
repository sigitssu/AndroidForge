package id.guru.agenda

import android.app.Application
import android.database.sqlite.SQLiteDatabase
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import id.guru.agenda.data.*
import id.guru.agenda.ui.ThemePrefs
import id.guru.agenda.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

val PROFIL_AWAL = Profil(id = 1, nama = "Pampam Bamungkas", nip = "1234567890", sekolah = "SMK Negeri 1", fotoPath = null)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    private val dao = db.dao()
    val tema = ThemePrefs(app)

    private val _siap = MutableStateFlow(false)
    val siap: StateFlow<Boolean> = _siap

    /** Bertambah setiap ada perubahan data, dipakai untuk menyegarkan perhitungan sekali-jalan. */
    val versi = MutableStateFlow(0)

    val profil: StateFlow<Profil> = dao.profil().map { it ?: PROFIL_AWAL }
        .stateIn(viewModelScope, SharingStarted.Eagerly, PROFIL_AWAL)

    val tahunAktif: StateFlow<TahunAjaran?> = dao.tahunAktif().onEach { _siap.value = true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val semuaTahun: StateFlow<List<TahunAjaran>> = dao.semuaTahun()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<TahunAjaran>())

    private val idTahun = tahunAktif.map { it?.id ?: -1L }.distinctUntilChanged()

    val kelas: StateFlow<List<KelasView>> = idTahun.flatMapLatest { dao.kelas(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<KelasView>())

    val mapel: StateFlow<List<MapelView>> = combine(
        idTahun.flatMapLatest { dao.mapel(it) },
        idTahun.flatMapLatest { dao.mapelKelas(it) }
    ) { daftar, relasi ->
        daftar.map { m -> MapelView(m.id, m.nama, relasi.filter { r -> r.mapelId == m.id }) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<MapelView>())

    val agenda: StateFlow<List<AgendaView>> = idTahun.flatMapLatest { dao.agenda(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<AgendaView>())

    val nilai: StateFlow<List<NilaiView>> = idTahun.flatMapLatest { dao.nilai(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList<NilaiView>())

    fun siswaFlow(kelasId: Long): Flow<List<Siswa>> = dao.siswa(kelasId)

    // ------------------------------------------------------------ pembantu
    private fun kerja(cb: (String?) -> Unit, blok: suspend () -> String?) {
        viewModelScope.launch {
            val hasil = try {
                withContext(Dispatchers.IO) { blok() }
            } catch (e: Exception) {
                "Terjadi kesalahan: ${e.message ?: e.javaClass.simpleName}"
            }
            if (hasil == null) versi.value = versi.value + 1
            cb(hasil)
        }
    }

    // ------------------------------------------------------------ profil
    fun simpanProfil(nama: String, nip: String, sekolah: String, cb: (String?) -> Unit) = kerja(cb) {
        dao.simpanProfil(profil.value.copy(nama = nama.trim(), nip = nip.trim(), sekolah = sekolah.trim()))
        null
    }

    fun ubahFoto(uri: Uri, cb: (String?) -> Unit) = kerja(cb) {
        val path = simpanFoto(uri)
        val lama = profil.value.fotoPath
        dao.simpanProfil(profil.value.copy(fotoPath = path))
        if (lama != null) File(lama).delete()
        null
    }

    fun hapusFoto(cb: (String?) -> Unit) = kerja(cb) {
        val lama = profil.value.fotoPath
        dao.simpanProfil(profil.value.copy(fotoPath = null))
        if (lama != null) File(lama).delete()
        null
    }

    private fun simpanFoto(uri: Uri): String {
        val cr = app.contentResolver
        val batas = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, batas) }
        var sample = 1
        while (batas.outWidth / sample > 1024 || batas.outHeight / sample > 1024) sample *= 2
        val opsi = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opsi) }
            ?: throw IllegalStateException("Gambar tidak dapat dibaca")
        val derajat = try {
            cr.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }
        if (derajat != 0f) {
            val m = Matrix().apply { postRotate(derajat) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val sisi = minOf(bmp.width, bmp.height)
        val persegi = Bitmap.createBitmap(bmp, (bmp.width - sisi) / 2, (bmp.height - sisi) / 2, sisi, sisi)
        val akhir = if (sisi > 512) Bitmap.createScaledBitmap(persegi, 512, 512, true) else persegi
        val f = File(app.filesDir, "foto_${System.currentTimeMillis()}.jpg")
        f.outputStream().use { akhir.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return f.path
    }

    // ------------------------------------------------------------ tahun ajaran
    fun simpanTahun(lama: TahunAjaran?, awal: Long, akhir: Long, semester: String, cb: (String?) -> Unit) = kerja(cb) {
        if (akhir <= awal) return@kerja "Akhir tahun ajaran harus setelah awal tahun ajaran"
        val baru = (lama ?: TahunAjaran(awal = awal, akhir = akhir, semester = semester))
            .copy(awal = awal, akhir = akhir, semester = semester)
        val kembar = dao.semuaTahunOnce().any { it.id != lama?.id && it.label() == baru.label() }
        if (kembar) return@kerja "Tahun ajaran ${baru.label()} sudah ada"
        if (lama != null) {
            val luar = dao.hitungAgendaDiLuar(lama.id, awal, akhir)
            if (luar > 0) return@kerja "Ada $luar agenda di luar rentang tanggal yang baru. Hapus atau ubah agenda tersebut terlebih dahulu."
        }
        db.withTransaction {
            if (lama == null) {
                dao.nonaktifkanSemua()
                dao.insertTahun(baru.copy(aktif = true))
            } else {
                dao.updateTahun(baru)
            }
        }
        null
    }

    /** Menjadikan tahun ajaran tertentu aktif (yang lain otomatis nonaktif). */
    fun aktifkanTahun(t: TahunAjaran, cb: (String?) -> Unit) = kerja(cb) {
        db.withTransaction {
            dao.nonaktifkanSemua()
            dao.aktifkan(t.id)
        }
        null
    }

    fun hapusTahun(t: TahunAjaran, cb: (String?) -> Unit) = kerja(cb) {
        db.withTransaction {
            dao.deleteTahun(t)
            val pengganti = if (t.aktif) dao.tahunTerbaru() else null
            if (pengganti != null) dao.aktifkan(pengganti.id)
        }
        null
    }

    // ------------------------------------------------------------ kelas
    fun simpanKelas(lama: KelasView?, nama: String, cb: (String?) -> Unit) = kerja(cb) {
        val th = tahunAktif.value ?: return@kerja "Belum ada tahun ajaran aktif"
        val n = nama.trim()
        if (dao.hitungKelasNama(th.id, n, lama?.id ?: 0L) > 0) return@kerja "Kelas \"$n\" sudah ada"
        if (lama == null) dao.insertKelas(Kelas(tahunId = th.id, nama = n)) else dao.updateKelas(Kelas(lama.id, lama.tahunId, n))
        null
    }

    fun hapusKelas(k: KelasView, cb: (String?) -> Unit) = kerja(cb) { dao.hapusKelas(k.id); null }

    // ------------------------------------------------------------ siswa
    fun simpanSiswa(lama: Siswa?, kelasId: Long, nis: String, nama: String, jk: String, cb: (String?) -> Unit) = kerja(cb) {
        val n = nis.trim()
        val nm = nama.trim()
        val ada = dao.siswaByNis(kelasId, n)
        if (ada != null && ada.id != lama?.id) return@kerja "NIS $n sudah terdaftar di kelas ini atas nama ${ada.nama}"
        if (lama == null) dao.insertSiswa(Siswa(kelasId = kelasId, nis = n, nama = nm, jk = jk)) else dao.updateSiswa(lama.copy(nis = n, nama = nm, jk = jk))
        null
    }

    fun hapusSiswa(s: Siswa, cb: (String?) -> Unit) = kerja(cb) { dao.hapusSiswa(s.id); null }

    /** Format Excel: kolom A = NIS, B = Nama Siswa, C = Jenis Kelamin. Baris judul boleh ada. */
    fun imporSiswa(kelasId: Long, uri: Uri, cb: (String) -> Unit) {
        viewModelScope.launch {
            val pesan = try {
                withContext(Dispatchers.IO) { prosesImpor(kelasId, uri) }
            } catch (e: Exception) {
                "Gagal mengimpor. Pastikan file berformat Excel (.xlsx).\n${e.message ?: ""}"
            }
            versi.value = versi.value + 1
            cb(pesan)
        }
    }

    private suspend fun prosesImpor(kelasId: Long, uri: Uri): String {
        val stream = app.contentResolver.openInputStream(uri) ?: return "File tidak dapat dibuka."
        val baris = stream.use { XlsxReader.baca(it) }
        if (baris.isEmpty()) return "File kosong atau bukan format Excel (.xlsx)."
        val h0 = baris.first()
        val adaHeader = h0.getOrNull(0).orEmpty().lowercase().contains("nis") ||
            h0.getOrNull(1).orEmpty().lowercase().contains("nama")
        val mulai = if (adaHeader) 1 else 0
        var tambah = 0
        var perbarui = 0
        val gagal = mutableListOf<String>()
        db.withTransaction {
            for (i in mulai until baris.size) {
                val r = baris[i]
                if (r.all { it.isBlank() }) continue
                val no = i + 1
                val nis = XlsxReader.normalNis(r.getOrNull(0))
                val nama = r.getOrNull(1).orEmpty().trim()
                val jk = XlsxReader.normalJk(r.getOrNull(2))
                when {
                    nis.isBlank() -> gagal.add("Baris $no: NIS kosong")
                    nis.length > 20 -> gagal.add("Baris $no: NIS terlalu panjang")
                    nama.isBlank() -> gagal.add("Baris $no: Nama siswa kosong")
                    nama.length > 100 -> gagal.add("Baris $no: Nama siswa terlalu panjang")
                    jk == null -> gagal.add("Baris $no: Jenis kelamin harus L/P atau Laki-laki/Perempuan")
                    else -> {
                        val ada = dao.siswaByNis(kelasId, nis)
                        if (ada == null) {
                            dao.insertSiswa(Siswa(kelasId = kelasId, nis = nis, nama = nama, jk = jk))
                            tambah++
                        } else {
                            dao.updateSiswa(ada.copy(nama = nama, jk = jk))
                            perbarui++
                        }
                    }
                }
            }
        }
        val sb = StringBuilder()
        sb.append("$tambah siswa ditambahkan, $perbarui siswa diperbarui")
        if (gagal.isNotEmpty()) {
            sb.append(", ${gagal.size} baris dilewati:")
            gagal.take(6).forEach { sb.append("\n• ").append(it) }
            if (gagal.size > 6) sb.append("\n• dan ${gagal.size - 6} baris lainnya")
        } else {
            sb.append(".")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------ mata pelajaran
    fun simpanMapel(lama: MapelView?, nama: String, kelasIds: Set<Long>, cb: (String?) -> Unit) = kerja(cb) {
        val th = tahunAktif.value ?: return@kerja "Belum ada tahun ajaran aktif"
        val n = nama.trim()
        if (dao.hitungMapelNama(th.id, n, lama?.id ?: 0L) > 0) return@kerja "Mata pelajaran \"$n\" sudah ada"
        if (lama != null) {
            for (r in lama.kelas) {
                if (r.kelasId !in kelasIds && dao.hitungDataMapelKelas(lama.id, r.kelasId) > 0) {
                    return@kerja "Kelas ${r.kelasNama} tidak dapat dihapus dari mata pelajaran ini karena sudah memiliki agenda atau daftar nilai."
                }
            }
        }
        db.withTransaction {
            val id = if (lama == null) {
                dao.insertMapel(Mapel(tahunId = th.id, nama = n))
            } else {
                dao.updateMapel(Mapel(lama.id, th.id, n))
                dao.hapusMapelKelas(lama.id)
                lama.id
            }
            dao.insertMapelKelas(kelasIds.map { MapelKelas(id, it) })
        }
        null
    }

    fun hapusMapel(m: MapelView, cb: (String?) -> Unit) = kerja(cb) { dao.hapusMapel(m.id); null }

    // ------------------------------------------------------------ agenda & presensi
    fun simpanAgenda(
        lama: AgendaView?, kelasId: Long, mapelId: Long, tanggal: Long, mulai: Int, selesai: Int,
        topik: String, catatan: String, cb: (String?) -> Unit
    ) = kerja(cb) {
        if (selesai <= mulai) return@kerja "Jam selesai harus lebih besar dari jam mulai"
        val th = tahunAktif.value ?: return@kerja "Belum ada tahun ajaran aktif"
        if (tanggal < th.awal || tanggal > th.akhir) {
            return@kerja "Tanggal harus berada dalam rentang tahun ajaran (${Fmt.tanggal(th.awal)} - ${Fmt.tanggal(th.akhir)})"
        }
        val sah = mapel.value.any { m -> m.id == mapelId && m.kelas.any { it.kelasId == kelasId } }
        if (!sah) return@kerja "Mata pelajaran ini tidak diajarkan di kelas yang dipilih"
        if (dao.hitungBentrok(kelasId, tanggal, lama?.id ?: 0L, mulai, selesai) > 0) {
            return@kerja "Jadwal bentrok dengan agenda lain pada kelas dan tanggal yang sama"
        }
        val a = Agenda(
            id = lama?.id ?: 0L, kelasId = kelasId, mapelId = mapelId, tanggal = tanggal,
            mulai = mulai, selesai = selesai, topik = topik.trim(), catatan = catatan.trim()
        )
        if (lama == null) dao.insertAgenda(a) else dao.updateAgenda(a)
        null
    }

    fun hapusAgenda(a: AgendaView, cb: (String?) -> Unit) = kerja(cb) { dao.hapusAgenda(a.id); null }

    suspend fun presensiAgenda(agendaId: Long): Map<Long, String> =
        withContext(Dispatchers.IO) { dao.presensi(agendaId).associate { it.siswaId to it.status } }

    fun simpanPresensi(agendaId: Long, status: Map<Long, String>, cb: (String?) -> Unit) = kerja(cb) {
        dao.simpanPresensi(status.map { (sid, st) -> Presensi(agendaId = agendaId, siswaId = sid, status = st) })
        null
    }

    // ------------------------------------------------------------ nilai
    fun simpanNilai(lama: NilaiView?, nama: String, kelasId: Long, mapelId: Long, cb: (String?) -> Unit) = kerja(cb) {
        val n = nama.trim()
        val sah = mapel.value.any { m -> m.id == mapelId && m.kelas.any { it.kelasId == kelasId } }
        if (!sah) return@kerja "Mata pelajaran ini tidak diajarkan di kelas yang dipilih"
        if (dao.hitungNilaiNama(kelasId, mapelId, n, lama?.id ?: 0L) > 0) {
            return@kerja "Daftar nilai \"$n\" sudah ada untuk kelas dan mata pelajaran ini"
        }
        if (lama == null) dao.insertNilai(Nilai(kelasId = kelasId, mapelId = mapelId, nama = n))
        else dao.updateNilai(Nilai(lama.id, kelasId, mapelId, n))
        null
    }

    fun hapusNilai(n: NilaiView, cb: (String?) -> Unit) = kerja(cb) { dao.hapusNilai(n.id); null }

    suspend fun nilaiSiswaMap(nilaiId: Long): Map<Long, Double> =
        withContext(Dispatchers.IO) { dao.nilaiSiswa(nilaiId).associate { it.siswaId to it.skor } }

    fun simpanNilaiSiswa(nilaiId: Long, skor: Map<Long, Double?>, cb: (String?) -> Unit) = kerja(cb) {
        db.withTransaction {
            val simpan = mutableListOf<NilaiSiswa>()
            for ((sid, v) in skor) {
                if (v == null) dao.hapusNilaiSiswa(nilaiId, sid) else simpan.add(NilaiSiswa(nilaiId = nilaiId, siswaId = sid, skor = v))
            }
            if (simpan.isNotEmpty()) dao.simpanNilaiSiswa(simpan)
        }
        null
    }

    suspend fun statNilai(kelasId: Long, mapelId: Long): Pair<Int, Double?> = withContext(Dispatchers.IO) {
        val daftar = dao.nilaiUntuk(kelasId, mapelId)
        val skor = dao.nilaiSiswaUntuk(kelasId, mapelId).map { it.skor }
        Pair(daftar.size, if (skor.isEmpty()) null else skor.average())
    }

    // ------------------------------------------------------------ laporan
    fun buatLaporan(jenis: String, kelas: KelasView, mapel: MapelView, periode: Periode?, cb: (HasilLaporan) -> Unit) {
        viewModelScope.launch {
            val hasil = try {
                withContext(Dispatchers.IO) { susunLaporan(jenis, kelas, mapel, periode) }
            } catch (e: Exception) {
                HasilLaporan(false, "Gagal membuat laporan: ${e.message ?: e.javaClass.simpleName}")
            }
            cb(hasil)
        }
    }

    private suspend fun susunLaporan(jenis: String, kelas: KelasView, mapel: MapelView, periode: Periode?): HasilLaporan {
        val tahun = tahunAktif.value ?: return HasilLaporan(false, "Belum ada tahun ajaran aktif.")
        val p = profil.value
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))
        val dasar = Fmt.aman(kelas.nama) + "_" + Fmt.aman(mapel.nama) + "_" + stamp
        if (jenis == "Agenda") {
            val per = periode ?: return HasilLaporan(false, "Pilih periode laporan terlebih dahulu.")
            val agenda = dao.agendaLaporan(kelas.id, mapel.id, per.dari, per.sampai)
            if (agenda.isEmpty()) {
                return HasilLaporan(false, "Tidak ada agenda pada periode \"${per.label}\" untuk kelas dan mata pelajaran ini.")
            }
            val siswa = dao.siswaOnce(kelas.id)
            val pres = dao.presensiLaporan(kelas.id, mapel.id, per.dari, per.sampai)
            val bytes = LaporanPdf.buat(
                DataLaporanAgenda(p.sekolah, p.nama, p.nip, tahun.label(), kelas.nama, mapel.nama, per.label, agenda, siswa, pres)
            )
            val h = Unduhan.simpan(app, "Laporan_Agenda_$dasar.pdf", "application/pdf", bytes)
            return HasilLaporan(true, "Laporan agenda tersimpan di folder Download:\n${h.nama}", h.uri, "application/pdf")
        } else {
            val daftar = dao.nilaiUntuk(kelas.id, mapel.id)
            if (daftar.isEmpty()) return HasilLaporan(false, "Belum ada daftar nilai untuk kelas dan mata pelajaran ini.")
            val siswa = dao.siswaOnce(kelas.id)
            if (siswa.isEmpty()) return HasilLaporan(false, "Belum ada siswa di kelas ini.")
            val skor = dao.nilaiSiswaUntuk(kelas.id, mapel.id)
            val bytes = LaporanExcel.nilai(p.sekolah, p.nama, p.nip, tahun.label(), kelas.nama, mapel.nama, daftar, siswa, skor)
            val mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            val h = Unduhan.simpan(app, "Laporan_Nilai_$dasar.xlsx", mime, bytes)
            return HasilLaporan(true, "Laporan penilaian tersimpan di folder Download:\n${h.nama}", h.uri, mime)
        }
    }

    // ------------------------------------------------------------ cadangkan & pulihkan
    fun cadangkan(cb: (HasilLaporan) -> Unit) {
        viewModelScope.launch {
            val hasil = try {
                withContext(Dispatchers.IO) {
                    db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
                    val bytes = AppDatabase.fileDb(app).readBytes()
                    val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))
                    val h = Unduhan.simpan(app, "AgendaGuru_cadangan_$stamp.db", "application/octet-stream", bytes)
                    HasilLaporan(true, "Cadangan data tersimpan di folder Download:\n${h.nama}")
                }
            } catch (e: Exception) {
                HasilLaporan(false, "Gagal mencadangkan data: ${e.message ?: e.javaClass.simpleName}")
            }
            cb(hasil)
        }
    }

    /** Menyiapkan file pemulihan. Data baru dipakai saat aplikasi dibuka kembali. */
    fun pulihkan(uri: Uri, cb: (String?) -> Unit) {
        viewModelScope.launch {
            val hasil = try {
                withContext(Dispatchers.IO) { siapkanPemulihan(uri) }
            } catch (e: Exception) {
                "Gagal memulihkan data: ${e.message ?: e.javaClass.simpleName}"
            }
            cb(hasil)
        }
    }

    private fun siapkanPemulihan(uri: Uri): String? {
        val tmp = File(app.cacheDir, "validasi.db")
        val masuk = app.contentResolver.openInputStream(uri) ?: return "File tidak dapat dibuka."
        masuk.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        val tabel = listOf("profil", "tahun_ajaran", "kelas", "siswa", "mapel", "mapel_kelas", "agenda", "presensi", "nilai", "nilai_siswa")
        val sah = try {
            val s = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY)
            try {
                s.version == AppDatabase.VERSI && tabel.all { t ->
                    s.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(t)).use { it.moveToFirst() }
                }
            } finally {
                s.close()
            }
        } catch (e: Exception) {
            false
        }
        if (!sah) {
            tmp.delete()
            return "File bukan cadangan Agenda Guru yang valid."
        }
        tmp.copyTo(AppDatabase.filePulihkan(app), overwrite = true)
        tmp.delete()
        return null
    }
}
