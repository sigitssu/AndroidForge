package id.guru.agenda.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.EventBusy
import androidx.compose.material.icons.outlined.Grade
import androidx.compose.material.icons.outlined.HowToReg
import androidx.compose.material.icons.outlined.IosShare
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*
import id.guru.agenda.MainViewModel
import id.guru.agenda.data.*
import id.guru.agenda.util.Fmt
import id.guru.agenda.util.HasilLaporan
import id.guru.agenda.util.daftarPeriode
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private val ListPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)

private class Pil(val id: Long, val nama: String)

/** Menu Ubah / Presensi Siswa / Hapus untuk satu agenda, lengkap dengan konfirmasi hapus. */
@Composable
fun AgendaAksi(vm: MainViewModel, a: AgendaView?, push: (Route) -> Unit, onTutup: () -> Unit) {
    val ctx = LocalContext.current
    var konfirmasi by remember { mutableStateOf<AgendaView?>(null) }
    if (a != null) {
        ActionSheet(
            onDismiss = onTutup,
            actions = listOf(
                SheetAction(Icons.Outlined.Edit, "Ubah") { onTutup(); push(Route.AgendaForm(a)) },
                SheetAction(Icons.Outlined.HowToReg, "Presensi Siswa") { onTutup(); push(Route.Presensi(a)) },
                SheetAction(Icons.Outlined.Delete, "Hapus") { onTutup(); konfirmasi = a }
            )
        )
    }
    konfirmasi?.let { x ->
        KonfirmasiDialog(
            judul = "Hapus agenda?",
            pesan = "Agenda \"${x.topik}\" (${x.kelasNama}, ${Fmt.tanggal(x.tanggal)}) beserta data presensinya akan dihapus.",
            onOk = {
                konfirmasi = null
                vm.hapusAgenda(x) { err -> ctx.toast(err ?: "Agenda dihapus") }
            },
            onBatal = { konfirmasi = null }
        )
    }
}

// ------------------------------------------------------------------ Beranda
@Composable
fun BerandaTab(vm: MainViewModel, push: (Route) -> Unit, tambahAgenda: () -> Unit) {
    val tahun by vm.tahunAktif.collectAsState()
    val agenda by vm.agenda.collectAsState()
    var hariIni by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            hariIni = LocalDate.now().toEpochDay()
        }
    }
    val daftar = agenda.filter { it.tanggal == hariIni }.sortedBy { it.mulai }
    var menu by remember { mutableStateOf<AgendaView?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = ListPadding,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { WaktuCard() }
        if (tahun == null) {
            item {
                KeadaanKosong(
                    icon = Icons.Outlined.CalendarMonth,
                    judul = "Belum ada tahun ajaran",
                    deskripsi = "Buat tahun ajaran terlebih dahulu untuk mulai mencatat agenda, presensi, dan penilaian.",
                    labelAksi = "Buat Tahun Ajaran",
                    onAksi = { push(Route.TahunForm(null)) }
                )
            }
        } else {
            item { RekapRow(daftar) }
            if (daftar.isEmpty()) {
                item {
                    KeadaanKosong(
                        icon = Icons.Outlined.EventBusy,
                        judul = "Belum ada agenda hari ini",
                        deskripsi = "Ketuk tombol di bawah untuk menambah agenda mengajar hari ini.",
                        labelAksi = "Tambah Agenda",
                        onAksi = tambahAgenda
                    )
                }
            } else {
                items(daftar, key = { it.id }) { a -> AgendaCard(a, false) { menu = a } }
            }
        }
    }
    AgendaAksi(vm, menu, push) { menu = null }
}

@Composable
private fun WaktuCard() {
    var sekarang by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            sekarang = LocalDateTime.now()
            delay(1000)
        }
    }
    val tanggal = sekarang.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Fmt.locale))
    val waktu = sekarang.format(DateTimeFormatter.ofPattern("HH:mm"))
    Box(
        Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(BannerStart, BannerEnd)))
    ) {
        Icon(
            Icons.Outlined.Schedule, contentDescription = null,
            modifier = Modifier.align(Alignment.BottomEnd).offset(x = 8.dp, y = 16.dp).size(100.dp),
            tint = OnBanner.copy(alpha = 0.1f)
        )
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(CircleShape)
                    .background(OnBanner.copy(alpha = 0.2f))
                    .border(1.dp, OnBanner.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.CalendarMonth, contentDescription = null, tint = OnBanner, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text(tanggal, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = OnBanner.copy(alpha = 0.85f))
                Text(waktu, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = OnBanner)
            }
        }
    }
}

@Composable
private fun RekapRow(hariIni: List<AgendaView>) {
    val durasi = hariIni.sumOf { it.selesai - it.mulai } / 60.0
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.EventAvailable, contentDescription = null, tint = MdOnPrimaryContainer, modifier = Modifier.size(28.dp))
                Spacer(Modifier.height(4.dp))
                Text("${hariIni.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                Text("KEGIATAN", fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp, color = MdOnPrimaryContainer.copy(alpha = 0.8f))
            }
        }
        Card(
            Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MdSecondaryContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Timer, contentDescription = null, tint = MdTertiary, modifier = Modifier.size(28.dp))
                Spacer(Modifier.height(4.dp))
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold)) { append(Fmt.desimal(durasi)) }
                        withStyle(SpanStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium)) { append("J") }
                    },
                    color = Gray800
                )
                Text("DURASI", fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp, color = Gray600)
            }
        }
    }
}

// ------------------------------------------------------------------ kartu agenda
@Composable
fun AgendaCard(a: AgendaView, tampilTanggal: Boolean, onMore: () -> Unit) {
    val total = a.hadir + a.sakit + a.izin + a.alpa
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(8.dp), color = MdSecondaryContainer) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Schedule, contentDescription = null, tint = MdOnSurface, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(Fmt.rentang(a.mulai, a.selesai), fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MdOnSurface)
                    }
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onMore, modifier = Modifier.size(32.dp).offset(x = 8.dp)) {
                    Icon(Icons.Outlined.MoreVert, contentDescription = "Opsi", tint = Gray500)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(a.kelasNama, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MdOnSurface)
            Spacer(Modifier.height(2.dp))
            Text(
                if (tampilTanggal) a.mapelNama + " • " + Fmt.tanggal(a.tanggal, "EEEE, d MMM yyyy") else a.mapelNama,
                fontSize = 12.sp, color = Gray500
            )
            Spacer(Modifier.height(12.dp))
            Text("Topik Pembelajaran:", fontSize = 12.sp, color = Gray500)
            Spacer(Modifier.height(4.dp))
            Text(a.topik, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Gray800)
            if (a.catatan.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("Catatan: " + a.catatan, fontSize = 12.sp, color = Gray500)
            }
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = MdSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            if (total == 0) {
                Text(
                    "Presensi belum diisi", Modifier.fillMaxWidth(),
                    fontSize = 12.sp, color = Gray500, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat(a.hadir, "Hadir", MdPrimary)
                    Stat(a.sakit, "Sakit", MdError)
                    Stat(a.izin, "Izin", MdTertiary)
                    Stat(a.alpa, "Alpa", AlpaRed)
                }
            }
        }
    }
}

@Composable
fun Stat(value: Int, label: String, color: Color) = StatText("$value", label, color)

@Composable
fun StatText(value: String, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Gray600)
    }
}

// ------------------------------------------------------------------ tab Agenda
@Composable
fun AgendaTab(vm: MainViewModel, push: (Route) -> Unit, tambahAgenda: () -> Unit) {
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    val mapel by vm.mapel.collectAsState()
    val agenda by vm.agenda.collectAsState()
    var kelasId by remember { mutableLongStateOf(0L) }
    var mapelId by remember { mutableLongStateOf(0L) }
    var menu by remember { mutableStateOf<AgendaView?>(null) }

    val semuaKelas = Pil(0L, "Semua Kelas")
    val semuaMapel = Pil(0L, "Semua Mata Pelajaran")
    val opsiKelas = listOf(semuaKelas) + kelas.map { Pil(it.id, it.nama) }
    val kelasPilih = opsiKelas.firstOrNull { it.id == kelasId } ?: semuaKelas
    val mapelUntuk = if (kelasPilih.id == 0L) mapel else mapel.filter { m -> m.kelas.any { it.kelasId == kelasPilih.id } }
    val opsiMapel = listOf(semuaMapel) + mapelUntuk.map { Pil(it.id, it.nama) }
    val mapelPilih = opsiMapel.firstOrNull { it.id == mapelId } ?: semuaMapel
    val daftar = agenda.filter {
        (kelasPilih.id == 0L || it.kelasId == kelasPilih.id) && (mapelPilih.id == 0L || it.mapelId == mapelPilih.id)
    }

    Column(Modifier.fillMaxSize()) {
        if (tahun != null && kelas.isNotEmpty()) {
            Column(
                Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PilihField("Kelas", opsiKelas, kelasPilih, { it.nama }, { kelasId = it.id; mapelId = 0L })
                PilihField("Mata Pelajaran", opsiMapel, mapelPilih, { it.nama }, { mapelId = it.id })
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = ListPadding, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (tahun == null) {
                item {
                    KeadaanKosong(
                        icon = Icons.Outlined.CalendarMonth,
                        judul = "Belum ada tahun ajaran",
                        deskripsi = "Buat tahun ajaran terlebih dahulu untuk mulai mencatat agenda mengajar.",
                        labelAksi = "Buat Tahun Ajaran",
                        onAksi = { push(Route.TahunForm(null)) }
                    )
                }
            } else if (agenda.isEmpty()) {
                item {
                    KeadaanKosong(
                        icon = Icons.Outlined.EventBusy,
                        judul = "Belum ada agenda",
                        deskripsi = if (kelas.isEmpty()) "Tambahkan kelas dan mata pelajaran terlebih dahulu dari menu utama, lalu catat agenda mengajar."
                        else "Ketuk tombol di bawah untuk mencatat agenda mengajar pertama Anda.",
                        labelAksi = "Tambah Agenda",
                        onAksi = tambahAgenda
                    )
                }
            } else if (daftar.isEmpty()) {
                item {
                    KeadaanKosong(
                        icon = Icons.Outlined.EventBusy,
                        judul = "Tidak ada agenda",
                        deskripsi = "Belum ada agenda untuk kelas dan mata pelajaran yang dipilih."
                    )
                }
            } else {
                items(daftar, key = { it.id }) { a -> AgendaCard(a, true) { menu = a } }
            }
        }
    }
    AgendaAksi(vm, menu, push) { menu = null }
}

// ------------------------------------------------------------------ tab Laporan
private fun bukaFile(ctx: Context, h: HasilLaporan) {
    val uri = h.uri ?: return
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, h.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        ctx.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        ctx.toast("Tidak ada aplikasi untuk membuka file ini")
    }
}

@Composable
fun LaporanTab(vm: MainViewModel, push: (Route) -> Unit) {
    val ctx = LocalContext.current
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    val mapel by vm.mapel.collectAsState()
    val agenda by vm.agenda.collectAsState()
    val versi by vm.versi.collectAsState()
    var jenis by remember { mutableStateOf("Agenda") }
    var kelasId by remember { mutableLongStateOf(-1L) }
    var mapelId by remember { mutableLongStateOf(-1L) }
    var periodeIdx by remember(tahun?.id) { mutableIntStateOf(0) }
    var sedang by remember { mutableStateOf(false) }
    var hasil by remember { mutableStateOf<HasilLaporan?>(null) }
    val mintaIzin = rememberMintaIzinSimpan()
    val th = tahun

    if (th == null) {
        KeadaanKosong(
            icon = Icons.Outlined.CalendarMonth,
            judul = "Belum ada tahun ajaran",
            deskripsi = "Buat tahun ajaran terlebih dahulu. Laporan dibuat dari data tahun ajaran yang aktif.",
            modifier = Modifier.fillMaxSize(),
            labelAksi = "Buat Tahun Ajaran",
            onAksi = { push(Route.TahunForm(null)) }
        )
    } else if (kelas.isEmpty()) {
        KeadaanKosong(
            icon = Icons.Outlined.Class,
            judul = "Belum ada kelas",
            deskripsi = "Tambahkan kelas, siswa, dan mata pelajaran terlebih dahulu agar laporan dapat dibuat.",
            modifier = Modifier.fillMaxSize(),
            labelAksi = "Tambah Kelas",
            onAksi = { push(Route.KelasForm(null)) }
        )
    } else {
        val kelasPilih = kelas.firstOrNull { it.id == kelasId } ?: kelas.first()
        val opsiMapel = mapel.filter { m -> m.kelas.any { it.kelasId == kelasPilih.id } }
        val mapelPilih = opsiMapel.firstOrNull { it.id == mapelId } ?: opsiMapel.firstOrNull()
        val periodeList = remember(th) { daftarPeriode(th) }
        val periodePilih = periodeList.getOrNull(periodeIdx) ?: periodeList.first()

        val terfilter = agenda.filter { a ->
            a.kelasId == kelasPilih.id && a.mapelId == mapelPilih?.id &&
                a.tanggal >= periodePilih.dari && a.tanggal <= periodePilih.sampai
        }
        val totalPresensi = terfilter.sumOf { it.hadir + it.sakit + it.izin + it.alpa }
        val persenHadir = if (totalPresensi == 0) "-" else "${(terfilter.sumOf { it.hadir } * 100.0 / totalPresensi).roundToInt()}%"
        val stat by produceState<Pair<Int, Double?>>(Pair(0, null), kelasPilih.id, mapelPilih?.id, versi) {
            value = if (mapelPilih != null) vm.statNilai(kelasPilih.id, mapelPilih.id) else Pair(0, null)
        }

        Column(Modifier.fillMaxSize()) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SegmentedField("Jenis Laporan", listOf("Agenda", "Penilaian"), jenis) { jenis = it }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (jenis == "Agenda") {
                        StatCard(Icons.Outlined.CalendarMonth, "Pertemuan", "${terfilter.size}", Modifier.weight(1f))
                        StatCard(Icons.Outlined.HowToReg, "Rata-rata hadir", persenHadir, Modifier.weight(1f))
                    } else {
                        StatCard(Icons.Outlined.Grade, "Penilaian", "${stat.first}", Modifier.weight(1f))
                        StatCard(Icons.Outlined.BarChart, "Rata-rata nilai", stat.second?.let { Fmt.desimal(it) } ?: "-", Modifier.weight(1f))
                    }
                }
                Text("Filter laporan", fontWeight = FontWeight.SemiBold, color = Gray800)
                PilihField("Kelas", kelas, kelasPilih, { it.nama }, { kelasId = it.id; mapelId = -1L })
                PilihField(
                    "Mata Pelajaran", opsiMapel, mapelPilih, { it.nama }, { mapelId = it.id },
                    error = if (opsiMapel.isEmpty()) "Kelas ini belum memiliki mata pelajaran" else null,
                    kosong = "Belum ada mata pelajaran"
                )
                if (jenis == "Agenda") {
                    PilihField("Periode", periodeList, periodePilih, { it.label }, { periodeIdx = periodeList.indexOf(it) })
                }
            }
            Button(
                onClick = {
                    if (mapelPilih == null) {
                        ctx.toast("Pilih kelas dan mata pelajaran terlebih dahulu")
                    } else {
                        mintaIzin {
                            sedang = true
                            vm.buatLaporan(jenis, kelasPilih, mapelPilih, if (jenis == "Agenda") periodePilih else null) { h ->
                                sedang = false
                                hasil = h
                            }
                        }
                    }
                },
                enabled = !sedang && mapelPilih != null,
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 16.dp).height(52.dp)
            ) {
                if (sedang) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = OnPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Membuat laporan...")
                } else {
                    Icon(Icons.Outlined.IosShare, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Buat Laporan")
                }
            }
        }
    }

    hasil?.let { h ->
        val bisaBuka = h.sukses && h.uri != null
        InfoDialog(
            judul = if (h.sukses) "Laporan berhasil dibuat" else "Laporan belum dapat dibuat",
            pesan = h.pesan,
            onTutup = { hasil = null },
            aksi = if (bisaBuka) "Buka" else null,
            onAksi = if (bisaBuka) ({ bukaFile(ctx, h); hasil = null }) else null
        )
    }
}

@Composable
private fun StatCard(icon: ImageVector, label: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(CardBg.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MdPrimary, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
            Text(label, fontSize = 12.sp, color = Gray600)
        }
    }
}
