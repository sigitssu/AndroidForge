package id.gurukelas.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "classes", indices = [Index(value = ["name"], unique = true)])
data class SchoolClass(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(
    tableName = "students",
    indices = [Index(value = ["studentNumber"], unique = true)]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentNumber: String,
    val fullName: String,
    val classId: Long,
    val gender: String
)

@Entity(
    tableName = "attendance",
    indices = [Index(value = ["studentId", "date"], unique = true)]
)
data class Attendance(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val date: String,
    val status: String
)

@Entity(tableName = "teaching_agenda")
data class TeachingAgenda(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val className: String,
    val subject: String,
    val topic: String,
    val activity: String,
    val reflection: String = ""
)

data class StudentAttendance(
    val studentId: Long,
    val studentNumber: String,
    val fullName: String,
    val gender: String,
    val status: String?
)

data class AttendanceReportRow(
    val date: String,
    val studentNumber: String,
    val fullName: String,
    val className: String,
    val status: String
)

@Dao
interface SchoolDao {
    @Query("SELECT * FROM classes ORDER BY name")
    fun observeClasses(): Flow<List<SchoolClass>>

    @Query("SELECT * FROM students ORDER BY fullName")
    fun observeStudents(): Flow<List<Student>>

    @Query("SELECT * FROM classes WHERE name = :name LIMIT 1")
    suspend fun classByName(name: String): SchoolClass?

    @Query("SELECT * FROM students WHERE studentNumber = :nis LIMIT 1")
    suspend fun studentByNis(nis: String): Student?

    @Query("SELECT * FROM students WHERE classId = :classId ORDER BY fullName")
    suspend fun studentsInClass(classId: Long): List<Student>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addClass(item: SchoolClass): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addStudent(item: Student): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAttendance(item: Attendance)

    @Insert
    suspend fun addAgenda(item: TeachingAgenda): Long

    @Query("SELECT * FROM attendance WHERE date BETWEEN :fromDate AND :toDate ORDER BY date")
    suspend fun attendanceBetween(fromDate: String, toDate: String): List<Attendance>

    @Query("""
        SELECT attendance.date AS date, students.studentNumber AS studentNumber,
        students.fullName AS fullName, classes.name AS className, attendance.status AS status
        FROM attendance
        INNER JOIN students ON students.id = attendance.studentId
        INNER JOIN classes ON classes.id = students.classId
        WHERE attendance.date BETWEEN :fromDate AND :toDate
        ORDER BY attendance.date, classes.name, students.fullName
    """)
    suspend fun attendanceReportRows(fromDate: String, toDate: String): List<AttendanceReportRow>

    @Query("SELECT * FROM teaching_agenda WHERE date BETWEEN :fromDate AND :toDate ORDER BY date")
    suspend fun agendasBetween(fromDate: String, toDate: String): List<TeachingAgenda>

    @Query("""
        SELECT students.id AS studentId, students.studentNumber AS studentNumber,
        students.fullName AS fullName, students.gender AS gender,
        attendance.status AS status
        FROM students LEFT JOIN attendance
        ON students.id = attendance.studentId AND attendance.date = :date
        WHERE students.classId = :classId ORDER BY students.fullName
    """)
    suspend fun attendanceForClass(classId: Long, date: String): List<StudentAttendance>
}

@Database(
    entities = [SchoolClass::class, Student::class, Attendance::class, TeachingAgenda::class],
    version = 2,
    exportSchema = false
)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun dao(): SchoolDao

    companion object {
        @Volatile private var instance: SchoolDatabase? = null

        fun get(context: Context): SchoolDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SchoolDatabase::class.java,
                    "gurukelas.db"
                )
                // Starter project has no released user database yet. This destructive migration
                // is acceptable for this prototype only; remove it before production.
                .fallbackToDestructiveMigration()
                .build().also { instance = it }
            }
    }
}
