package id.gurukelas.app

import android.content.ContentValues
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val dao by lazy { SchoolDatabase.get(this).dao() }
    private lateinit var body: LinearLayout
    private val fmt = DateTimeFormatter.ISO_LOCAL_DATE

    private val excelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) lifecycleScope.launch {
            runCatching { ExcelImport.import(contentResolver, uri, dao) }
                .onSuccess { toast(it.message) }
                .onFailure { toast("Impor gagal: ${it.message}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun roundedDrawable(color: Int, radius: Int = 18, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun screen(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(18))
            setBackgroundColor(0xFFF3F6FC.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = roundedDrawable(0xFF173B70.toInt(), 24)
            elevation = dp(3).toFloat()
        }
        header.addView(TextView(this).apply {
            text = "GURUKELAS"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(0xFFBBD4FF.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(2))
        })
        header.addView(TextView(this).apply {
            text = when (title) {
                "GuruKelas" -> "Administrasi kelas jadi lebih mudah"
                "Presensi siswa" -> "Catat kehadiran siswa dengan praktis"
                "Agenda mengajar" -> "Rencanakan dan dokumentasikan pembelajaran"
                else -> "Kelola data dan laporan pembelajaran"
            }
            textSize = 13f
            setTextColor(0xFFDCE7F8.toInt())
        })
        root.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        val scroll = ScrollView(this).apply { clipToPadding = false }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(1), dp(2), dp(1), dp(10))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun text(s: String, size: Float = 16f) {
        body.addView(TextView(this).apply {
            text = s
            textSize = size
            setTextColor(if (size >= 18f) 0xFF173B70.toInt() else 0xFF344054.toInt())
            if (size >= 18f) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(9), dp(4), dp(9))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(3) })
    }

    private fun button(s: String, action: () -> Unit) {
        val isBack = s.contains("Kembali", ignoreCase = true)
        val isPrimary = s.contains("Simpan", ignoreCase = true) ||
            s.contains("Buat", ignoreCase = true) || s.contains("Impor", ignoreCase = true)
        val fill = if (isPrimary) 0xFF2459A9.toInt() else 0xFFFFFFFF.toInt()
        val foreground = if (isPrimary) 0xFFFFFFFF.toInt() else 0xFF204A87.toInt()
        val border = if (isPrimary) null else 0xFFD5E1F2.toInt()
        body.addView(Button(this).apply {
            text = s
            isAllCaps = false
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (isBack) 0xFF667085.toInt() else foreground)
            background = roundedDrawable(if (isBack) 0xFFEDF1F7.toInt() else fill, 16, if (isBack) null else border)
            stateListAnimator = null
            elevation = if (isPrimary) dp(2).toFloat() else 0f
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(dp(16), dp(7), dp(16), dp(7))
            minHeight = dp(52)
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }

    private fun field(h: String, value: String = ""): EditText {
        val e = EditText(this).apply {
            hint = h
            setText(value)
            textSize = 15f
            setTextColor(0xFF101828.toInt())
            setHintTextColor(0xFF98A2B3.toInt())
            background = roundedDrawable(0xFFFFFFFF.toInt(), 14, 0xFFD0D9E8.toInt())
            setPadding(dp(14), dp(11), dp(14), dp(11))
            minHeight = dp(52)
        }
        body.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return e
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun home() {
        screen("GuruKelas")
        text("📚  Administrasi guru • data tersimpan lokal", 15f)
        button("👥  Data kelas dan siswa") { classScreen() }
        button("📥  Impor siswa dari Excel (.xlsx)") { excelPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) }
        button("🗓️  Agenda mengajar") { agendaScreen() }
        button("✅  Presensi siswa") { attendanceScreen() }
        button("📄  Laporan presensi harian") { attendanceReportScreen(false) }
        button("📊  Rekap presensi bulanan") { attendanceReportScreen(true) }
        button("📝  Laporan agenda PDF") { agendaReportScreen() }
        text("Impor Excel: NIS, Nama, Kelas, Jenis Kelamin. Data disimpan lokal di HP. Backup/restore masih perlu ditambahkan.", 13f)
    }

    private fun classScreen() {
        screen("Data kelas")
        val name = field("Nama kelas, misalnya XI TJKT 1")
        button("Simpan kelas") {
            val n = name.text.toString().trim()
            if (n.isBlank()) toast("Nama kelas wajib diisi.") else lifecycleScope.launch {
                dao.addClass(SchoolClass(name = n)); toast("Kelas tersimpan."); classScreen()
            }
        }
        button("📥  Impor siswa dari Excel (.xlsx)") {
            excelPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
        }
        text("Daftar kelas dan siswa:")
        lifecycleScope.launch {
            var rendered = false
            dao.observeClasses().collect { list ->
                if (!rendered) {
                    rendered = true
                    if (list.isEmpty()) text("Belum ada kelas.")
                    list.forEach { c ->
                        text("KELAS: ${c.name}", 18f)
                    }
                }
            }
        }
        lifecycleScope.launch {
            var rendered = false
            dao.observeStudents().collect { list ->
                if (!rendered) {
                    rendered = true
                    list.forEach { s ->
                        text("${s.studentNumber} • ${s.fullName} • ${s.gender}", 14f)
                    }
                }
            }
        }
        button("Kembali") { home() }
    }

    private fun attendanceScreen() {
        screen("Presensi siswa")
        val date = field("Tanggal (YYYY-MM-DD)", LocalDate.now().format(fmt))
        val classSpinner = Spinner(this)
        body.addView(classSpinner)
        val statusRows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(statusRows)
        var classes: List<SchoolClass> = emptyList()
        var loadedClassId: Long? = null
        var loadedDate: String? = null
        val rowSpinners = linkedMapOf<Long, Spinner>()
        lifecycleScope.launch {
            dao.observeClasses().collect { list ->
                classes = list
                classSpinner.adapter = ArrayAdapter(this@MainActivity,
                    android.R.layout.simple_spinner_dropdown_item, list.map { it.name })
            }
        }
        button("Muat daftar siswa") {
            val d = date.text.toString().trim()
            if (runCatching { LocalDate.parse(d) }.isFailure) { toast("Format tanggal harus YYYY-MM-DD."); return@button }
            if (classes.isEmpty() || classSpinner.selectedItemPosition !in classes.indices) { toast("Tambahkan kelas atau impor siswa terlebih dahulu."); return@button }
            val selectedClass = classes[classSpinner.selectedItemPosition]
            lifecycleScope.launch {
                val students = dao.attendanceForClass(selectedClass.id, d)
                statusRows.removeAllViews(); rowSpinners.clear(); loadedClassId = selectedClass.id; loadedDate = d
                if (students.isEmpty()) { text("Belum ada siswa di kelas ini."); return@launch }
                students.forEach { student ->
                    val row = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(0, 8, 0, 8)
                    }
                    row.addView(TextView(this@MainActivity).apply {
                        text = "${student.studentNumber} • ${student.fullName}"
                        textSize = 15f; setTextColor(0xFF243247.toInt())
                    })
                    val spinner = Spinner(this@MainActivity)
                    spinner.adapter = ArrayAdapter(this@MainActivity,
                        android.R.layout.simple_spinner_dropdown_item, listOf("Hadir", "Sakit", "Izin", "Alpa"))
                    val choices = listOf("Hadir", "Sakit", "Izin", "Alpa")
                    spinner.setSelection(choices.indexOf(student.status).takeIf { it >= 0 } ?: 0)
                    row.addView(spinner); statusRows.addView(row); rowSpinners[student.studentId] = spinner
                }
                text("${students.size} siswa dimuat. Pilih status setiap siswa lalu simpan.")
            }
        }
        button("Simpan presensi") {
            val d = date.text.toString().trim()
            if (runCatching { LocalDate.parse(d) }.isFailure) { toast("Format tanggal harus YYYY-MM-DD."); return@button }
            if (loadedClassId == null || rowSpinners.isEmpty()) { toast("Muat daftar siswa terlebih dahulu."); return@button }
            if (loadedDate != d || classes.getOrNull(classSpinner.selectedItemPosition)?.id != loadedClassId) {
                toast("Tanggal atau kelas berubah. Muat ulang daftar siswa sebelum menyimpan."); return@button
            }
            lifecycleScope.launch {
                rowSpinners.forEach { (studentId, spinner) ->
                    dao.saveAttendance(Attendance(studentId = studentId, date = d,
                        status = spinner.selectedItem.toString()))
                }
                toast("Presensi ${rowSpinners.size} siswa tanggal $d berhasil disimpan.")
            }
        }
        button("Kembali") { home() }
    }

    private fun attendanceReportScreen(monthly: Boolean) {
        screen(if (monthly) "Rekap presensi bulanan" else "Laporan presensi harian")
        val defaultDate = LocalDate.now()
        val date = field(if (monthly) "Bulan (YYYY-MM)" else "Tanggal (YYYY-MM-DD)",
            if (monthly) defaultDate.format(DateTimeFormatter.ofPattern("yyyy-MM")) else defaultDate.format(fmt))
        button("Buat PDF") {
            val input = date.text.toString().trim()
            val range = runCatching {
                if (monthly) {
                    val first = java.time.YearMonth.parse(input)
                    first.atDay(1).format(fmt) to first.atEndOfMonth().format(fmt)
                } else {
                    val day = LocalDate.parse(input); day.format(fmt) to day.format(fmt)
                }
            }.getOrNull()
            if (range == null) { toast(if (monthly) "Gunakan format YYYY-MM." else "Gunakan format YYYY-MM-DD."); return@button }
            lifecycleScope.launch {
                runCatching { makeAttendancePdf(range.first, range.second, monthly, dao.attendanceReportRows(range.first, range.second)) }
                    .onSuccess { toast("PDF tersimpan: Download/GuruKelas/$it") }
                    .onFailure { toast("Gagal membuat PDF: ${it.message}") }
            }
        }
        button("Kembali") { home() }
    }

    private fun makeAttendancePdf(from: String, to: String, monthly: Boolean,
                                  rows: List<AttendanceReportRow>): String {
        val doc = PdfDocument()
        val groups: List<Pair<String, List<AttendanceReportRow>>> = if (monthly)
            rows.groupBy { it.date }.toSortedMap().map { it.key to it.value }
        else listOf(from to rows)
        val chunks: List<List<Pair<String, List<AttendanceReportRow>>>> = if (groups.isEmpty()) listOf(emptyList()) else groups.chunked(4)
        var pageNumber = 1
        chunks.forEach { chunk ->
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber++).create())
            val paint = Paint().apply { color = android.graphics.Color.BLACK }
            var y = 42f
            fun line(s: String, bold: Boolean = false) {
                paint.textSize = if (bold) 15f else 10f; paint.isFakeBoldText = bold
                page.canvas.drawText(s.take(95), 36f, y, paint); y += if (bold) 24f else 16f
            }
            line(if (monthly) "REKAP PRESENSI BULANAN" else "LAPORAN PRESENSI HARIAN", true)
            line("Periode: $from s.d. $to")
            if (rows.isEmpty()) line("Belum ada data presensi untuk periode ini.")
            chunk.forEach { group ->
                val dayRows = group.second
                if (monthly) { y += 5; line("Tanggal: ${group.first}", true) }
                val counts = dayRows.groupingBy { it.status }.eachCount()
                line("Hadir ${counts["Hadir"] ?: 0} | Sakit ${counts["Sakit"] ?: 0} | Izin ${counts["Izin"] ?: 0} | Alpa ${counts["Alpa"] ?: 0}")
                dayRows.forEach { r -> line("${r.className} | ${r.studentNumber} | ${r.fullName} | ${r.status}") }
                y += 8
            }
            doc.finishPage(page)
        }
        val filename = "Presensi_${if (monthly) from.substring(0,7) else from}.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/GuruKelas")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Tidak dapat membuat file PDF")
        contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Gagal menulis PDF")
        doc.close(); return filename
    }

    private fun agendaReportScreen() {
        screen("Laporan agenda PDF")
        val from = field("Tanggal awal (YYYY-MM-DD)", LocalDate.now().withDayOfMonth(1).format(fmt))
        val to = field("Tanggal akhir (YYYY-MM-DD)", LocalDate.now().format(fmt))
        button("Buat laporan agenda") {
            val f = from.text.toString().trim(); val t = to.text.toString().trim()
            if (runCatching { LocalDate.parse(f); LocalDate.parse(t) }.isFailure || f > t) {
                toast("Rentang tanggal tidak valid."); return@button
            }
            lifecycleScope.launch {
                runCatching { makeAgendaPdf(f, t, dao.agendasBetween(f, t)) }
                    .onSuccess { toast("PDF tersimpan: Download/GuruKelas/$it") }
                    .onFailure { toast("Gagal membuat PDF: ${it.message}") }
            }
        }
        button("Kembali") { home() }
    }

    private fun makeAgendaPdf(from: String, to: String, agendas: List<TeachingAgenda>): String {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val paint = Paint().apply { color = android.graphics.Color.BLACK }
        var y = 48f
        fun line(s: String, bold: Boolean = false) {
            paint.textSize = if (bold) 16f else 11f; paint.isFakeBoldText = bold
            page.canvas.drawText(s.take(90), 40f, y, paint); y += if (bold) 26f else 18f
        }
        line("LAPORAN AGENDA MENGAJAR", true); line("Periode: $from sampai $to"); y += 8
        if (agendas.isEmpty()) line("Tidak ada agenda pada periode ini.")
        agendas.take(30).forEach { a ->
            line("${a.date} | ${a.className} | ${a.subject}", true)
            line("Materi: ${a.topic}")
            if (a.activity.isNotBlank()) line("Kegiatan: ${a.activity}")
            if (a.reflection.isNotBlank()) line("Refleksi: ${a.reflection}")
            y += 6
        }
        doc.finishPage(page)
        val filename = "Agenda_${from}_$to.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename); put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/GuruKelas")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Tidak dapat membuat file PDF")
        contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Gagal menulis PDF")
        doc.close(); return filename
    }

    private fun agendaScreen() {
        screen("Agenda mengajar")
        val date = field("Tanggal (YYYY-MM-DD)", LocalDate.now().format(fmt))
        val cls = field("Kelas")
        val subject = field("Mata pelajaran")
        val topic = field("Materi / topik")
        val activity = field("Kegiatan pembelajaran")
        val reflection = field("Refleksi (opsional)")
        button("Simpan agenda") {
            val d = date.text.toString().trim()
            val c = cls.text.toString().trim()
            val s = subject.text.toString().trim()
            val t = topic.text.toString().trim()
            if (runCatching { LocalDate.parse(d) }.isFailure || c.isBlank() || s.isBlank() || t.isBlank()) {
                toast("Tanggal, kelas, mata pelajaran, dan materi wajib diisi.")
            } else lifecycleScope.launch {
                dao.addAgenda(TeachingAgenda(
                    date = d,
                    className = c,
                    subject = s,
                    topic = t,
                    activity = activity.text.toString().trim(),
                    reflection = reflection.text.toString().trim()
                ))
                toast("Agenda tersimpan."); home()
            }
        }
        button("Kembali") { home() }
    }

    private fun reportScreen() {
        screen("Laporan PDF")
        val from = field("Tanggal awal (YYYY-MM-DD)", LocalDate.now().withDayOfMonth(1).format(fmt))
        val to = field("Tanggal akhir (YYYY-MM-DD)", LocalDate.now().format(fmt))
        button("Buat laporan PDF") {
            val f = from.text.toString().trim(); val t = to.text.toString().trim()
            if (runCatching { LocalDate.parse(f); LocalDate.parse(t) }.isFailure || f > t) {
                toast("Rentang tanggal tidak valid.")
            } else lifecycleScope.launch {
                runCatching { makePdf(f, t, dao.attendanceBetween(f, t), dao.agendasBetween(f, t)) }
                    .onSuccess { toast("PDF tersimpan: Download/GuruKelas/$it") }
                    .onFailure { toast("Gagal membuat PDF: ${it.message}") }
            }
        }
        button("Kembali") { home() }
    }

    private fun makePdf(from: String, to: String, attendance: List<Attendance>,
                        agendas: List<TeachingAgenda>): String {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val paint = Paint().apply { color = android.graphics.Color.BLACK }
        var y = 48f
        fun line(s: String, bold: Boolean = false) {
            paint.textSize = if (bold) 16f else 11f; paint.isFakeBoldText = bold
            page.canvas.drawText(s.take(90), 40f, y, paint); y += if (bold) 26f else 18f
        }
        line("LAPORAN GURUKELAS", true); line("Periode: $from sampai $to")
        y += 8; line("RINGKASAN PRESENSI", true)
        val counts = attendance.groupingBy { it.status }.eachCount()
        listOf("Hadir", "Sakit", "Izin", "Alpa").forEach { line("$it: ${counts[it] ?: 0}") }
        y += 8; line("AGENDA MENGAJAR", true)
        if (agendas.isEmpty()) line("Tidak ada agenda pada periode ini.")
        agendas.take(25).forEach {
            line("${it.date} | ${it.className} | ${it.subject}")
            line("Materi: ${it.topic}")
            if (it.activity.isNotBlank()) line("Kegiatan: ${it.activity}")
        }
        doc.finishPage(page)
        val filename = "GuruKelas_${from}_$to.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, filename)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/GuruKelas")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Tidak dapat membuat file PDF")
        contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Gagal menulis PDF")
        doc.close()
        return filename
    }
}
