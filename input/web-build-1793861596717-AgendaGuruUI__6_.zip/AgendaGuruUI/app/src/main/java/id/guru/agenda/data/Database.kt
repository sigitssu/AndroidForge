package id.guru.agenda.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.time.LocalDate

// ----------------------------------------------------------------- Entitas
@Entity(tableName = "profil")
data class Profil(
    @PrimaryKey val id: Int = 1,
    val nama: String,
    val nip: String,
    val sekolah: String,
    val fotoPath: String? = null
)

/** awal & akhir disimpan sebagai epoch day (jumlah hari sejak 1970-01-01). */
@Entity(tableName = "tahun_ajaran")
data class TahunAjaran(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val awal: Long,
    val akhir: Long,
    val semester: String,
    val aktif: Boolean = false
)

fun TahunAjaran.label(): String {
    val th = LocalDate.ofEpochDay(awal).year
    return if (semester == "Ganjil") "$th/${th + 1} - $semester" else "${th - 1}/$th - $semester"
}

@Entity(
    tableName = "kelas",
    foreignKeys = [ForeignKey(entity = TahunAjaran::class, parentColumns = ["id"], childColumns = ["tahunId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tahunId")]
)
data class Kelas(@PrimaryKey(autoGenerate = true) val id: Long = 0, val tahunId: Long, val nama: String)

@Entity(
    tableName = "siswa",
    foreignKeys = [ForeignKey(entity = Kelas::class, parentColumns = ["id"], childColumns = ["kelasId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["kelasId", "nis"], unique = true)]
)
data class Siswa(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kelasId: Long,
    val nis: String,
    val nama: String,
    val jk: String
)

@Entity(
    tableName = "mapel",
    foreignKeys = [ForeignKey(entity = TahunAjaran::class, parentColumns = ["id"], childColumns = ["tahunId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tahunId")]
)
data class Mapel(@PrimaryKey(autoGenerate = true) val id: Long = 0, val tahunId: Long, val nama: String)

@Entity(
    tableName = "mapel_kelas",
    primaryKeys = ["mapelId", "kelasId"],
    foreignKeys = [
        ForeignKey(entity = Mapel::class, parentColumns = ["id"], childColumns = ["mapelId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Kelas::class, parentColumns = ["id"], childColumns = ["kelasId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("kelasId")]
)
data class MapelKelas(val mapelId: Long, val kelasId: Long)

/** mulai & selesai disimpan sebagai menit sejak 00:00. */
@Entity(
    tableName = "agenda",
    foreignKeys = [
        ForeignKey(entity = Kelas::class, parentColumns = ["id"], childColumns = ["kelasId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Mapel::class, parentColumns = ["id"], childColumns = ["mapelId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("kelasId"), Index("mapelId")]
)
data class Agenda(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kelasId: Long,
    val mapelId: Long,
    val tanggal: Long,
    val mulai: Int,
    val selesai: Int,
    val topik: String,
    val catatan: String = ""
)

/** status: Hadir / Sakit / Izin / Alpa */
@Entity(
    tableName = "presensi",
    foreignKeys = [
        ForeignKey(entity = Agenda::class, parentColumns = ["id"], childColumns = ["agendaId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Siswa::class, parentColumns = ["id"], childColumns = ["siswaId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index(value = ["agendaId", "siswaId"], unique = true), Index("siswaId")]
)
data class Presensi(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agendaId: Long,
    val siswaId: Long,
    val status: String
)

/** Satu item daftar nilai, mis. "Tugas 1", "UTS". */
@Entity(
    tableName = "nilai",
    foreignKeys = [
        ForeignKey(entity = Kelas::class, parentColumns = ["id"], childColumns = ["kelasId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Mapel::class, parentColumns = ["id"], childColumns = ["mapelId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("kelasId"), Index("mapelId")]
)
data class Nilai(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kelasId: Long,
    val mapelId: Long,
    val nama: String
)

@Entity(
    tableName = "nilai_siswa",
    foreignKeys = [
        ForeignKey(entity = Nilai::class, parentColumns = ["id"], childColumns = ["nilaiId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Siswa::class, parentColumns = ["id"], childColumns = ["siswaId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index(value = ["nilaiId", "siswaId"], unique = true), Index("siswaId")]
)
data class NilaiSiswa(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nilaiId: Long,
    val siswaId: Long,
    val skor: Double
)

// ----------------------------------------------------------------- Tampilan hasil query
data class KelasView(val id: Long, val tahunId: Long, val nama: String, val jumlah: Int)
data class MapelKelasRow(val mapelId: Long, val kelasId: Long, val kelasNama: String)
data class MapelView(val id: Long, val nama: String, val kelas: List<MapelKelasRow>)
data class NilaiView(val id: Long, val kelasId: Long, val mapelId: Long, val nama: String, val kelasNama: String, val mapelNama: String)
data class PresensiTanggal(val siswaId: Long, val status: String, val tanggal: Long)
data class AgendaView(
    val id: Long, val kelasId: Long, val mapelId: Long, val tanggal: Long,
    val mulai: Int, val selesai: Int, val topik: String, val catatan: String,
    val kelasNama: String, val mapelNama: String,
    val hadir: Int, val sakit: Int, val izin: Int, val alpa: Int
)

const val AGENDA_SELECT =
    "SELECT a.id AS id, a.kelasId AS kelasId, a.mapelId AS mapelId, a.tanggal AS tanggal, a.mulai AS mulai, " +
        "a.selesai AS selesai, a.topik AS topik, a.catatan AS catatan, k.nama AS kelasNama, m.nama AS mapelNama, " +
        "(SELECT COUNT(*) FROM presensi p WHERE p.agendaId = a.id AND p.status = 'Hadir') AS hadir, " +
        "(SELECT COUNT(*) FROM presensi p WHERE p.agendaId = a.id AND p.status = 'Sakit') AS sakit, " +
        "(SELECT COUNT(*) FROM presensi p WHERE p.agendaId = a.id AND p.status = 'Izin') AS izin, " +
        "(SELECT COUNT(*) FROM presensi p WHERE p.agendaId = a.id AND p.status = 'Alpa') AS alpa " +
        "FROM agenda a JOIN kelas k ON k.id = a.kelasId JOIN mapel m ON m.id = a.mapelId "

// ----------------------------------------------------------------- DAO
@Dao
interface AppDao {
    // Profil
    @Query("SELECT * FROM profil WHERE id = 1") fun profil(): Flow<Profil?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun simpanProfil(p: Profil)

    // Tahun ajaran
    @Query("SELECT * FROM tahun_ajaran ORDER BY awal DESC, id DESC") fun semuaTahun(): Flow<List<TahunAjaran>>
    @Query("SELECT * FROM tahun_ajaran ORDER BY awal DESC, id DESC") suspend fun semuaTahunOnce(): List<TahunAjaran>
    @Query("SELECT * FROM tahun_ajaran WHERE aktif = 1 LIMIT 1") fun tahunAktif(): Flow<TahunAjaran?>
    @Query("SELECT * FROM tahun_ajaran ORDER BY awal DESC, id DESC LIMIT 1") suspend fun tahunTerbaru(): TahunAjaran?
    @Insert suspend fun insertTahun(t: TahunAjaran): Long
    @Update suspend fun updateTahun(t: TahunAjaran)
    @Delete suspend fun deleteTahun(t: TahunAjaran)
    @Query("UPDATE tahun_ajaran SET aktif = 0") suspend fun nonaktifkanSemua()
    @Query("UPDATE tahun_ajaran SET aktif = 1 WHERE id = :id") suspend fun aktifkan(id: Long)
    @Query(
        "SELECT COUNT(*) FROM agenda a JOIN kelas k ON k.id = a.kelasId " +
            "WHERE k.tahunId = :t AND (a.tanggal < :awal OR a.tanggal > :akhir)"
    )
    suspend fun hitungAgendaDiLuar(t: Long, awal: Long, akhir: Long): Int

    // Kelas
    @Query(
        "SELECT k.id AS id, k.tahunId AS tahunId, k.nama AS nama, " +
            "(SELECT COUNT(*) FROM siswa s WHERE s.kelasId = k.id) AS jumlah " +
            "FROM kelas k WHERE k.tahunId = :t ORDER BY k.nama COLLATE NOCASE"
    )
    fun kelas(t: Long): Flow<List<KelasView>>
    @Insert suspend fun insertKelas(k: Kelas): Long
    @Update suspend fun updateKelas(k: Kelas)
    @Query("DELETE FROM kelas WHERE id = :id") suspend fun hapusKelas(id: Long)
    @Query("SELECT COUNT(*) FROM kelas WHERE tahunId = :t AND LOWER(nama) = LOWER(:nama) AND id != :kecuali")
    suspend fun hitungKelasNama(t: Long, nama: String, kecuali: Long): Int

    // Siswa
    @Query("SELECT * FROM siswa WHERE kelasId = :k ORDER BY nama COLLATE NOCASE") fun siswa(k: Long): Flow<List<Siswa>>
    @Query("SELECT * FROM siswa WHERE kelasId = :k ORDER BY nama COLLATE NOCASE") suspend fun siswaOnce(k: Long): List<Siswa>
    @Query("SELECT * FROM siswa WHERE kelasId = :k AND nis = :nis LIMIT 1") suspend fun siswaByNis(k: Long, nis: String): Siswa?
    @Insert suspend fun insertSiswa(s: Siswa): Long
    @Update suspend fun updateSiswa(s: Siswa)
    @Query("DELETE FROM siswa WHERE id = :id") suspend fun hapusSiswa(id: Long)

    // Mata pelajaran
    @Query("SELECT * FROM mapel WHERE tahunId = :t ORDER BY nama COLLATE NOCASE") fun mapel(t: Long): Flow<List<Mapel>>
    @Query(
        "SELECT mk.mapelId AS mapelId, mk.kelasId AS kelasId, k.nama AS kelasNama " +
            "FROM mapel_kelas mk JOIN kelas k ON k.id = mk.kelasId WHERE k.tahunId = :t ORDER BY k.nama COLLATE NOCASE"
    )
    fun mapelKelas(t: Long): Flow<List<MapelKelasRow>>
    @Insert suspend fun insertMapel(m: Mapel): Long
    @Update suspend fun updateMapel(m: Mapel)
    @Query("DELETE FROM mapel WHERE id = :id") suspend fun hapusMapel(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertMapelKelas(list: List<MapelKelas>)
    @Query("DELETE FROM mapel_kelas WHERE mapelId = :id") suspend fun hapusMapelKelas(id: Long)
    @Query("SELECT COUNT(*) FROM mapel WHERE tahunId = :t AND LOWER(nama) = LOWER(:nama) AND id != :kecuali")
    suspend fun hitungMapelNama(t: Long, nama: String, kecuali: Long): Int
    @Query(
        "SELECT (SELECT COUNT(*) FROM agenda WHERE mapelId = :m AND kelasId = :k) + " +
            "(SELECT COUNT(*) FROM nilai WHERE mapelId = :m AND kelasId = :k)"
    )
    suspend fun hitungDataMapelKelas(m: Long, k: Long): Int

    // Agenda & presensi
    @Query(AGENDA_SELECT + "WHERE k.tahunId = :t ORDER BY a.tanggal DESC, a.mulai DESC") fun agenda(t: Long): Flow<List<AgendaView>>
    @Query(AGENDA_SELECT + "WHERE a.kelasId = :k AND a.mapelId = :m AND a.tanggal BETWEEN :dari AND :sampai ORDER BY a.tanggal, a.mulai")
    suspend fun agendaLaporan(k: Long, m: Long, dari: Long, sampai: Long): List<AgendaView>
    @Insert suspend fun insertAgenda(a: Agenda): Long
    @Update suspend fun updateAgenda(a: Agenda)
    @Query("DELETE FROM agenda WHERE id = :id") suspend fun hapusAgenda(id: Long)
    @Query("SELECT COUNT(*) FROM agenda WHERE kelasId = :k AND tanggal = :tgl AND id != :kecuali AND mulai < :selesai AND selesai > :mulai")
    suspend fun hitungBentrok(k: Long, tgl: Long, kecuali: Long, mulai: Int, selesai: Int): Int

    @Query("SELECT * FROM presensi WHERE agendaId = :a") suspend fun presensi(a: Long): List<Presensi>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun simpanPresensi(list: List<Presensi>)
    @Query(
        "SELECT p.siswaId AS siswaId, p.status AS status, a.tanggal AS tanggal FROM presensi p " +
            "JOIN agenda a ON a.id = p.agendaId WHERE a.kelasId = :k AND a.mapelId = :m AND a.tanggal BETWEEN :dari AND :sampai"
    )
    suspend fun presensiLaporan(k: Long, m: Long, dari: Long, sampai: Long): List<PresensiTanggal>

    // Nilai
    @Query(
        "SELECT n.id AS id, n.kelasId AS kelasId, n.mapelId AS mapelId, n.nama AS nama, k.nama AS kelasNama, m.nama AS mapelNama " +
            "FROM nilai n JOIN kelas k ON k.id = n.kelasId JOIN mapel m ON m.id = n.mapelId WHERE k.tahunId = :t ORDER BY n.id"
    )
    fun nilai(t: Long): Flow<List<NilaiView>>
    @Insert suspend fun insertNilai(n: Nilai): Long
    @Update suspend fun updateNilai(n: Nilai)
    @Query("DELETE FROM nilai WHERE id = :id") suspend fun hapusNilai(id: Long)
    @Query("SELECT COUNT(*) FROM nilai WHERE kelasId = :k AND mapelId = :m AND LOWER(nama) = LOWER(:nama) AND id != :kecuali")
    suspend fun hitungNilaiNama(k: Long, m: Long, nama: String, kecuali: Long): Int
    @Query("SELECT * FROM nilai WHERE kelasId = :k AND mapelId = :m ORDER BY id") suspend fun nilaiUntuk(k: Long, m: Long): List<Nilai>
    @Query("SELECT * FROM nilai_siswa WHERE nilaiId = :n") suspend fun nilaiSiswa(n: Long): List<NilaiSiswa>
    @Query(
        "SELECT ns.* FROM nilai_siswa ns JOIN nilai n ON n.id = ns.nilaiId WHERE n.kelasId = :k AND n.mapelId = :m"
    )
    suspend fun nilaiSiswaUntuk(k: Long, m: Long): List<NilaiSiswa>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun simpanNilaiSiswa(list: List<NilaiSiswa>)
    @Query("DELETE FROM nilai_siswa WHERE nilaiId = :n AND siswaId = :s") suspend fun hapusNilaiSiswa(n: Long, s: Long)
}

// ----------------------------------------------------------------- Database
@Database(
    entities = [
        Profil::class, TahunAjaran::class, Kelas::class, Siswa::class, Mapel::class, MapelKelas::class,
        Agenda::class, Presensi::class, Nilai::class, NilaiSiswa::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        const val NAMA = "agenda_guru.db"
        const val VERSI = 1
        @Volatile private var inst: AppDatabase? = null

        fun fileDb(ctx: Context): File = ctx.getDatabasePath(NAMA)
        fun filePulihkan(ctx: Context): File = File(ctx.filesDir, "pulihkan.db")

        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: buat(ctx.applicationContext).also { inst = it }
        }

        private fun buat(ctx: Context): AppDatabase {
            terapkanPemulihan(ctx)
            return Room.databaseBuilder(ctx, AppDatabase::class.java, NAMA)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        db.execSQL(
                            "INSERT INTO profil (id, nama, nip, sekolah, fotoPath) " +
                                "VALUES (1, 'Pampam Bamungkas', '1234567890', 'SMK Negeri 1', NULL)"
                        )
                    }
                })
                .build()
        }

        /** Jika ada file hasil pemulihan yang tertunda, tempatkan sebelum database dibuka. */
        private fun terapkanPemulihan(ctx: Context) {
            val sumber = filePulihkan(ctx)
            if (!sumber.exists()) return
            val tujuan = fileDb(ctx)
            tujuan.parentFile?.mkdirs()
            listOf("", "-wal", "-shm", "-journal").forEach { File(tujuan.path + it).delete() }
            sumber.copyTo(tujuan, overwrite = true)
            sumber.delete()
        }
    }
}
