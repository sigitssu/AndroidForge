package id.guru.agenda.util

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import id.guru.agenda.data.AgendaView
import id.guru.agenda.data.PresensiTanggal
import id.guru.agenda.data.Siswa
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.YearMonth

class DataLaporanAgenda(
    val sekolah: String,
    val guru: String,
    val nip: String,
    val tahun: String,
    val kelas: String,
    val mapel: String,
    val periode: String,
    val agenda: List<AgendaView>,
    val siswa: List<Siswa>,
    val presensi: List<PresensiTanggal>
)

private const val LEBAR = 595
private const val TINGGI = 842
private const val TEPI = 40f
private const val PAD = 3f
private const val GARIS_TEKS = 12f

private class Pena(val doc: PdfDocument) {
    var nomor = 0
    lateinit var halaman: PdfDocument.Page
    lateinit var kanvas: Canvas
    var y = TEPI

    val teks = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; color = 0xFF000000.toInt() }
    val tebal = Paint(teks).apply { typeface = Typeface.DEFAULT_BOLD }
    val judul = Paint(tebal).apply { textSize = 15f }
    val bagian = Paint(tebal).apply { textSize = 11f }
    val garis = Paint().apply { color = 0xFF777777.toInt(); strokeWidth = 0.6f; style = Paint.Style.STROKE }
    val latarHeader = Paint().apply { color = 0xFFDDE3F3.toInt(); style = Paint.Style.FILL }

    init { baru() }

    fun baru() {
        if (nomor > 0) doc.finishPage(halaman)
        nomor++
        halaman = doc.startPage(PdfDocument.PageInfo.Builder(LEBAR, TINGGI, nomor).create())
        kanvas = halaman.canvas
        y = TEPI
    }

    fun selesai() { doc.finishPage(halaman) }

    fun pastikan(tinggi: Float) { if (y + tinggi > TINGGI - TEPI) baru() }

    fun baris(t: String, p: Paint = teks, gap: Float = GARIS_TEKS + 2f, x: Float = TEPI) {
        pastikan(gap)
        kanvas.drawText(t, x, y + 9f, p)
        y += gap
    }

    fun spasi(h: Float) { y += h }

    private fun bungkus(t: String, lebar: Float, p: Paint): List<String> {
        val hasil = mutableListOf<String>()
        for (para in t.split("\n")) {
            var cur = ""
            for (kata in para.split(" ")) {
                var k = kata
                while (lebar > 0 && p.measureText(k) > lebar) {
                    val n = p.breakText(k, true, lebar, null)
                    if (n <= 0) break
                    if (cur.isNotEmpty()) { hasil.add(cur); cur = "" }
                    hasil.add(k.substring(0, n))
                    k = k.substring(n)
                }
                val coba = if (cur.isEmpty()) k else "$cur $k"
                if (p.measureText(coba) <= lebar) cur = coba else { hasil.add(cur); cur = k }
            }
            hasil.add(cur)
        }
        return hasil
    }

    private fun ukur(lebar: List<Float>, sel: List<String>, p: Paint): Pair<List<List<String>>, Float> {
        val bk = sel.mapIndexed { i, t -> bungkus(t, lebar[i] - 2 * PAD, p) }
        return Pair(bk, (bk.maxOf { it.size }) * GARIS_TEKS + 2 * PAD)
    }

    private fun gambar(lebar: List<Float>, bk: List<List<String>>, tinggi: Float, p: Paint, tengah: Set<Int>, latar: Boolean) {
        var x = TEPI
        if (latar) kanvas.drawRect(TEPI, y, TEPI + lebar.sum(), y + tinggi, latarHeader)
        lebar.forEachIndexed { i, w ->
            kanvas.drawRect(x, y, x + w, y + tinggi, garis)
            bk[i].forEachIndexed { j, s ->
                val tx = if (i in tengah) x + (w - p.measureText(s)) / 2f else x + PAD
                kanvas.drawText(s, tx, y + PAD + (j + 1) * GARIS_TEKS - 3f, p)
            }
            x += w
        }
        y += tinggi
    }

    fun tabel(lebar: List<Float>, header: List<String>, isi: List<List<String>>, tengah: Set<Int>) {
        val semuaTengah = header.indices.toSet()
        val (bh, th) = ukur(lebar, header, tebal)
        pastikan(th + 30f)
        gambar(lebar, bh, th, tebal, semuaTengah, true)
        for (r in isi) {
            val (bk, t) = ukur(lebar, r, teks)
            if (y + t > TINGGI - TEPI) {
                baru()
                gambar(lebar, bh, th, tebal, semuaTengah, true)
            }
            gambar(lebar, bk, t, teks, tengah, false)
        }
    }
}

object LaporanPdf {
    private fun ym(tgl: Long): YearMonth = YearMonth.from(LocalDate.ofEpochDay(tgl))

    private fun rekap(siswa: List<Siswa>, pres: List<PresensiTanggal>, pertemuan: Int): List<List<String>> {
        val per = pres.groupBy { it.siswaId }
        return siswa.mapIndexed { i, s ->
            val st = per[s.id].orEmpty().groupingBy { it.status }.eachCount()
            val h = st["Hadir"] ?: 0
            val persen = if (pertemuan == 0) 0 else Math.round(h * 100f / pertemuan)
            listOf("${i + 1}", s.nis, s.nama, "$h", "${st["Sakit"] ?: 0}", "${st["Izin"] ?: 0}", "${st["Alpa"] ?: 0}", "$persen%")
        }
    }

    fun buat(d: DataLaporanAgenda): ByteArray {
        val doc = PdfDocument()
        val p = Pena(doc)

        p.baris("LAPORAN AGENDA MENGAJAR", p.judul, 22f)
        p.baris("Sekolah               : ${d.sekolah}")
        p.baris("Guru                    : ${d.guru} (NIP ${d.nip})")
        p.baris("Tahun Ajaran     : ${d.tahun}")
        p.baris("Kelas                   : ${d.kelas}")
        p.baris("Mata Pelajaran : ${d.mapel}")
        p.baris("Periode               : ${d.periode}")
        p.spasi(10f)

        // A. Daftar agenda
        p.baris("A. Daftar Agenda Mengajar", p.bagian, 18f)
        val lebarAgenda = listOf(24f, 76f, 58f, 140f, 113f, 26f, 26f, 26f, 26f)
        val barisAgenda = d.agenda.mapIndexed { i, a ->
            listOf(
                "${i + 1}", Fmt.tanggal(a.tanggal, "d MMM yyyy"), Fmt.rentang(a.mulai, a.selesai),
                a.topik, a.catatan.ifBlank { "-" },
                "${a.hadir}", "${a.sakit}", "${a.izin}", "${a.alpa}"
            )
        }
        p.tabel(lebarAgenda, listOf("No", "Tanggal", "Waktu", "Topik Pembelajaran", "Catatan", "H", "S", "I", "A"), barisAgenda, setOf(0, 1, 2, 5, 6, 7, 8))
        p.baris("H = Hadir, S = Sakit, I = Izin, A = Alpa", p.teks, 14f)
        p.spasi(10f)

        // B. Rekap presensi per bulan
        p.pastikan(60f)
        p.baris("B. Rekap Presensi Siswa per Bulan", p.bagian, 18f)
        if (d.siswa.isEmpty()) {
            p.baris("Belum ada siswa terdaftar pada kelas ini.")
        } else {
            val lebarRekap = listOf(26f, 70f, 209f, 36f, 36f, 36f, 36f, 66f)
            val header = listOf("No", "NIS", "Nama Siswa", "H", "S", "I", "A", "% Hadir")
            val tengah = setOf(0, 3, 4, 5, 6, 7)
            val bulanList = d.agenda.map { ym(it.tanggal) }.distinct().sorted()
            for (b in bulanList) {
                val ag = d.agenda.count { ym(it.tanggal) == b }
                val pres = d.presensi.filter { ym(it.tanggal) == b }
                p.pastikan(70f)
                p.baris("Bulan ${Fmt.bulan(b)} ($ag pertemuan)", p.tebal, 16f)
                p.tabel(lebarRekap, header, rekap(d.siswa, pres, ag), tengah)
                p.spasi(10f)
            }
            if (bulanList.size > 1) {
                p.pastikan(70f)
                p.baris("Total Seluruh Periode (${d.agenda.size} pertemuan)", p.tebal, 16f)
                p.tabel(lebarRekap, header, rekap(d.siswa, d.presensi, d.agenda.size), tengah)
                p.spasi(10f)
            }
        }

        // Tanda tangan
        p.pastikan(110f)
        val xKanan = LEBAR - TEPI - 190f
        p.spasi(8f)
        p.baris("Dicetak pada ${Fmt.tanggal(LocalDate.now().toEpochDay())}", p.teks, 14f, xKanan)
        p.baris("Guru Mata Pelajaran,", p.teks, 60f, xKanan)
        p.baris(d.guru, p.tebal, 12f, xKanan)
        p.baris("NIP ${d.nip}", p.teks, 12f, xKanan)

        p.selesai()
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
