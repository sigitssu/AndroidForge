package com.edu.teacherlog

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.edu.teacherlog.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnClasses.setOnClickListener {
            // Placeholder for Class activity
        }
        binding.btnAgenda.setOnClickListener {
            // Placeholder for Agenda activity
        }
        binding.btnReports.setOnClickListener {
            // Placeholder for Report activity
        }
    }
}