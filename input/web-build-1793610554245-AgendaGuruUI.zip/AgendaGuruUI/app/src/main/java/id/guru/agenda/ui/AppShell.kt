package id.guru.agenda.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment as AssignmentFilled
import androidx.compose.material.icons.automirrored.outlined.Assignment as AssignmentOutlined
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.CalendarToday as CalendarFilled
import androidx.compose.material.icons.filled.Home as HomeFilled
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch

private class NavItem(val label: String, val on: ImageVector, val off: ImageVector)

private val navItems = listOf(
    NavItem("Beranda", Icons.Filled.HomeFilled, Icons.Outlined.Home),
    NavItem("Agenda", Icons.Filled.CalendarFilled, Icons.Outlined.CalendarToday),
    NavItem("Laporan", Icons.AutoMirrored.Filled.AssignmentFilled, Icons.AutoMirrored.Outlined.AssignmentOutlined),
    NavItem("Pengaturan", Icons.Outlined.Settings, Icons.Outlined.Settings)
)

private val drawerItems: List<Pair<String, ImageVector>> = listOf(
    "Tahun Ajaran" to Icons.Outlined.DateRange,
    "Daftar Kelas" to Icons.Outlined.Class,
    "Daftar Siswa" to Icons.Outlined.Group,
    "Daftar Mata Pelajaran" to Icons.AutoMirrored.Outlined.MenuBook,
    "Backup & Restore" to Icons.Outlined.CloudSync
)

private data class NavEntry(val route: Route, val depth: Int)

@Composable
fun AgendaGuruApp() {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Route>() }
    val push: (Route) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    Box(Modifier.fillMaxSize()) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(300.dp),
                    drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                    drawerContainerColor = MdSurface
                ) {
                    Column(Modifier.fillMaxWidth().background(MdPrimaryContainer).padding(24.dp)) {
                        Text("Menu Utama", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                        Text("SMK Negeri 1", fontSize = 14.sp, color = MdOnPrimaryContainer.copy(alpha = 0.8f))
                    }
                    drawerItems.forEachIndexed { index, item ->
                        if (index == drawerItems.lastIndex) {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gray200)
                        }
                        NavigationDrawerItem(
                            label = { Text(item.first) },
                            icon = { Icon(item.second, contentDescription = null, tint = Gray600) },
                            selected = false,
                            shape = RectangleShape,
                            onClick = {
                                scope.launch { drawerState.close() }
                                push(Route.Master(item.first))
                            }
                        )
                    }
                }
            }
        ) {
            MainScaffold(
                tab = tab,
                onTab = { tab = it },
                onMenu = { scope.launch { drawerState.open() } },
                push = push
            )
        }

        val top = stack.lastOrNull()?.let { NavEntry(it, stack.size) }
        AnimatedContent(
            targetState = top,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                val masuk = (targetState?.depth ?: 0) > (initialState?.depth ?: 0)
                if (masuk) {
                    slideInHorizontally { it } togetherWith slideOutHorizontally { -it / 3 }
                } else {
                    slideInHorizontally { -it / 3 } togetherWith slideOutHorizontally { it }
                }
            },
            label = "nav"
        ) { entry ->
            if (entry != null) RouteScreen(entry.route, push, pop) else Box(Modifier.fillMaxSize())
        }
    }
    BackHandler(enabled = stack.isNotEmpty()) { pop() }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
}

@Composable
private fun RouteScreen(route: Route, push: (Route) -> Unit, pop: () -> Unit) {
    when (route) {
        Route.Profil -> ProfilScreen(pop)
        Route.Pengaturan -> PengaturanScreen(pop)
        is Route.Master -> MasterListScreen(route.title, push, pop)
        is Route.TahunForm -> TahunForm(route.item, pop)
        is Route.KelasForm -> KelasForm(route.item, pop)
        is Route.SiswaForm -> SiswaForm(route.item, pop)
        is Route.MapelForm -> MapelForm(route.item, pop)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(tab: Int, onTab: (Int) -> Unit, onMenu: () -> Unit, push: (Route) -> Unit) {
    var profileMenu by remember { mutableStateOf(false) }
    val judul = listOf("Agenda Hari Ini", "Agenda", "Laporan")
    Scaffold(
        containerColor = AppBg,
        topBar = {
            TopAppBar(
                title = { Text(judul[tab], fontSize = 20.sp, fontWeight = FontWeight.Medium) },
                navigationIcon = {
                    IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, contentDescription = "Menu") }
                },
                actions = {
                    Box(Modifier.padding(end = 16.dp)) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .border(2.dp, MdPrimary, CircleShape)
                                .clip(CircleShape)
                                .background(Color(0xFFD0BCFF))
                                .clickable { profileMenu = true },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("PB", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MdOnPrimaryContainer)
                        }
                        DropdownMenu(
                            expanded = profileMenu,
                            onDismissRequest = { profileMenu = false },
                            modifier = Modifier.width(160.dp)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Ubah Profil") },
                                leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                                onClick = { profileMenu = false; push(Route.Profil) }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MdPrimaryContainer,
                    titleContentColor = MdOnPrimaryContainer,
                    navigationIconContentColor = MdOnPrimaryContainer,
                    actionIconContentColor = MdOnPrimaryContainer
                )
            )
        },
        floatingActionButton = { if (tab <= 1) AddFab { } },
        bottomBar = {
            Column {
                HorizontalDivider(color = Gray200)
                NavigationBar(containerColor = MdSurface) {
                    navItems.forEachIndexed { i, item ->
                        val selected = i < 3 && tab == i
                        NavigationBarItem(
                            selected = selected,
                            onClick = { if (i == 3) push(Route.Pengaturan) else onTab(i) },
                            icon = { Icon(if (selected) item.on else item.off, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MdOnSurface,
                                selectedTextColor = MdOnSurface,
                                indicatorColor = MdSecondaryContainer,
                                unselectedIconColor = Gray600,
                                unselectedTextColor = Gray600
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> BerandaTab()
                1 -> AgendaTab()
                else -> LaporanTab()
            }
        }
    }
}
