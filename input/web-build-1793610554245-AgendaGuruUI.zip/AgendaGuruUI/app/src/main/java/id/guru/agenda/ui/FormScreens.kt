package id.guru.agenda.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

@Composable
fun ProfilScreen(pop: () -> Unit) {
    var nama by remember { mutableStateOf("Budi Santoso, S.Kom.") }
    var nip by remember { mutableStateOf("198501012010011001") }
    var sekolah by remember { mutableStateOf("SMK Negeri 1") }
    FormScaffold("Ubah Profil", pop) {
        Box(Modifier.align(Alignment.CenterHorizontally).size(120.dp)) {
            Box(
                Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFFD0BCFF)).border(3.dp, MdPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("PB", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
            }
            Box(
                Modifier.align(Alignment.BottomEnd).size(38.dp).clip(CircleShape).background(MdPrimary)
                    .border(2.dp, Color.White, CircleShape).clickable { },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Edit, contentDescription = "Ubah foto", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
        AppTextField("Nama Lengkap", nama, { nama = it })
        AppTextField("NIP", nip, { nip = it }, number = true)
        AppTextField("Nama Sekolah", sekolah, { sekolah = it })
    }
}

@Composable
fun TahunForm(item: TahunAjaran?, pop: () -> Unit) {
    var awal by remember { mutableStateOf(item?.awal ?: "") }
    var akhir by remember { mutableStateOf(item?.akhir ?: "") }
    var semester by remember { mutableStateOf(item?.semester ?: "Ganjil") }
    FormScaffold(if (item == null) "Tambah Tahun Ajaran" else "Ubah Tahun Ajaran", pop) {
        DateField("Awal Tahun Ajaran", awal) { awal = it }
        DateField("Akhir Tahun Ajaran", akhir) { akhir = it }
        RadioGroup("Semester", listOf("Ganjil", "Genap"), semester) { semester = it }
    }
}

@Composable
fun KelasForm(item: KelasItem?, pop: () -> Unit) {
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    FormScaffold(if (item == null) "Tambah Daftar Kelas" else "Ubah Daftar Kelas", pop) {
        AppTextField("Nama Kelas", nama, { nama = it })
    }
}

@Composable
fun SiswaForm(item: SiswaItem?, pop: () -> Unit) {
    var nis by remember { mutableStateOf(item?.nis ?: "") }
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    var jk by remember { mutableStateOf(item?.jk ?: "Laki-laki") }
    FormScaffold(if (item == null) "Tambah Siswa" else "Ubah Siswa", pop) {
        AppTextField("NIS", nis, { nis = it }, number = true)
        AppTextField("Nama Siswa", nama, { nama = it })
        RadioGroup("Jenis Kelamin", listOf("Laki-laki", "Perempuan"), jk) { jk = it }
    }
}

@Composable
fun MapelForm(item: MapelItem?, pop: () -> Unit) {
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    var kelas by remember { mutableStateOf(item?.kelas ?: "Pilih kelas") }
    FormScaffold(if (item == null) "Tambah Daftar Mata Pelajaran" else "Ubah Daftar Mata Pelajaran", pop) {
        AppTextField("Nama Mata Pelajaran", nama, { nama = it })
        FilterField("Kelas", kelas, kelasList.map { it.nama }, { kelas = it })
    }
}
