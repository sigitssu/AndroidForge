package id.gurukelas.app

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.zip.ZipInputStream

data class ImportResult(
    val inserted: Int,
    val skipped: Int,
    val updated: Int,
    val message: String
)

/**
 * XLSX importer for the first worksheet.
 * Recognized headers: NIS, Nama, Kelas, Jenis Kelamin.
 * If headers cannot be recognized, columns A-D are used in that order.
 */
object ExcelImport {
    suspend fun import(
        resolver: ContentResolver,
        uri: Uri,
        dao: SchoolDao
    ): ImportResult {
        val rows = readFirstSheet(resolver, uri)
        if (rows.size < 2) return ImportResult(0, 0, 0, "File tidak berisi baris siswa.")

        val header = rows.first().map { normalize(it) }
        val nisCol = header.indexOfFirst { it == "nis" || it == "nisn" }.let { if (it >= 0) it else 0 }
        val nameCol = header.indexOfFirst { it == "nama" || it == "nama siswa" }.let { if (it >= 0) it else 1 }
        val classCol = header.indexOfFirst { it == "kelas" }.let { if (it >= 0) it else 2 }
        val genderCol = header.indexOfFirst {
            it == "jenis kelamin" || it == "jk" || it == "gender"
        }.let { if (it >= 0) it else 3 }

        var inserted = 0
        var skipped = 0
        var updated = 0
        val seen = mutableSetOf<String>()

        for (cells in rows.drop(1)) {
            val nis = cells.getOrNull(nisCol).orEmpty().trim()
            val name = cells.getOrNull(nameCol).orEmpty().trim()
            val className = cells.getOrNull(classCol).orEmpty().trim()
            val genderRaw = cells.getOrNull(genderCol).orEmpty().trim()
            val gender = normalizeGender(genderRaw)

            if (nis.isBlank() || name.isBlank() || className.isBlank() || gender == null) {
                skipped++
                continue
            }
            if (!seen.add(nis)) {
                skipped++
                continue
            }

            var schoolClass = dao.classByName(className)
            if (schoolClass == null) {
                val id = dao.addClass(SchoolClass(name = className))
                schoolClass = dao.classByName(className)
                if (schoolClass == null && id > 0) {
                    schoolClass = SchoolClass(id = id, name = className)
                }
            }
            if (schoolClass == null) {
                skipped++
                continue
            }
            val targetClass = schoolClass

            val existing = dao.studentByNis(nis)
            if (existing != null) {
                // Keep current row safe in the starter: do not silently move/update an existing student.
                skipped++
            } else {
                val id = dao.addStudent(
                    Student(
                        studentNumber = nis,
                        fullName = name,
                        classId = targetClass.id,
                        gender = gender
                    )
                )
                if (id == -1L) skipped++ else inserted++
            }
        }

        return ImportResult(
            inserted, skipped, updated,
            "Impor selesai. Berhasil: $inserted; dilewati: $skipped."
        )
    }

    private fun normalize(value: String): String =
        value.trim().lowercase().replace("_", " ").replace(Regex("\\s+"), " ")

    private fun normalizeGender(value: String): String? = when (normalize(value)) {
        "l", "laki laki", "laki-laki", "pria", "male" -> "Laki-laki"
        "p", "perempuan", "wanita", "female" -> "Perempuan"
        else -> null
    }

    private fun readFirstSheet(resolver: ContentResolver, uri: Uri): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.name == "xl/sharedStrings.xml" ||
                        entry.name == "xl/worksheets/sheet1.xml") {
                        entries[entry.name] = zip.readBytes()
                    }
                }
            }
        } ?: error("File tidak dapat dibuka.")

        val sharedStrings = parseSharedStrings(entries["xl/sharedStrings.xml"])
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: error("Sheet pertama tidak ditemukan.")
        val parser = Xml.newPullParser()
        parser.setInput(sheet.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var currentRow = mutableListOf<String>()
        var cellRef = ""
        var cellType = ""
        var cellValue = ""
        var readingValue = false
        var event = parser.eventType

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> currentRow = mutableListOf()
                    "c" -> {
                        cellRef = parser.getAttributeValue(null, "r") ?: ""
                        cellType = parser.getAttributeValue(null, "t") ?: ""
                        cellValue = ""
                    }
                    "v", "t" -> readingValue = true
                }
                XmlPullParser.TEXT -> if (readingValue) cellValue += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> readingValue = false
                    "c" -> {
                        val col = cellRef.takeWhile { it.isLetter() }
                            .fold(0) { acc, ch -> acc * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                        while (currentRow.size <= col) currentRow.add("")
                        currentRow[col] = if (cellType == "s") {
                            sharedStrings.getOrNull(cellValue.toIntOrNull() ?: -1).orEmpty()
                        } else cellValue
                    }
                    "row" -> rows.add(currentRow.toList())
                }
            }
            event = parser.next()
        }
        return rows
    }

    private fun parseSharedStrings(bytes: ByteArray?): List<String> {
        if (bytes == null) return emptyList()
        val parser = Xml.newPullParser()
        parser.setInput(bytes.inputStream(), "UTF-8")
        val result = mutableListOf<String>()
        var inItem = false
        var inText = false
        var value = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "si" -> { inItem = true; value = "" }
                    "t" -> if (inItem) inText = true
                }
                XmlPullParser.TEXT -> if (inText) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "t" -> inText = false
                    "si" -> { result.add(value); inItem = false }
                }
            }
            event = parser.next()
        }
        return result
    }
}
