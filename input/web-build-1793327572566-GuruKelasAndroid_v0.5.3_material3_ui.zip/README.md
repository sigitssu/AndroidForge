# GuruKelas v0.5.3 — Material Design 3-inspired UI

Revisi visual berdasarkan source v0.5.2.

## Pembaruan UI
- Palet warna terinspirasi Material You / Material Design 3: primary blue-gray, surface terang, dan primary container.
- Header memakai primary-container lembut dengan teks kontras.
- Kartu dan kontrol menggunakan radius lebih besar, border lembut, dan jarak yang lebih lapang.
- Tab pilihan menggunakan gaya segmented/selected-container.
- FAB memakai warna primary agar konsisten dengan sistem warna.
- Status bar dan navigation bar mengikuti surface terang.

## Catatan teknis
Proyek ini masih menggunakan Android Views dan `com.google.android.material:material:1.12.0` (Material Components). Karena itu, pembaruan ini menerapkan **prinsip visual Material 3**, bukan migrasi penuh ke Jetpack Compose Material 3. Migrasi penuh ke Compose Material 3 memerlukan perubahan arsitektur UI yang lebih besar.

## Build
Unggah ZIP ini melalui AndroidForge Web UI lalu jalankan Build APK (debug). Kompilasi Android versi ini belum diverifikasi di lingkungan ini.
