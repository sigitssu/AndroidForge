package id.guru.agenda.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.Brush
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*

@Composable
fun PengaturanScreen(push: (Route) -> Unit, pop: () -> Unit) {
    PageScaffold("Pengaturan", pop) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            SettingsCard(
                listOf(
                    SettingItem(Icons.Outlined.Palette, "Tema Aplikasi") { push(Route.Tema) },
                    SettingItem(Icons.Outlined.Info, "Tentang Aplikasi") { push(Route.Tentang) }
                )
            )
        }
    }
}

// ---------------- Tema Aplikasi ----------------
@Composable
fun TemaScreen(pop: () -> Unit) {
    var mode by remember { mutableIntStateOf(0) }
    var pilih by remember { mutableIntStateOf(4) }
    val warna = listOf(Color(0xFFFF5A6E), Color(0xFFFFD54F), Color(0xFF66CC8A), Color(0xFF3B82F6), Color(0xFF7C4DFF))

    PageScaffold("Tema Aplikasi", pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Tema Warna", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Gray800)
                    Spacer(Modifier.height(12.dp))
                    ThemeSwitch(mode) { mode = it }
                    Spacer(Modifier.height(24.dp))
                    Text("Warna Aplikasi", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Gray800)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        warna.forEachIndexed { i, c -> ColorDot(c, i == pilih) { pilih = i } }
                    }
                    Spacer(Modifier.height(20.dp))
                    HorizontalDivider(color = Gray100)
                    Row(
                        Modifier.fillMaxWidth().clickable { }.padding(top = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(36.dp).clip(CircleShape).background(
                                Brush.sweepGradient(
                                    listOf(Color(0xFFFF5A6E), Color(0xFFFFD54F), Color(0xFF66CC8A), Color(0xFF22D3EE), Color(0xFF3B82F6), Color(0xFFD946EF), Color(0xFFFF5A6E))
                                )
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Brush, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Text("Buka Editor", Modifier.weight(1f), fontWeight = FontWeight.Medium, color = Gray600)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Gray500)
                    }
                }
            }
            PratinjauCard(mode, warna[pilih])
        }
    }
}

@Composable
private fun ThemeSwitch(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Icons.Outlined.LightMode to "Terang",
        Icons.Outlined.DarkMode to "Gelap",
        Icons.Outlined.NightsStay to "Hitam"
    )
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(MdSurfaceVariant.copy(alpha = 0.6f)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items.forEachIndexed { i, item ->
            val sel = i == selected
            val bobot by animateFloatAsState(if (sel) 1.9f else 1f, label = "bobot")
            Row(
                Modifier.weight(bobot)
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) MdPrimary else Color.Transparent)
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.first, contentDescription = item.second, tint = if (sel) Color.White else Gray600, modifier = Modifier.size(20.dp))
                if (sel) {
                    Spacer(Modifier.width(6.dp))
                    Text(item.second, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape)
            .then(if (selected) Modifier.border(2.dp, color.copy(alpha = 0.45f), CircleShape) else Modifier)
            .clickable(onClick = onClick)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            if (selected) Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun PratinjauCard(mode: Int, aksen: Color) {
    val bg = when (mode) { 0 -> AppBg; 1 -> Color(0xFF1C1B1F); else -> Color.Black }
    val fg = if (mode == 0) Gray800 else Color.White
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Pratinjau", fontSize = 12.sp, color = fg.copy(alpha = 0.6f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(aksen), contentAlignment = Alignment.Center) {
                    Text("PB", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("XII TKJ 1", fontWeight = FontWeight.Bold, color = fg)
                    Text("07:30 - 09:00", fontSize = 12.sp, color = fg.copy(alpha = 0.7f))
                }
            }
            Button(onClick = { }, colors = ButtonDefaults.buttonColors(containerColor = aksen)) { Text("Simpan") }
        }
    }
}

// ---------------- Tentang Aplikasi ----------------
@Composable
fun TentangScreen(pop: () -> Unit) {
    PageScaffold("Tentang Aplikasi", pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(MdPrimary, Indigo500))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.EventAvailable, contentDescription = null, tint = Color.White, modifier = Modifier.size(52.dp))
            }
            Text("Agenda Guru", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Gray800)
            Text("Versi 1.0.0", fontSize = 14.sp, color = Gray500)
            Text(
                "Aplikasi pencatat agenda mengajar dan presensi siswa untuk guru. " +
                    "Data tersimpan di perangkat dan laporannya dapat dibuat dalam bentuk PDF.",
                textAlign = TextAlign.Center, fontSize = 14.sp, color = Gray600
            )
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column {
                    InfoRow(Icons.Outlined.Storage, "Penyimpanan", "Lokal di perangkat")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.UploadFile, "Impor data siswa", "File Excel (.xlsx)")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.PictureAsPdf, "Laporan", "PDF")
                    HorizontalDivider(color = Gray100)
                    InfoRow(Icons.Outlined.Code, "Dibuat dengan", "Kotlin & Material Design 3")
                }
            }
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MdPrimary)
        Spacer(Modifier.width(16.dp))
        Column {
            Text(label, fontSize = 12.sp, color = Gray500)
            Text(value, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray800)
        }
    }
}
