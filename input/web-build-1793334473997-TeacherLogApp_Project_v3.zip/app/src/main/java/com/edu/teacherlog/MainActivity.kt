package com.edu.teacherlog

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.edu.teacherlog.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnClasses.setOnClickListener {
            // Class Activity
        }
        binding.btnAgenda.setOnClickListener {
            // Agenda Activity
        }
        binding.btnReports.setOnClickListener {
            // Report Activity
        }
    }
}