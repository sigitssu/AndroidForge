package id.guru.agenda.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

@Composable
fun PresensiScreen(a: AgendaItem, pop: () -> Unit) {
    val siswa = siswaList.filter { it.kelas == a.kelas }
    val status = remember { mutableStateMapOf<String, String>() }
    val opsi = listOf("Hadir", "Sakit", "Izin", "Alpa")
    val warna = mapOf("Hadir" to MdPrimary, "Sakit" to MdError, "Izin" to MdTertiary, "Alpa" to AlpaRed)

    PageScaffold("Presensi Siswa", pop) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("${a.kelas} • ${a.jam}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                            Text(a.topik, fontSize = 13.sp, color = Gray600)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                opsi.forEach { o ->
                                    val jumlah = siswa.count { s -> (status[s.nis] ?: "Hadir") == o }
                                    Stat(jumlah, o, warna.getValue(o))
                                }
                            }
                        }
                    }
                }
                items(siswa) { s ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text(s.nama, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray800)
                            Text("NIS ${s.nis}", fontSize = 12.sp, color = Gray500)
                            Spacer(Modifier.height(12.dp))
                            SegmentedControl(
                                options = opsi,
                                selected = status[s.nis] ?: "Hadir",
                                onSelect = { status[s.nis] = it },
                                selectedColors = warna
                            )
                        }
                    }
                }
            }
            Surface(color = Color.White, shadowElevation = 8.dp) {
                Button(
                    onClick = pop,
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
                ) { Text("Simpan") }
            }
        }
    }
}
