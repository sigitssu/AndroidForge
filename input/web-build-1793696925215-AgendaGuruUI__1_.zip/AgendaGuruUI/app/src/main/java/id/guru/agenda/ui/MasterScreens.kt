package id.guru.agenda.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

private class RowData(val title: String, val sub: String, val icon: ImageVector, val editRoute: Route)

private fun addRoute(title: String): Route? = when (title) {
    "Tahun Ajaran" -> Route.TahunForm(null)
    "Daftar Kelas" -> Route.KelasForm(null)
    "Daftar Mata Pelajaran" -> Route.MapelForm(null)
    else -> null
}

@Composable
fun MasterListScreen(title: String, push: (Route) -> Unit, pop: () -> Unit) {
    var sheetRoute by remember { mutableStateOf<Route?>(null) }
    var kelasSiswa by remember { mutableStateOf(kelasList.first().nama) }

    val rows: List<RowData> = when (title) {
        "Tahun Ajaran" -> tahunAjaranList.map {
            RowData(it.label, it.awal + " - " + it.akhir + (if (it.aktif) "  •  Aktif" else ""), Icons.Outlined.DateRange, Route.TahunForm(it))
        }
        "Daftar Kelas" -> kelasList.map {
            RowData(it.nama, "${it.jumlah} siswa", Icons.Outlined.Class, Route.KelasForm(it))
        }
        "Daftar Siswa" -> siswaList.filter { it.kelas == kelasSiswa }.map {
            RowData(it.nama, "NIS ${it.nis}  •  ${it.jk}", Icons.Outlined.Person, Route.SiswaForm(it))
        }
        "Daftar Mata Pelajaran" -> mapelList.map {
            RowData(it.nama, it.kelas, Icons.AutoMirrored.Outlined.MenuBook, Route.MapelForm(it))
        }
        else -> emptyList()
    }

    PageScaffold(
        title = title,
        pop = pop,
        fab = {
            when (title) {
                "Backup & Restore" -> Unit
                "Daftar Siswa" -> ExtendedFloatingActionButton(onClick = { }) {
                    Icon(Icons.Outlined.UploadFile, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Impor Excel")
                }
                else -> AddFab { addRoute(title)?.let(push) }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (title == "Backup & Restore") {
                Column(Modifier.padding(16.dp)) {
                    SettingsCard(
                        listOf(
                            SettingItem(Icons.Outlined.Backup, "Cadangkan data") { },
                            SettingItem(Icons.Outlined.Restore, "Pulihkan data") { }
                        )
                    )
                }
            } else {
                if (title == "Daftar Siswa") {
                    FilterField(
                        "Kelas", kelasSiswa, kelasList.map { it.nama }, { kelasSiswa = it },
                        Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)
                    )
                }
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(rows) { r ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            ListItem(
                                headlineContent = { Text(r.title, fontWeight = FontWeight.Medium) },
                                supportingContent = { Text(r.sub) },
                                leadingContent = { Icon(r.icon, contentDescription = null, tint = MdPrimary) },
                                trailingContent = {
                                    IconButton(onClick = { sheetRoute = r.editRoute }) {
                                        Icon(Icons.Outlined.MoreVert, contentDescription = "Opsi", tint = Gray500)
                                    }
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                            )
                        }
                    }
                }
            }
        }
    }

    sheetRoute?.let { target ->
        ActionSheet(
            onDismiss = { sheetRoute = null },
            actions = listOf(
                SheetAction(Icons.Outlined.Edit, "Ubah") { sheetRoute = null; push(target) },
                SheetAction(Icons.Outlined.Delete, "Hapus") { sheetRoute = null }
            )
        )
    }
}
