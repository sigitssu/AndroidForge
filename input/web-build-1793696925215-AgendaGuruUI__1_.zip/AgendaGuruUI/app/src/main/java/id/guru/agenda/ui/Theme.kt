package id.guru.agenda.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palet Material 3 (baseline purple) sesuai mockup
val MdPrimary = Color(0xFF6750A4)
val MdPrimaryContainer = Color(0xFFEADDFF)
val MdOnPrimaryContainer = Color(0xFF21005D)
val MdSurface = Color(0xFFFEF7FF)
val MdOnSurface = Color(0xFF1D1B20)
val MdSurfaceVariant = Color(0xFFE7E0EC)
val MdSecondaryContainer = Color(0xFFE8DEF8)
val MdError = Color(0xFFB3261E)
val MdTertiary = Color(0xFF7D5260)
val AlpaRed = Color(0xFF991B1B)
val AppBg = Color(0xFFFDF8FD)
val Gray100 = Color(0xFFF3F4F6)
val Gray200 = Color(0xFFE5E7EB)
val Gray500 = Color(0xFF6B7280)
val Gray600 = Color(0xFF4B5563)
val Gray800 = Color(0xFF1F2937)

private val Scheme = lightColorScheme(
    primary = MdPrimary, onPrimary = Color.White,
    primaryContainer = MdPrimaryContainer, onPrimaryContainer = MdOnPrimaryContainer,
    secondaryContainer = MdSecondaryContainer, onSecondaryContainer = MdOnSurface,
    tertiary = MdTertiary, error = MdError,
    background = AppBg, onBackground = MdOnSurface,
    surface = MdSurface, onSurface = MdOnSurface,
    surfaceVariant = MdSurfaceVariant
)

@Composable
fun AgendaGuruTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)

val Indigo100 = Color(0xFFE0E7FF)
val Indigo500 = Color(0xFF6366F1)
