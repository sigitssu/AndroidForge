package id.guru.agenda

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import id.guru.agenda.data.*
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicLightColorScheme(ctx)
            else lightColorScheme(primary = Color(0xFF1B5E9E))
            MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize()) { App() } }
        }
    }
}

sealed interface Screen {
    data object Home : Screen
    data class KelasDetail(val k: Kelas) : Screen
    data class Absen(val a: Agenda) : Screen
}

@Composable
fun App(vm: MainVM = viewModel()) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val home = { screen = Screen.Home }
    when (val s = screen) {
        Screen.Home -> HomeScreen(vm, { screen = Screen.KelasDetail(it) }, { screen = Screen.Absen(it) })
        is Screen.KelasDetail -> KelasDetailScreen(vm, s.k, home)
        is Screen.Absen -> AbsenScreen(vm, s.a, home)
    }
    BackHandler(screen != Screen.Home) { home() }
}

@Composable
fun <T> Picker(label: String, items: List<T>, sel: T?, name: (T) -> String, onSel: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text(sel?.let(name) ?: label) }
        DropdownMenu(open, { open = false }) {
            items.forEach { DropdownMenuItem({ Text(name(it)) }, { onSel(it); open = false }) }
        }
    }
}

@Composable
fun InputDialog(title: String, labels: List<String>, onOk: (List<String>) -> Unit, onDismiss: () -> Unit) {
    val v = remember { mutableStateListOf(*Array(labels.size) { "" }) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            labels.forEachIndexed { i, l -> OutlinedTextField(v[i], { v[i] = it }, label = { Text(l) }, singleLine = true) } } },
        confirmButton = { TextButton({ if (v[0].isNotBlank()) { onOk(v.toList()); onDismiss() } }) { Text("Simpan") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } })
}

@Composable
fun AgendaDialog(vm: MainVM, onDismiss: () -> Unit) {
    val kelas by vm.kelas.collectAsState(); val mapel by vm.mapel.collectAsState()
    var k by remember { mutableStateOf<Kelas?>(null) }; var m by remember { mutableStateOf<Mapel?>(null) }
    var tgl by remember { mutableStateOf(LocalDate.now().toString()) }
    var topik by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Agenda Mengajar Baru") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Picker("Pilih kelas", kelas, k, { it.nama }) { k = it }
            Picker("Pilih mata pelajaran", mapel, m, { it.nama }) { m = it }
            OutlinedTextField(tgl, { tgl = it }, label = { Text("Tanggal (yyyy-MM-dd)") }, singleLine = true)
            OutlinedTextField(topik, { topik = it }, label = { Text("Materi / topik") })
            OutlinedTextField(cat, { cat = it }, label = { Text("Catatan (opsional)") })
        } },
        confirmButton = { TextButton({
            if (k != null && m != null && topik.isNotBlank()) {
                vm.addAgenda(Agenda(kelasId = k!!.id, mapelId = m!!.id, tanggal = tgl, topik = topik, catatan = cat)); onDismiss()
            }
        }) { Text("Simpan") } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainVM, onKelas: (Kelas) -> Unit, onAbsen: (Agenda) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf(false) }
    val kelas by vm.kelas.collectAsState(); val mapel by vm.mapel.collectAsState(); val agenda by vm.agenda.collectAsState()
    val titles = listOf("Kelas", "Mapel", "Agenda", "Laporan")
    val icons = listOf(Icons.Default.Home, Icons.Default.List, Icons.Default.DateRange, Icons.Default.Info)
    Scaffold(
        topBar = { CenterAlignedTopAppBar({ Text("Agenda Guru") }) },
        bottomBar = { NavigationBar { titles.forEachIndexed { i, t ->
            NavigationBarItem(tab == i, { tab = i }, { Icon(icons[i], t) }, label = { Text(t) }) } } },
        floatingActionButton = { if (tab < 3) FloatingActionButton({ dialog = true }) { Icon(Icons.Default.Add, "Tambah") } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> LazyColumn { items(kelas) { k ->
                    ListItem({ Text(k.nama) }, Modifier.clickable2 { onKelas(k) }, supportingContent = { Text("TA ${k.tahun}") },
                        trailingContent = { IconButton({ vm.delete(k) }) { Icon(Icons.Default.Delete, "Hapus") } }) } }
                1 -> LazyColumn { items(mapel) { m ->
                    ListItem({ Text(m.nama) }, trailingContent = { IconButton({ vm.delete(m) }) { Icon(Icons.Default.Delete, "Hapus") } }) } }
                2 -> LazyColumn { items(agenda) { a ->
                    val kn = kelas.find { it.id == a.kelasId }?.nama ?: "-"; val mn = mapel.find { it.id == a.mapelId }?.nama ?: "-"
                    ListItem({ Text("${a.topik}") }, Modifier.clickable2 { onAbsen(a) },
                        supportingContent = { Text("${a.tanggal} • $kn • $mn\nKetuk untuk mengisi presensi") },
                        trailingContent = { IconButton({ vm.delete(a) }) { Icon(Icons.Default.Delete, "Hapus") } }) } }
                else -> LaporanTab(vm)
            }
        }
    }
    if (dialog) when (tab) {
        0 -> InputDialog("Kelas Baru", listOf("Nama kelas (mis. X IPA 1)", "Tahun ajaran (mis. 2026/2027)"), { vm.addKelas(it[0], it[1]) }) { dialog = false }
        1 -> InputDialog("Mata Pelajaran Baru", listOf("Nama mata pelajaran"), { vm.addMapel(it[0]) }) { dialog = false }
        2 -> AgendaDialog(vm) { dialog = false }
    }
}

@Composable
fun LaporanTab(vm: MainVM) {
    val ctx = LocalContext.current
    val kelas by vm.kelas.collectAsState(); val mapel by vm.mapel.collectAsState()
    var k by remember { mutableStateOf<Kelas?>(null) }; var m by remember { mutableStateOf<Mapel?>(null) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Laporan Agenda & Presensi (PDF)", style = MaterialTheme.typography.titleMedium)
        Picker("Pilih kelas", kelas, k, { it.nama }) { k = it }
        Picker("Pilih mata pelajaran", mapel, m, { it.nama }) { m = it }
        Button({
            if (k == null || m == null) Toast.makeText(ctx, "Pilih kelas dan mapel dulu", Toast.LENGTH_SHORT).show()
            else vm.buatPdf(k!!, m!!) { f ->
                if (f == null) Toast.makeText(ctx, "Gagal membuat PDF", Toast.LENGTH_SHORT).show()
                else {
                    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Buka / bagikan laporan"))
                }
            }
        }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Buat & Bagikan PDF") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KelasDetailScreen(vm: MainVM, k: Kelas, back: () -> Unit) {
    val ctx = LocalContext.current
    val siswa by remember(k.id) { vm.dao.siswa(k.id) }.collectAsState(emptyList())
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.importSiswa(k.id, it) { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() } }
    }
    Scaffold(topBar = { TopAppBar({ Text("${k.nama} (${siswa.size} siswa)") },
        navigationIcon = { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") } }) },
        floatingActionButton = { ExtendedFloatingActionButton({ pick.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) }) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Impor Excel (NIS, Nama)") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad)) { items(siswa) { s ->
            ListItem({ Text(s.nama) }, supportingContent = { Text("NIS ${s.nis}") },
                trailingContent = { IconButton({ vm.delete(s) }) { Icon(Icons.Default.Delete, "Hapus") } }) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AbsenScreen(vm: MainVM, a: Agenda, back: () -> Unit) {
    val siswa by produceState(emptyList<Siswa>(), a) { value = vm.dao.siswaOnce(a.kelasId) }
    val status = remember { mutableStateMapOf<Long, String>() }
    LaunchedEffect(a) { vm.dao.presensi(a.id).forEach { status[it.siswaId] = it.status } }
    Scaffold(topBar = { TopAppBar({ Text("Presensi: ${a.topik}") },
        navigationIcon = { IconButton(back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") } },
        actions = { IconButton({
            vm.savePresensi(siswa.map { Presensi(agendaId = a.id, siswaId = it.id, status = status[it.id] ?: "H") }); back()
        }) { Icon(Icons.Default.Check, "Simpan") } }) }
    ) { pad ->
        LazyColumn(Modifier.padding(pad)) { items(siswa) { s ->
            ListItem({ Text(s.nama) }, supportingContent = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf("H" to "Hadir", "S" to "Sakit", "I" to "Izin", "A" to "Alpa").forEach { (c, l) ->
                        FilterChip((status[s.id] ?: "H") == c, { status[s.id] = c }, { Text(l) }) } } }) } }
    }
}

private fun Modifier.clickable2(onClick: () -> Unit) = this.then(Modifier.clickable(onClick = onClick))
