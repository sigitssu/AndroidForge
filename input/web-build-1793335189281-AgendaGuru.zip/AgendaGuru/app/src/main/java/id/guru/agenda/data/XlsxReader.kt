package id.guru.agenda.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Pembaca .xlsx ringan tanpa library tambahan: membaca sheet pertama menjadi baris-baris teks. */
object XlsxReader {
    fun read(input: InputStream): List<List<String>> {
        var shared = emptyList<String>()
        var sheet: ByteArray? = null
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                when (e.name) {
                    "xl/sharedStrings.xml" -> shared = parseShared(zip.readBytes())
                    "xl/worksheets/sheet1.xml" -> sheet = zip.readBytes()
                }
            }
        }
        return sheet?.let { parseSheet(it, shared) } ?: emptyList()
    }

    private fun parser(b: ByteArray) = Xml.newPullParser().apply { setInput(ByteArrayInputStream(b), "UTF-8") }

    private fun parseShared(b: ByteArray): List<String> {
        val p = parser(b); val out = mutableListOf<String>(); var sb = StringBuilder()
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "si") sb = StringBuilder()
            else if (p.eventType == XmlPullParser.START_TAG && p.name == "t") sb.append(p.nextText())
            else if (p.eventType == XmlPullParser.END_TAG && p.name == "si") out.add(sb.toString())
        }
        return out
    }

    private fun parseSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val p = parser(b); val rows = mutableListOf<List<String>>()
        var row = mutableMapOf<Int, String>(); var col = 0; var type: String? = null
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG) when (p.name) {
                "row" -> row = mutableMapOf()
                "c" -> {
                    type = p.getAttributeValue(null, "t")
                    col = (p.getAttributeValue(null, "r") ?: "A").takeWhile { it.isLetter() }
                        .fold(0) { a, ch -> a * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                }
                "v" -> {
                    val v = p.nextText()
                    row[col] = if (type == "s") shared.getOrElse(v.toIntOrNull() ?: -1) { "" } else v.removeSuffix(".0")
                }
                "t" -> if (type == "inlineStr") row[col] = p.nextText()
            } else if (p.eventType == XmlPullParser.END_TAG && p.name == "row") {
                rows.add(List((row.keys.maxOrNull() ?: -1) + 1) { row[it].orEmpty().trim() })
            }
        }
        return rows
    }
}
