package id.guru.agenda

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.guru.agenda.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainVM(private val app: Application) : AndroidViewModel(app) {
    val dao = AppDb.get(app).dao()
    private fun <T> kotlinx.coroutines.flow.Flow<List<T>>.hot() = stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val kelas = dao.kelas().hot()
    val mapel = dao.mapel().hot()
    val agenda = dao.agenda().hot()

    private fun io(block: suspend () -> Unit) { viewModelScope.launch(Dispatchers.IO) { block() } }
    fun addKelas(n: String, t: String) = io { dao.insertKelas(Kelas(nama = n, tahun = t)) }
    fun addMapel(n: String) = io { dao.insertMapel(Mapel(nama = n)) }
    fun addAgenda(a: Agenda) = io { dao.insertAgenda(a) }
    fun delete(x: Any) = io {
        when (x) { is Kelas -> dao.deleteKelas(x); is Mapel -> dao.deleteMapel(x); is Agenda -> dao.deleteAgenda(x); is Siswa -> dao.deleteSiswa(x) }
    }
    fun savePresensi(list: List<Presensi>) = io { dao.savePresensi(list) }

    /** Format Excel: kolom A = NIS, kolom B = Nama (baris header opsional). */
    fun importSiswa(kelasId: Long, uri: Uri, done: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try {
                val rows = app.contentResolver.openInputStream(uri)!!.use { XlsxReader.read(it) }
                    .filter { it.size >= 2 && it[1].isNotBlank() }
                val data = if (rows.firstOrNull()?.get(0)?.lowercase() in listOf("nis", "nisn", "no", "nomor")) rows.drop(1) else rows
                dao.insertSiswa(data.map { Siswa(kelasId = kelasId, nis = it[0], nama = it[1]) })
                "${data.size} siswa berhasil diimpor"
            } catch (e: Exception) { "Gagal impor: ${e.message}" }
            withContext(Dispatchers.Main) { done(msg) }
        }
    }

    fun buatPdf(k: Kelas, m: Mapel, done: (File?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val f = try {
                val ag = dao.agendaFor(k.id, m.id)
                val pr = if (ag.isEmpty()) emptyList() else dao.presensiIn(ag.map { it.id })
                PdfReport.create(app, k, m, ag, dao.siswaOnce(k.id), pr)
            } catch (e: Exception) { null }
            withContext(Dispatchers.Main) { done(f) }
        }
    }
}
