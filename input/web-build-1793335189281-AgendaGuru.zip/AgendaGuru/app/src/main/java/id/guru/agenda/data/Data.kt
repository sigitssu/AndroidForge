package id.guru.agenda.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Kelas(@PrimaryKey(autoGenerate = true) val id: Long = 0, val nama: String, val tahun: String)

@Entity(foreignKeys = [ForeignKey(Kelas::class, ["id"], ["kelasId"], onDelete = ForeignKey.CASCADE)], indices = [Index("kelasId")])
data class Siswa(@PrimaryKey(autoGenerate = true) val id: Long = 0, val kelasId: Long, val nis: String, val nama: String)

@Entity data class Mapel(@PrimaryKey(autoGenerate = true) val id: Long = 0, val nama: String)

@Entity(
    foreignKeys = [
        ForeignKey(Kelas::class, ["id"], ["kelasId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(Mapel::class, ["id"], ["mapelId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("kelasId"), Index("mapelId")]
)
data class Agenda(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kelasId: Long, val mapelId: Long,
    val tanggal: String, val topik: String, val catatan: String = ""
)

/** status: H = Hadir, S = Sakit, I = Izin, A = Alpa */
@Entity(
    foreignKeys = [
        ForeignKey(Agenda::class, ["id"], ["agendaId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(Siswa::class, ["id"], ["siswaId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["agendaId", "siswaId"], unique = true), Index("siswaId")]
)
data class Presensi(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agendaId: Long, val siswaId: Long, val status: String
)

@Dao
interface AppDao {
    @Insert suspend fun insertKelas(k: Kelas): Long
    @Delete suspend fun deleteKelas(k: Kelas)
    @Query("SELECT * FROM Kelas ORDER BY nama") fun kelas(): Flow<List<Kelas>>

    @Insert suspend fun insertSiswa(list: List<Siswa>)
    @Delete suspend fun deleteSiswa(s: Siswa)
    @Query("SELECT * FROM Siswa WHERE kelasId=:k ORDER BY nama") fun siswa(k: Long): Flow<List<Siswa>>
    @Query("SELECT * FROM Siswa WHERE kelasId=:k ORDER BY nama") suspend fun siswaOnce(k: Long): List<Siswa>

    @Insert suspend fun insertMapel(m: Mapel)
    @Delete suspend fun deleteMapel(m: Mapel)
    @Query("SELECT * FROM Mapel ORDER BY nama") fun mapel(): Flow<List<Mapel>>

    @Insert suspend fun insertAgenda(a: Agenda): Long
    @Delete suspend fun deleteAgenda(a: Agenda)
    @Query("SELECT * FROM Agenda ORDER BY tanggal DESC, id DESC") fun agenda(): Flow<List<Agenda>>
    @Query("SELECT * FROM Agenda WHERE kelasId=:k AND mapelId=:m ORDER BY tanggal, id")
    suspend fun agendaFor(k: Long, m: Long): List<Agenda>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun savePresensi(list: List<Presensi>)
    @Query("SELECT * FROM Presensi WHERE agendaId=:a") suspend fun presensi(a: Long): List<Presensi>
    @Query("SELECT * FROM Presensi WHERE agendaId IN (:ids)") suspend fun presensiIn(ids: List<Long>): List<Presensi>
}

@Database(entities = [Kelas::class, Siswa::class, Mapel::class, Agenda::class, Presensi::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "agenda_guru.db").build().also { inst = it }
        }
    }
}
