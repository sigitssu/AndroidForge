package id.guru.agenda.data

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File

object PdfReport {
    fun create(ctx: Context, k: Kelas, m: Mapel, ag: List<Agenda>, sw: List<Siswa>, pr: List<Presensi>): File {
        val doc = PdfDocument()
        var n = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, n).create())
        var c = page.canvas
        var y = 50f
        val p = Paint().apply { textSize = 10.5f }
        val b = Paint(p).apply { typeface = Typeface.DEFAULT_BOLD }
        val h = Paint(b).apply { textSize = 15f }

        fun ensure() {
            if (y > 800f) {
                doc.finishPage(page); n++
                page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, n).create())
                c = page.canvas; y = 50f
            }
        }
        fun line(t: String, paint: Paint = p, gap: Float = 16f) { ensure(); c.drawText(t, 40f, y, paint); y += gap }
        fun row(cols: List<String>, xs: List<Float>, paint: Paint = p) {
            ensure(); cols.forEachIndexed { i, t -> c.drawText(t.take(if (i == cols.lastIndex) 70 else 45), xs[i], y, paint) }; y += 16f
        }

        line("LAPORAN AGENDA MENGAJAR & PRESENSI SISWA", h, 24f)
        line("Kelas            : ${k.nama} (${k.tahun})")
        line("Mata Pelajaran: ${m.nama}")
        line("Jumlah pertemuan: ${ag.size}", p, 26f)

        line("A. Agenda Kegiatan Mengajar", b, 20f)
        val xa = listOf(40f, 70f, 140f)
        row(listOf("No", "Tanggal", "Materi / Catatan"), xa, b)
        ag.forEachIndexed { i, a ->
            row(listOf("${i + 1}", a.tanggal, a.topik + if (a.catatan.isNotBlank()) " - ${a.catatan}" else ""), xa)
        }
        y += 14f

        line("B. Rekap Presensi Siswa", b, 20f)
        val xs = listOf(40f, 65f, 130f, 360f, 395f, 430f, 465f, 505f)
        row(listOf("No", "NIS", "Nama", "H", "S", "I", "A", "% Hadir"), xs, b)
        val byS = pr.groupBy { it.siswaId }
        sw.forEachIndexed { i, s ->
            val st = byS[s.id].orEmpty().groupingBy { it.status }.eachCount()
            val hd = st["H"] ?: 0
            val pct = if (ag.isEmpty()) 0 else hd * 100 / ag.size
            row(listOf("${i + 1}", s.nis, s.nama, "$hd", "${st["S"] ?: 0}", "${st["I"] ?: 0}", "${st["A"] ?: 0}", "$pct%"), xs)
        }
        doc.finishPage(page)

        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        val f = File(dir, "laporan_${k.nama}_${m.nama}.pdf".replace(Regex("[^A-Za-z0-9_.-]"), "_"))
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
