# Agenda Guru (Android, Kotlin, Material 3)
Cara build APK:
1. Buka folder ini di Android Studio (Koala / 2024.1+). Biarkan Gradle sync (Studio akan membuat Gradle wrapper otomatis; butuh JDK 17).
2. Build > Build Bundle(s)/APK(s) > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
   Atau lewat terminal: gradle assembleDebug
Format Excel siswa: kolom A = NIS, kolom B = Nama (baris pertama header boleh ada). Simpan sebagai .xlsx.
