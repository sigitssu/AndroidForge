package id.guru.agenda.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Data contoh (statis, hanya untuk tampilan) ----------
private data class AgendaItem(val jam: String, val mapel: String, val kelas: String, val topik: String, val status: Int, val hadir: String)
private val agendaDummy = listOf(
    AgendaItem("07:00 - 08:30", "Matematika", "X IPA 1 • Ruang 12", "Persamaan Kuadrat", 0, "31/32 hadir"),
    AgendaItem("08:45 - 10:15", "Matematika", "X IPA 2 • Ruang 13", "Fungsi Kuadrat", 1, "Presensi belum diisi"),
    AgendaItem("10:30 - 12:00", "Fisika", "XI IPA 1 • Lab Fisika", "Hukum Newton", 2, "Belum dimulai"),
    AgendaItem("13:00 - 14:30", "Matematika", "XI IPS 1 • Ruang 21", "Barisan dan Deret", 2, "Belum dimulai")
)

@Composable
fun AgendaTab() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Jumat, 30 Oktober 2026", fontSize = 13.sp, color = Slate500)
            Text("4 jadwal mengajar hari ini", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Slate800)
            Spacer(Modifier.height(4.dp))
        }
        items(agendaDummy) { AgendaCard(it) }
    }
}

@Composable
private fun AgendaCard(a: AgendaItem) {
    val (label, bg, fg) = when (a.status) {
        0 -> Triple("Selesai", Color(0xFFDCFCE7), Color(0xFF166534))
        1 -> Triple("Berlangsung", Indigo100, Indigo700)
        else -> Triple("Akan datang", Color(0xFFF1F5F9), Slate500)
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Slate200), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Schedule, null, Modifier.size(16.dp), tint = Slate500)
                Spacer(Modifier.width(6.dp))
                Text(a.jam, fontSize = 12.sp, color = Slate500, modifier = Modifier.weight(1f))
                Surface(shape = CircleShape, color = bg) {
                    Text(label, Modifier.padding(horizontal = 10.dp, vertical = 3.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = fg)
                }
            }
            Text(a.mapel, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Slate800)
            Text(a.kelas, fontSize = 13.sp, color = Slate500)
            Text("Materi: ${a.topik}", fontSize = 14.sp, color = Slate800)
            HorizontalDivider(Modifier.padding(vertical = 4.dp), color = Slate200)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Groups, null, Modifier.size(16.dp), tint = Indigo700)
                Spacer(Modifier.width(6.dp))
                Text(a.hadir, fontSize = 12.sp, color = Indigo700, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun LaporanTab() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Pertemuan", "24", Modifier.weight(1f))
            StatCard("Rata-rata hadir", "94%", Modifier.weight(1f))
        }
        Text("Filter laporan", fontWeight = FontWeight.SemiBold, color = Slate800)
        FilterField("Kelas", "X IPA 1")
        FilterField("Mata Pelajaran", "Matematika")
        FilterField("Periode", "Semester Ganjil 2026/2027")
        Spacer(Modifier.weight(1f))
        Button({}, Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Outlined.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("Buat Laporan PDF")
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Indigo50)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Indigo700)
            Text(label, fontSize = 12.sp, color = Slate500)
        }
    }
}

@Composable
private fun FilterField(label: String, value: String) {
    OutlinedCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.outlinedCardColors(containerColor = Color.White)) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 11.sp, color = Slate500)
                Text(value, fontSize = 15.sp, color = Slate800)
            }
            Icon(Icons.Outlined.ArrowDropDown, null, tint = Slate500)
        }
    }
}

// ---------- Layar detail (dari drawer & Pengaturan) ----------
private data class Row3(val title: String, val sub: String, val icon: ImageVector)
private fun listFor(title: String): List<Row3> = when (title) {
    "Tahun Ajaran" -> listOf(Row3("2026/2027 - Ganjil", "Aktif", Icons.Outlined.CalendarMonth),
        Row3("2025/2026 - Genap", "Selesai", Icons.Outlined.CalendarMonth), Row3("2025/2026 - Ganjil", "Selesai", Icons.Outlined.CalendarMonth))
    "Daftar Kelas" -> listOf(Row3("X IPA 1", "32 siswa", Icons.Outlined.MeetingRoom), Row3("X IPA 2", "30 siswa", Icons.Outlined.MeetingRoom),
        Row3("XI IPA 1", "28 siswa", Icons.Outlined.MeetingRoom), Row3("XI IPS 1", "31 siswa", Icons.Outlined.MeetingRoom))
    "Daftar Siswa" -> listOf(Row3("Ahmad Fauzi", "NIS 2026001", Icons.Outlined.Person), Row3("Bella Safitri", "NIS 2026002", Icons.Outlined.Person),
        Row3("Citra Lestari", "NIS 2026003", Icons.Outlined.Person), Row3("Dimas Prakoso", "NIS 2026004", Icons.Outlined.Person))
    "Daftar Mata Pelajaran" -> listOf(Row3("Matematika", "4 kelas", Icons.Outlined.MenuBook), Row3("Fisika", "2 kelas", Icons.Outlined.MenuBook))
    else -> emptyList()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(title: String, onBack: () -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar({ Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Kembali") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White))
        },
        floatingActionButton = {
            when (title) {
                "Pengaturan", "Backup & Restore" -> {}
                "Daftar Siswa" -> ExtendedFloatingActionButton({}, icon = { Icon(Icons.Outlined.UploadFile, null) }, text = { Text("Impor Excel") })
                else -> FloatingActionButton({}) { Icon(Icons.Default.Add, "Tambah") }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (title) {
                "Pengaturan" -> SettingRow(Icons.Outlined.Palette, "Tema")
                "Backup & Restore" -> {
                    SettingRow(Icons.Outlined.Backup, "Cadangkan data")
                    SettingRow(Icons.Outlined.Restore, "Pulihkan data")
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(listFor(title)) { r ->
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Slate200)) {
                            ListItem(
                                headlineContent = { Text(r.title, fontWeight = FontWeight.Medium) },
                                supportingContent = { Text(r.sub) },
                                leadingContent = { Icon(r.icon, null, tint = Indigo700) },
                                trailingContent = { Icon(Icons.Outlined.MoreVert, null, tint = Slate500) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(icon: ImageVector, label: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Slate200)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(16.dp))
            Text(label, Modifier.weight(1f), fontWeight = FontWeight.Medium, color = Slate800)
            Icon(Icons.Default.ChevronRight, null, tint = Slate500)
        }
    }
}
