package id.guru.agenda.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palet indigo + slate, mengikuti mockup (Tailwind indigo/slate)
val Indigo50 = Color(0xFFEEF2FF)
val Indigo100 = Color(0xFFE0E7FF)
val Indigo700 = Color(0xFF4338CA)
val Indigo900 = Color(0xFF312E81)
val Slate50 = Color(0xFFF8FAFC)
val Slate200 = Color(0xFFE2E8F0)
val Slate500 = Color(0xFF64748B)
val Slate800 = Color(0xFF1E293B)

private val Scheme = lightColorScheme(
    primary = Color(0xFF4F46E5), onPrimary = Color.White,
    primaryContainer = Indigo100, onPrimaryContainer = Indigo900,
    secondaryContainer = Indigo100, onSecondaryContainer = Indigo700,
    background = Slate50, onBackground = Slate800,
    surface = Color.White, onSurface = Slate800,
    surfaceVariant = Color(0xFFF1F5F9), onSurfaceVariant = Slate500,
    outlineVariant = Slate200
)

@Composable
fun AgendaGuruTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)
