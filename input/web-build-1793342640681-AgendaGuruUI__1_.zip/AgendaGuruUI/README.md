# Agenda Guru - versi tampilan (UI saja)
Buka di Android Studio, tunggu Gradle sync, lalu Run atau Build > Build APK(s). Semua data hanya contoh statis.
