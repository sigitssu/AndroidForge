package id.gurukelas.app

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private val dao by lazy { SchoolDatabase.get(this).dao() }
    private lateinit var body: LinearLayout
    private lateinit var screenRoot: FrameLayout
    private var floatingActionButton: View? = null
    private val fmt = DateTimeFormatter.ISO_LOCAL_DATE
    private val blue = 0xFF2459A9.toInt()
    private val darkBlue = 0xFF173B70.toInt()
    private val pale = 0xFFF3F6FC.toInt()
    private val months = listOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")

    private val excelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) lifecycleScope.launch {
            runCatching { ExcelImport.import(contentResolver, uri, dao) }
                .onSuccess { toast(it.message); studentScreen() }
                .onFailure { toast("Impor gagal: ${it.message}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 16, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun screen(title: String, subtitle: String = "Kelola administrasi mengajar dengan mudah") {
        screenRoot = FrameLayout(this).apply { setBackgroundColor(pale) }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(12)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); background = rounded(darkBlue, 22); elevation = dp(3).toFloat() }
        header.addView(TextView(this).apply { text = "GURUKELAS"; textSize = 12f; letterSpacing = .12f; setTextColor(0xFFBBD4FF.toInt()); setTypeface(typeface, Typeface.BOLD) })
        header.addView(TextView(this).apply { text = title; textSize = 24f; setTextColor(-1); setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(4), 0, dp(2)) })
        header.addView(TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(0xFFDCE7F8.toInt()) })
        column.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val scroll = ScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(76)); clipToPadding = false }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(1), dp(2), dp(1), dp(8)) }
        scroll.addView(body); column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        screenRoot.addView(column, FrameLayout.LayoutParams(-1, -1))
        floatingActionButton = null
        setContentView(screenRoot)
    }
    private fun label(s: String, size: Float = 15f) { body.addView(TextView(this).apply { text = s; textSize = size; setTextColor(if (size >= 18) darkBlue else 0xFF344054.toInt()); if (size >= 18) setTypeface(typeface, Typeface.BOLD); setPadding(dp(4), dp(8), dp(4), dp(6)) }) }
    private fun button(s: String, primary: Boolean = false, action: () -> Unit) {
        val b = Button(this).apply { text = s; isAllCaps = false; textSize = 14f; setTypeface(typeface, Typeface.BOLD); setTextColor(if (primary) -1 else darkBlue); background = rounded(if (primary) blue else -1, 15, if (primary) null else 0xFFD5E1F2.toInt()); stateListAnimator = null; minHeight = dp(48); setPadding(dp(14), dp(4), dp(14), dp(4)); setOnClickListener { action() } }
        body.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }
    private fun fab(s: String = "+", action: () -> Unit) {
        floatingActionButton?.let { screenRoot.removeView(it) }
        val glyph = if (s.equals("PDF", ignoreCase = true)) "⇩" else "+"
        val b = TextView(this).apply {
            text = glyph; textSize = 30f; gravity = Gravity.CENTER; setTextColor(-1)
            contentDescription = if (s.equals("PDF", ignoreCase = true)) "Ekspor PDF" else "Tambah data"
            background = rounded(0xFFFF824E.toInt(), 28); elevation = dp(8).toFloat()
            minWidth = dp(58); minHeight = dp(58); setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { action() }
        }
        val lp = FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(dp(16), dp(16), dp(20), dp(22))
        }
        screenRoot.addView(b, lp)
        floatingActionButton = b
    }
    private fun field(hintText: String, value: String = ""): EditText {
        val e = EditText(this).apply { hint = hintText; setText(value); textSize = 15f; setTextColor(0xFF101828.toInt()); setHintTextColor(0xFF98A2B3.toInt()); background = rounded(-1, 13, 0xFFD0D9E8.toInt()); setPadding(dp(13), dp(9), dp(13), dp(9)); minHeight = dp(49) }
        body.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }); return e
    }
    private fun <T> spinner(items: List<T>, textOf: (T) -> String = { it.toString() }): Spinner {
        val sp = Spinner(this).apply {
            // Gunakan indikator dropdown bawaan Android agar pilihan terlihat jelas.
            background = getDrawable(android.R.drawable.spinner_background)
            setPadding(dp(10), dp(4), dp(12), dp(4))
            minimumHeight = dp(50)
        }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items.map(textOf))
        body.addView(sp, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) }); return sp
    }
    private fun dateField(initial: LocalDate = LocalDate.now()): TextView {
        val v = TextView(this).apply { text = initial.format(fmt); textSize = 15f; setTextColor(0xFF101828.toInt()); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(14), 0); minHeight = dp(49); background = rounded(-1, 13, 0xFFD0D9E8.toInt()) }
        v.setOnClickListener { pickDate(v.text.toString()) { v.text = it.format(fmt) } }
        body.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }); return v
    }
    private fun pickDate(current: String = LocalDate.now().format(fmt), onPicked: (LocalDate) -> Unit) {
        val d = runCatching { LocalDate.parse(current) }.getOrDefault(LocalDate.now())
        DatePickerDialog(this, { _, y, m, day -> onPicked(LocalDate.of(y, m + 1, day)) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }
    private fun menu(anchor: View, items: List<Pair<String, () -> Unit>>) {
        val pop = PopupMenu(this, anchor); items.forEachIndexed { i, p -> pop.menu.add(0, i, i, p.first) }; pop.setOnMenuItemClickListener { items.getOrNull(it.itemId)?.second?.invoke(); true }; pop.show()
    }
    private fun card(title: String, detail: String, menuItems: List<Pair<String, () -> Unit>> = emptyList()) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(6), dp(10)); background = rounded(-1, 16, 0xFFE3EAF5.toInt()) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(darkBlue); setTypeface(typeface, Typeface.BOLD) })
        if (detail.isNotBlank()) col.addView(TextView(this).apply { text = detail; textSize = 12f; setTextColor(0xFF667085.toInt()); setPadding(0, dp(3), 0, 0) })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (menuItems.isNotEmpty()) { val dots = TextView(this).apply { text = "⋮"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(darkBlue); minWidth = dp(42); setOnClickListener { menu(this, menuItems) } }; row.addView(dots) }
        body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }
    private fun tabBar(selected: String, onSelect: (String) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = rounded(0xFFE5ECF7.toInt(), 14); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        listOf("Harian", "Bulanan").forEach { t -> val v = TextView(this).apply { text = t; gravity = Gravity.CENTER; textSize = 14f; setTypeface(typeface, Typeface.BOLD); setTextColor(if (t == selected) -1 else darkBlue); background = if (t == selected) rounded(blue, 11) else rounded(0xFFE5ECF7.toInt(), 11); setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { onSelect(t) } }; row.addView(v, LinearLayout.LayoutParams(0, -2, 1f)) }
        body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
    private fun years(): List<Int> = (LocalDate.now().year - 5..LocalDate.now().year + 2).toList().reversed()
    private fun monthRange(year: Int, month: Int) = YearMonth.of(year, month).let { it.atDay(1).format(fmt) to it.atEndOfMonth().format(fmt) }

    private fun home() {
        screen("GuruKelas", "Administrasi kelas, agenda, dan presensi dalam satu aplikasi")
        label("DATA MASTER", 18f)
        button("🏫  Daftar Kelas") { classScreen() }
        button("👥  Daftar Siswa") { studentScreen() }
        button("📚  Daftar Mata Pelajaran") { subjectScreen() }
        label("KEGIATAN MENGAJAR", 18f)
        button("🗓️  Agenda Mengajar") { agendaScreen("Harian") }
        label("LAPORAN", 18f)
        button("📄  Laporan Presensi") { attendanceReportScreen("Harian") }
        button("📝  Laporan Agenda") { agendaReportScreen() }
        label("Data disimpan secara lokal di perangkat. Impor siswa Excel tersedia dari menu Daftar Siswa.", 13f)
    }

    private fun classScreen(edit: SchoolClass? = null) {
        screen("Daftar Kelas", "Kelola kelas sebagai data master")
        val name = field("Nama kelas", edit?.name.orEmpty())
        button(if (edit == null) "Simpan Kelas" else "Simpan Perubahan", true) {
            val n = name.text.toString().trim(); if (n.isBlank()) { toast("Nama kelas wajib diisi."); return@button }
            lifecycleScope.launch { runCatching { if (edit == null) dao.addClass(SchoolClass(name = n)) else dao.updateClass(edit.id, n) }
                .onSuccess { toast("Data kelas tersimpan."); classScreen() }.onFailure { toast("Gagal menyimpan. Nama kelas mungkin sudah ada.") } }
        }
        label("Daftar kelas", 18f)
        lifecycleScope.launch {
            val list = dao.observeClasses().first()
            if (list.isEmpty()) label("Belum ada kelas.")
            list.forEach { c -> card(c.name, "Kelas", listOf("Ubah" to { classScreen(c) }, "Hapus" to {
                AlertDialog.Builder(this@MainActivity).setTitle("Hapus kelas?").setMessage("Kelas yang masih memiliki siswa tidak dapat dihapus.").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> lifecycleScope.launch { if (dao.countStudentsInClass(c.id) > 0) toast("Pindahkan atau hapus siswa di kelas ini terlebih dahulu.") else { dao.deleteClass(c.id); toast("Kelas dihapus."); classScreen() } } }.show()
            })) }
        }
        button("Kembali") { home() }
    }

    private fun studentScreen(edit: Student? = null) {
        screen("Daftar Siswa", "Pilih kelas untuk melihat dan mengelola siswa")
        var classes: List<SchoolClass> = emptyList()
        val classSpinner = spinner(emptyList<String>())
        val nis = field("NIS", edit?.studentNumber.orEmpty()); val name = field("Nama lengkap", edit?.fullName.orEmpty())
        val gender = spinner(listOf("Laki-laki", "Perempuan"))
        button(if (edit == null) "Simpan Siswa" else "Simpan Perubahan", true) {
            val cl = classes.getOrNull(classSpinner.selectedItemPosition); val n = name.text.toString().trim(); val no = nis.text.toString().trim()
            if (cl == null || n.isBlank() || no.isBlank()) { toast("NIS, nama, dan kelas wajib diisi."); return@button }
            lifecycleScope.launch { runCatching { if (edit == null) dao.addStudent(Student(studentNumber = no, fullName = n, classId = cl.id, gender = gender.selectedItem.toString())) else dao.updateStudent(edit.id, no, n, cl.id, gender.selectedItem.toString()) }
                .onSuccess { toast("Data siswa tersimpan."); studentScreen() }.onFailure { toast("Gagal menyimpan. NIS mungkin sudah digunakan.") } }
        }
        label("Daftar siswa", 18f)
        lifecycleScope.launch { dao.observeClasses().collect { list -> classes = list; classSpinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, list.map { it.name }); edit?.let { e -> classSpinner.setSelection(list.indexOfFirst { it.id == e.classId }.coerceAtLeast(0)) }; renderStudents(classSpinner, classes) } }
        classSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { if (classes.isNotEmpty()) renderStudents(classSpinner, classes) }
        }
        button("Kembali") { home() }
        fab("+") { AlertDialog.Builder(this).setTitle("Tambah data siswa").setItems(arrayOf("Tambah", "Import")) { _, which -> if (which == 0) studentScreen() else excelPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) }.show() }
    }
    private fun renderStudents(sp: Spinner, classes: List<SchoolClass>) {
        if (classes.isEmpty()) return
        val selected = classes.getOrNull(sp.selectedItemPosition) ?: return
        lifecycleScope.launch { val list = dao.studentsInClass(selected.id); body.findViewWithTag<View>("student-list")?.let { body.removeView(it) }
            val section = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; tag = "student-list" }
            if (list.isEmpty()) section.addView(TextView(this@MainActivity).apply { text = "Belum ada siswa di kelas ${selected.name}."; setPadding(dp(4), dp(8), dp(4), dp(8)) })
            list.forEach { st ->
                val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(4), dp(10)); background = rounded(-1, 14, 0xFFE3EAF5.toInt()) }
                val info = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                info.addView(TextView(this@MainActivity).apply { text = st.fullName; textSize = 15f; setTypeface(typeface, Typeface.BOLD); setTextColor(darkBlue) })
                info.addView(TextView(this@MainActivity).apply { text = "${st.studentNumber} • ${st.gender}"; textSize = 12f; setTextColor(0xFF667085.toInt()) })
                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); val dots = TextView(this@MainActivity).apply { text = "⋮"; textSize = 26f; gravity = Gravity.CENTER; minWidth = dp(42); setTextColor(darkBlue); setOnClickListener { menu(this, listOf("Ubah" to { studentScreen(st) }, "Hapus" to { AlertDialog.Builder(this@MainActivity).setTitle("Hapus siswa?").setMessage(st.fullName).setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> lifecycleScope.launch { dao.deleteStudent(st.id); renderStudents(sp, classes) } }.show() })) } }; row.addView(dots); section.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
            val idx = body.indexOfChild(sp); body.addView(section, if (idx >= 0) idx + 1 else body.childCount)
        }
    }

    private fun subjectScreen(edit: SchoolSubject? = null) {
        screen("Daftar Mata Pelajaran", "Kelola mata pelajaran sebagai data master")
        val name = field("Nama mata pelajaran", edit?.name.orEmpty())
        button(if (edit == null) "Simpan Mata Pelajaran" else "Simpan Perubahan", true) { val n = name.text.toString().trim(); if (n.isBlank()) { toast("Nama mata pelajaran wajib diisi."); return@button }; lifecycleScope.launch { runCatching { if (edit == null) dao.addSubject(SchoolSubject(name = n)) else dao.updateSubject(edit.id, n) }.onSuccess { toast("Mata pelajaran tersimpan."); subjectScreen() }.onFailure { toast("Gagal menyimpan. Nama mungkin sudah ada.") } } }
        label("Daftar mata pelajaran", 18f)
        lifecycleScope.launch { val list = dao.observeSubjects().first(); if (list.isEmpty()) label("Belum ada mata pelajaran."); list.forEach { s -> card(s.name, "Mata pelajaran", listOf("Ubah" to { subjectScreen(s) }, "Hapus" to { AlertDialog.Builder(this@MainActivity).setTitle("Hapus mata pelajaran?").setMessage(s.name).setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> lifecycleScope.launch { dao.deleteSubject(s.id); toast("Mata pelajaran dihapus."); subjectScreen() } }.show() })) } }
        button("Kembali") { home() }
    }

    private fun agendaScreen(initialTab: String = "Harian") { renderAgenda(initialTab) }
    private fun renderAgenda(tab: String, chosenDate: LocalDate = LocalDate.now(), chosenMonth: Int = LocalDate.now().monthValue, chosenYear: Int = LocalDate.now().year) {
        screen("Agenda Mengajar", "Daftar agenda terbaru dan presensi per agenda")
        tabBar(tab) { renderAgenda(it, chosenDate, chosenMonth, chosenYear) }
        var dateSelected = chosenDate
        var monthSelected = chosenMonth
        var yearSelected = chosenYear
        if (tab == "Harian") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val monthSp = Spinner(this); monthSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, months); monthSp.setSelection(monthSelected - 1)
            val yearSp = Spinner(this); yearSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, years()); yearSp.setSelection(years().indexOf(yearSelected).coerceAtLeast(0))
            row.addView(monthSp, LinearLayout.LayoutParams(0, dp(48), 1f)); row.addView(yearSp, LinearLayout.LayoutParams(0, dp(48), 1f)); body.addView(row)
            val days = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val horiz = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(days) }; body.addView(horiz, LinearLayout.LayoutParams(-1, dp(64)))
            fun reloadDates() { days.removeAllViews(); val ym = YearMonth.of(yearSelected, monthSelected); for (day in 1..ym.lengthOfMonth()) { val d = ym.atDay(day); val b = TextView(this).apply { text = "${d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale("id", "ID"))}\n$day"; gravity = Gravity.CENTER; textSize = 12f; setTextColor(if (d == dateSelected) -1 else darkBlue); background = rounded(if (d == dateSelected) blue else -1, 12, 0xFFD5E1F2.toInt()); setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { renderAgenda("Harian", d, monthSelected, yearSelected) } }; days.addView(b, LinearLayout.LayoutParams(dp(58), dp(54)).apply { marginEnd = dp(5) }) } }
            monthSp.onItemSelectedListener = simpleListener { monthSelected = it + 1; renderAgenda("Harian", dateSelected, monthSelected, yearSelected) }
            yearSp.onItemSelectedListener = simpleListener { yearSelected = years()[it]; renderAgenda("Harian", dateSelected, monthSelected, yearSelected) }
            reloadDates()
        } else {
            val yearSp = spinner(years()); yearSp.setSelection(years().indexOf(yearSelected).coerceAtLeast(0)); val monthsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(monthsRow) }; body.addView(hs, LinearLayout.LayoutParams(-1, dp(56)))
            months.forEachIndexed { i, m -> val v = TextView(this).apply { text = m; gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); setTextColor(if (i + 1 == monthSelected) -1 else darkBlue); background = rounded(if (i + 1 == monthSelected) blue else -1, 12, 0xFFD5E1F2.toInt()); setOnClickListener { renderAgenda("Bulanan", chosenDate, i + 1, yearSelected) } }; monthsRow.addView(v, LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(5) }) }
            yearSp.onItemSelectedListener = simpleListener { renderAgenda("Bulanan", chosenDate, monthSelected, years()[it]) }
        }
        button("＋ Tambah Agenda", true) { agendaForm() }
        val range = if (tab == "Harian") dateSelected.format(fmt) to dateSelected.format(fmt) else monthRange(yearSelected, monthSelected)
        lifecycleScope.launch { val list = dao.agendasInRangeNewestFirst(range.first, range.second); if (list.isEmpty()) label("Belum ada agenda pada periode ini.") else list.forEach { a -> card("${a.date} • ${a.className}", "${a.subject} — ${a.topic}", listOf("Presensi" to { attendanceForAgenda(a) }, "Hapus" to { AlertDialog.Builder(this@MainActivity).setTitle("Hapus agenda?").setMessage("${a.date} • ${a.subject}").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> lifecycleScope.launch { dao.deleteAgenda(a.id); renderAgenda(tab, dateSelected, monthSelected, yearSelected) } }.show() })) } }
        button("Kembali") { home() }
    }
    private fun simpleListener(action: (Int) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        private var firstEvent = true
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
            if (firstEvent) { firstEvent = false; return }; action(position)
        }
    }

    private fun agendaForm() {
        screen("Tambah Agenda", "Tanggal, kelas, dan mata pelajaran diambil dari data master")
        label("Tanggal")
        val date = dateField()
        label("Kelas")
        val cls = spinner(emptyList<String>()); label("Mata Pelajaran"); val subj = spinner(emptyList<String>())
        val topic = field("Materi / topik"); val activity = field("Kegiatan pembelajaran"); val reflection = field("Refleksi (opsional)")
        var classes: List<SchoolClass> = emptyList(); var subjects: List<SchoolSubject> = emptyList()
        lifecycleScope.launch { dao.observeClasses().collect { classes = it; cls.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, it.map { c -> c.name }) } }
        lifecycleScope.launch { dao.observeSubjects().collect { subjects = it; subj.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, it.map { s -> s.name }) } }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = Button(this).apply { text = "Simpan"; isAllCaps = false; setTextColor(-1); background = rounded(blue); setOnClickListener { val c = classes.getOrNull(cls.selectedItemPosition); val s = subjects.getOrNull(subj.selectedItemPosition); val t = topic.text.toString().trim(); if (c == null || s == null || t.isBlank()) { toast("Tambahkan kelas dan mata pelajaran terlebih dahulu; materi wajib diisi."); return@setOnClickListener }; lifecycleScope.launch { dao.addAgenda(TeachingAgenda(date = date.text.toString(), className = c.name, subject = s.name, topic = t, activity = activity.text.toString().trim(), reflection = reflection.text.toString().trim())); toast("Agenda tersimpan."); agendaScreen("Harian") } } }
        val back = Button(this).apply { text = "Kembali"; isAllCaps = false; background = rounded(-1, 14, 0xFFD5E1F2.toInt()); setTextColor(darkBlue); setOnClickListener { agendaScreen() } }
        actions.addView(back, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(5) }); actions.addView(save, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(5) }); body.addView(actions)
    }

    private fun attendanceForAgenda(a: TeachingAgenda) {
        screen("Presensi Siswa", "${a.date} • ${a.className} • ${a.subject}\nMateri: ${a.topic}")
        lifecycleScope.launch {
            val cls = dao.classByName(a.className)
            if (cls == null) { label("Kelas agenda tidak ditemukan."); return@launch }
            val students = dao.attendanceForClass(cls.id, a.date)
            if (students.isEmpty()) label("Belum ada siswa pada kelas ini.")
            val choices = listOf("Hadir", "Izin", "Sakit", "Alpa")
            val selections = linkedMapOf<Long, Spinner>()
            students.forEach { st ->
                label("${st.studentNumber} • ${st.fullName}")
                val sp = spinner(choices); sp.setSelection(choices.indexOf(st.status ?: "Hadir").takeIf { it >= 0 } ?: 0); selections[st.studentId] = sp
            }
            val actions = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
            val cancel = Button(this@MainActivity).apply { text = "Batal"; isAllCaps = false; setOnClickListener { agendaScreen() } }
            val save = Button(this@MainActivity).apply { text = "Simpan"; isAllCaps = false; setTextColor(-1); background = rounded(blue); setOnClickListener { lifecycleScope.launch { selections.forEach { (id, sp) -> dao.saveAttendance(Attendance(studentId = id, date = a.date, status = sp.selectedItem.toString())) }; toast("Presensi tersimpan."); agendaScreen() } } }
            actions.addView(cancel, LinearLayout.LayoutParams(0, dp(50), 1f)); actions.addView(save, LinearLayout.LayoutParams(0, dp(50), 1f)); body.addView(actions)
        }
    }

    private fun attendanceReportScreen(tab: String) { renderAttendanceReport(tab) }
    private fun renderAttendanceReport(tab: String, date: LocalDate = LocalDate.now(), month: Int = LocalDate.now().monthValue, year: Int = LocalDate.now().year, classId: Long? = null) {
        screen("Laporan Presensi", "Lihat rekap kehadiran dan ekspor PDF")
        tabBar(tab) { renderAttendanceReport(it, date, month, year, classId) }
        var selectedDate = date; var selectedMonth = month; var selectedYear = year
        var classes: List<SchoolClass> = emptyList(); var selectedClass = classId
        if (tab == "Harian") {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; val monthSp = Spinner(this); monthSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, months); monthSp.setSelection(month - 1); val yearSp = Spinner(this); yearSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, years()); yearSp.setSelection(years().indexOf(year).coerceAtLeast(0)); row.addView(monthSp, LinearLayout.LayoutParams(0, dp(48), 1f)); row.addView(yearSp, LinearLayout.LayoutParams(0, dp(48), 1f)); body.addView(row)
            label("Kelas"); val classSp = spinner(emptyList<String>()); lifecycleScope.launch { dao.observeClasses().collect { classes = it; classSp.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Semua kelas") + it.map { c -> c.name }); val idx = classes.indexOfFirst { c -> c.id == selectedClass }; classSp.setSelection(if (idx >= 0) idx + 1 else 0) } }
            classSp.onItemSelectedListener = simpleListener { selectedClass = classes.getOrNull(it - 1)?.id; renderAttendanceReport("Harian", selectedDate, selectedMonth, selectedYear, selectedClass) }
            val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(dayRow) }; body.addView(hs, LinearLayout.LayoutParams(-1, dp(60)))
            val ym = YearMonth.of(year, month); for (dnum in 1..ym.lengthOfMonth()) { val d = ym.atDay(dnum); val v = TextView(this).apply { text = "${d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale("id", "ID"))}\n$dnum"; gravity = Gravity.CENTER; setPadding(dp(11), dp(5), dp(11), dp(5)); setTextColor(if (d == date) -1 else darkBlue); background = rounded(if (d == date) blue else -1, 12, 0xFFD5E1F2.toInt()); setOnClickListener { renderAttendanceReport("Harian", d, month, year, selectedClass) } }; dayRow.addView(v, LinearLayout.LayoutParams(dp(56), dp(52)).apply { marginEnd = dp(5) }) }
            monthSp.onItemSelectedListener = simpleListener { renderAttendanceReport("Harian", selectedDate, it + 1, selectedYear, selectedClass) }; yearSp.onItemSelectedListener = simpleListener { renderAttendanceReport("Harian", selectedDate, selectedMonth, years()[it], selectedClass) }
        } else {
            val yearSp = spinner(years()); yearSp.setSelection(years().indexOf(year).coerceAtLeast(0)); val mr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; body.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(mr) }, LinearLayout.LayoutParams(-1, dp(56))); months.forEachIndexed { i, m -> val v = TextView(this).apply { text = m; gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); setTextColor(if (i + 1 == month) -1 else darkBlue); background = rounded(if (i + 1 == month) blue else -1, 12, 0xFFD5E1F2.toInt()); setOnClickListener { renderAttendanceReport("Bulanan", date, i + 1, selectedYear) } }; mr.addView(v, LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(5) }) }; yearSp.onItemSelectedListener = simpleListener { renderAttendanceReport("Bulanan", date, selectedMonth, years()[it]) }
        }
        val range = if (tab == "Harian") date.format(fmt) to date.format(fmt) else monthRange(year, month)
        lifecycleScope.launch { val rows = dao.attendanceReportRows(range.first, range.second).filter { selectedClass == null || it.className == classes.firstOrNull { c -> c.id == selectedClass }?.name }; if (rows.isEmpty()) label("Belum ada presensi pada periode ini.") else rows.groupBy { it.date }.toSortedMap(compareByDescending { it }).forEach { (d, items) -> label(d, 17f); val counts = items.groupingBy { it.status }.eachCount(); card("Hadir ${counts["Hadir"] ?: 0} • Izin ${counts["Izin"] ?: 0}", "Sakit ${counts["Sakit"] ?: 0} • Alpa ${counts["Alpa"] ?: 0} • ${items.size} siswa") } }
        fab("PDF") { val rangePdf = if (tab == "Harian") date.format(fmt) to date.format(fmt) else monthRange(year, month); lifecycleScope.launch { runCatching { makeAttendancePdf(rangePdf.first, rangePdf.second, tab == "Bulanan", dao.attendanceReportRows(rangePdf.first, rangePdf.second)) }.onSuccess { toast("PDF tersimpan: Download/GuruKelas/$it") }.onFailure { toast("Gagal membuat PDF: ${it.message}") } } }
        button("Kembali") { home() }
    }

    private fun agendaReportScreen() {
        screen("Laporan Agenda", "Pilih rentang tanggal untuk laporan PDF")
        label("Tanggal awal"); val from = dateField(LocalDate.now().withDayOfMonth(1)); label("Tanggal akhir"); val to = dateField()
        button("Tampilkan", true) { val f = from.text.toString(); val t = to.text.toString(); if (f > t) toast("Tanggal awal tidak boleh melebihi tanggal akhir.") else lifecycleScope.launch { val list = dao.agendasBetween(f, t); label("Hasil: ${list.size} agenda", 18f); list.sortedByDescending { it.date }.forEach { card("${it.date} • ${it.className}", "${it.subject} — ${it.topic}") } } }
        fab("PDF") { val f = from.text.toString(); val t = to.text.toString(); if (f > t) toast("Rentang tanggal tidak valid.") else lifecycleScope.launch { runCatching { makeAgendaPdf(f, t, dao.agendasInRangeNewestFirst(f, t)) }.onSuccess { toast("PDF tersimpan: Download/GuruKelas/$it") }.onFailure { toast("Gagal membuat PDF: ${it.message}") } } }
        button("Kembali") { home() }
    }

    private fun makeAttendancePdf(from: String, to: String, monthly: Boolean, rows: List<AttendanceReportRow>): String {
        val doc = PdfDocument(); val groups = if (monthly) rows.groupBy { it.date }.toSortedMap().map { it.key to it.value } else listOf(from to rows); val chunks = (if (groups.isEmpty()) listOf(emptyList()) else groups.chunked(4)); var pageNo = 1
        chunks.forEach { chunk -> val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo++).create()); val p = Paint().apply { color = android.graphics.Color.BLACK }; var y = 42f
            fun line(s: String, bold: Boolean = false) { p.textSize = if (bold) 15f else 10f; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; page.canvas.drawText(s.take(95), 36f, y, p); y += if (bold) 24f else 16f }
            line(if (monthly) "REKAP PRESENSI BULANAN" else "LAPORAN PRESENSI HARIAN", true); line("Periode: $from s.d. $to"); if (rows.isEmpty()) line("Belum ada data presensi.")
            chunk.forEach { (d, items) -> if (monthly) line("Tanggal: $d", true); val counts = items.groupingBy { it.status }.eachCount(); line("Hadir ${counts["Hadir"] ?: 0} | Izin ${counts["Izin"] ?: 0} | Sakit ${counts["Sakit"] ?: 0} | Alpa ${counts["Alpa"] ?: 0}"); items.forEach { line("${it.className} | ${it.studentNumber} | ${it.fullName} | ${it.status}") }; y += 8 }
            doc.finishPage(page) }
        val filename = "Presensi_${from}_${to}.pdf"; savePdf(doc, filename); return filename
    }
    private fun makeAgendaPdf(from: String, to: String, agendas: List<TeachingAgenda>): String {
        val doc = PdfDocument(); var pageNo = 1; var index = 0; val pages = agendas.chunked(25).ifEmpty { listOf(emptyList()) }
        pages.forEach { chunk -> val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo++).create()); val p = Paint().apply { color = android.graphics.Color.BLACK }; var y = 48f
            fun line(s: String, bold: Boolean = false) { p.textSize = if (bold) 15f else 10f; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; page.canvas.drawText(s.take(95), 40f, y, p); y += if (bold) 24f else 16f }
            if (index == 0) { line("LAPORAN AGENDA MENGAJAR", true); line("Periode: $from sampai $to"); y += 8 }; if (agendas.isEmpty()) line("Tidak ada agenda pada periode ini.")
            chunk.forEach { a -> line("${a.date} | ${a.className} | ${a.subject}", true); line("Materi: ${a.topic}"); if (a.activity.isNotBlank()) line("Kegiatan: ${a.activity}"); if (a.reflection.isNotBlank()) line("Refleksi: ${a.reflection}"); y += 6 }; index += chunk.size; doc.finishPage(page) }
        val filename = "Agenda_${from}_$to.pdf"; savePdf(doc, filename); return filename
    }
    private fun savePdf(doc: PdfDocument, filename: String) { val values = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, filename); put(MediaStore.Downloads.MIME_TYPE, "application/pdf"); put(MediaStore.Downloads.RELATIVE_PATH, "Download/GuruKelas") }; val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Tidak dapat membuat file PDF"); contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) } ?: error("Gagal menulis PDF"); doc.close() }
}
