# Agenda Guru - Rancangan Database (Room / SQLite, lokal)

Berkas database: `agenda_guru.db` (folder database internal aplikasi). Versi skema: 1.

## Tabel
| Tabel | Kolom penting | Keterangan |
|---|---|---|
| profil | id=1, nama, nip, sekolah, fotoPath | Data awal: Pampam Bamungkas, 1234567890, SMK Negeri 1. Tanpa foto -> inisial nama |
| tahun_ajaran | id, awal, akhir (epoch day), semester, aktif | Tepat satu baris aktif. Baru dibuat = langsung aktif. Jika yang aktif dihapus, yang terbaru (awal terbesar) diaktifkan |
| kelas | id, tahunId -> tahun_ajaran, nama | Unik per tahun ajaran |
| siswa | id, kelasId -> kelas, nis, nama, jk | NIS unik per kelas |
| mapel | id, tahunId -> tahun_ajaran, nama | Unik per tahun ajaran |
| mapel_kelas | mapelId, kelasId (PK gabungan) | Satu mapel dapat dimiliki banyak kelas |
| agenda | id, kelasId, mapelId, tanggal, mulai, selesai (menit), topik, catatan | selesai > mulai, tanggal di dalam rentang tahun ajaran, tidak bentrok pada kelas+tanggal yang sama |
| presensi | id, agendaId, siswaId, status | status: Hadir/Sakit/Izin/Alpa; unik (agendaId, siswaId) |
| nilai | id, kelasId, mapelId, nama | Item daftar nilai (Tugas 1, UTS, ...); unik per kelas+mapel |
| nilai_siswa | id, nilaiId, siswaId, skor | skor 0-100; unik (nilaiId, siswaId) |

Semua relasi memakai `ON DELETE CASCADE`: menghapus tahun ajaran menghapus seluruh kelas, siswa, mapel, agenda, presensi, dan nilai di dalamnya.

## Pengaturan non-database
Tema (mode, warna, warna kustom) disimpan di SharedPreferences `tema`. Foto profil disimpan di folder file internal aplikasi.
