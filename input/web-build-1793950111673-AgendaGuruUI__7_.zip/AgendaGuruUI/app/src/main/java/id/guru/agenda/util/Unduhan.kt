package id.guru.agenda.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import java.io.File
import java.io.IOException

class HasilLaporan(val sukses: Boolean, val pesan: String, val uri: Uri? = null, val mime: String? = null)

class HasilSimpan(val uri: Uri?, val nama: String)

/** Menyimpan file langsung ke folder Download perangkat. */
object Unduhan {
    fun simpan(ctx: Context, nama: String, mime: String, data: ByteArray): HasilSimpan {
        return if (Build.VERSION.SDK_INT >= 29) simpanModern(ctx, nama, mime, data) else simpanLama(nama, data)
    }

    @RequiresApi(29)
    private fun simpanModern(ctx: Context, nama: String, mime: String, data: ByteArray): HasilSimpan {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, nama)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Tidak dapat membuat file di folder Download")
        val stream = resolver.openOutputStream(uri) ?: throw IOException("Tidak dapat menulis file")
        stream.use { it.write(data) }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return HasilSimpan(uri, nama)
    }

    private fun simpanLama(nama: String, data: ByteArray): HasilSimpan {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        var f = File(dir, nama)
        var n = 1
        val pangkal = nama.substringBeforeLast('.')
        val ekstensi = nama.substringAfterLast('.', "")
        while (f.exists()) {
            f = File(dir, "$pangkal ($n)" + if (ekstensi.isEmpty()) "" else ".$ekstensi")
            n++
        }
        f.writeBytes(data)
        return HasilSimpan(null, f.name)
    }
}
