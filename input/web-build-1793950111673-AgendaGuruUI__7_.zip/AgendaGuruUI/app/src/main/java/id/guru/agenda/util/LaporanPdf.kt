package id.guru.agenda.util

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import id.guru.agenda.data.AgendaView
import id.guru.agenda.data.PresensiTanggal
import id.guru.agenda.data.Siswa
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.YearMonth

class DataLaporanAgenda(
    val sekolah: String,
    val guru: String,
    val nip: String,
    val tahun: String,
    val kelas: String,
    val mapel: String,
    val periode: String,
    val agenda: List<AgendaView>,
    val siswa: List<Siswa>,
    val presensi: List<PresensiTanggal>
)

private const val TEPI = 40f
private const val PAD = 3f
private const val GARIS_TEKS = 12f

// ukuran baris tabel presensi (lebih rapat agar muat banyak siswa dan tanggal)
private const val PAD_P = 2f
private const val GARIS_P = 9.5f
private const val TINGGI_HEADER = 13f

private class BarisPresensi(
    val no: Int, val nis: String, val nama: String, val jk: String,
    val sel: List<String>, val h: Int, val s: Int, val i: Int, val a: Int, val persen: String
)

private class Pena(val doc: PdfDocument) {
    var nomor = 0
    var mendatar = false
    var lebar = 595f
    var tinggi = 842f
    lateinit var halaman: PdfDocument.Page
    lateinit var kanvas: Canvas
    var y = TEPI

    val teks = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; color = 0xFF000000.toInt() }
    val tebal = Paint(teks).apply { typeface = Typeface.DEFAULT_BOLD }
    val judul = Paint(tebal).apply { textSize = 15f }
    val kecil = Paint(teks).apply { textSize = 8f }
    val kecilTebal = Paint(kecil).apply { typeface = Typeface.DEFAULT_BOLD }
    val garis = Paint().apply { color = 0xFF555555.toInt(); strokeWidth = 0.6f; style = Paint.Style.STROKE }
    val latarHeader = Paint().apply { color = 0xFFD8D8D8.toInt(); style = Paint.Style.FILL }

    init { baru(false) }

    fun baru(landscape: Boolean = mendatar) {
        if (nomor > 0) doc.finishPage(halaman)
        nomor++
        mendatar = landscape
        lebar = if (landscape) 842f else 595f
        tinggi = if (landscape) 595f else 842f
        halaman = doc.startPage(PdfDocument.PageInfo.Builder(lebar.toInt(), tinggi.toInt(), nomor).create())
        kanvas = halaman.canvas
        y = TEPI
    }

    fun selesai() { doc.finishPage(halaman) }

    fun pastikan(t: Float) { if (y + t > tinggi - TEPI) baru() }

    fun baris(t: String, p: Paint = teks, gap: Float = GARIS_TEKS + 2f, x: Float = TEPI) {
        pastikan(gap)
        kanvas.drawText(t, x, y + 9f, p)
        y += gap
    }

    fun spasi(h: Float) { y += h }

    fun bungkus(t: String, lebarMaks: Float, p: Paint): List<String> {
        val hasil = mutableListOf<String>()
        for (para in t.split("\n")) {
            var cur = ""
            for (kata in para.split(" ")) {
                var k = kata
                while (lebarMaks > 0 && p.measureText(k) > lebarMaks) {
                    val n = p.breakText(k, true, lebarMaks, null)
                    if (n <= 0) break
                    if (cur.isNotEmpty()) { hasil.add(cur); cur = "" }
                    hasil.add(k.substring(0, n))
                    k = k.substring(n)
                }
                val coba = if (cur.isEmpty()) k else "$cur $k"
                if (p.measureText(coba) <= lebarMaks) cur = coba else { hasil.add(cur); cur = k }
            }
            hasil.add(cur)
        }
        return hasil
    }

    /** Blok informasi dengan titik dua yang sejajar (seperti tabel tanpa border). */
    fun info(pasangan: List<Pair<String, String>>) {
        val lebarLabel = pasangan.maxOf { teks.measureText(it.first) }
        val xKolon = TEPI + lebarLabel + 4f
        val xNilai = xKolon + 10f
        for ((k, v) in pasangan) {
            val bk = bungkus(v, lebar - TEPI - xNilai, teks)
            pastikan(bk.size * GARIS_TEKS + 2f)
            kanvas.drawText(k, TEPI, y + 9f, teks)
            kanvas.drawText(":", xKolon, y + 9f, teks)
            for (baris in bk) {
                kanvas.drawText(baris, xNilai, y + 9f, teks)
                y += GARIS_TEKS
            }
            y += 2f
        }
    }

    /** Tanda tangan: baris titik-titik kosong (tempat dan tanggal ditulis manual), lalu nama guru. */
    fun tandaTangan(guru: String, nip: String) {
        val lebarBlok = 190f
        val namaBaris = bungkus(guru, lebarBlok, tebal)
        pastikan(110f + namaBaris.size * GARIS_TEKS)
        val x = lebar - TEPI - lebarBlok
        y += 14f
        var titik = ""
        while (teks.measureText("$titik.") < lebarBlok - 6f) titik += "."
        kanvas.drawText(titik, x, y + 9f, teks)
        y += 16f
        kanvas.drawText("Guru Mata Pelajaran,", x, y + 9f, teks)
        y += 58f
        for (b in namaBaris) {
            kanvas.drawText(b, x, y + 9f, tebal)
            y += GARIS_TEKS
        }
        kanvas.drawText("NIP $nip", x, y + 9f, teks)
        y += GARIS_TEKS
    }

    // ---------------------------------------------------------------- tabel umum (daftar agenda)
    private fun ukur(lebarKol: List<Float>, sel: List<String>, p: Paint): Pair<List<List<String>>, Float> {
        val bk = sel.mapIndexed { i, t -> bungkus(t, lebarKol[i] - 2 * PAD, p) }
        return Pair(bk, (bk.maxOf { it.size }) * GARIS_TEKS + 2 * PAD)
    }

    private fun gambar(lebarKol: List<Float>, bk: List<List<String>>, tinggiBaris: Float, p: Paint, tengah: Set<Int>, latar: Boolean) {
        var x = TEPI
        if (latar) kanvas.drawRect(TEPI, y, TEPI + lebarKol.sum(), y + tinggiBaris, latarHeader)
        lebarKol.forEachIndexed { i, w ->
            kanvas.drawRect(x, y, x + w, y + tinggiBaris, garis)
            bk[i].forEachIndexed { j, s ->
                val tx = if (i in tengah) x + (w - p.measureText(s)) / 2f else x + PAD
                kanvas.drawText(s, tx, y + PAD + (j + 1) * GARIS_TEKS - 3f, p)
            }
            x += w
        }
        y += tinggiBaris
    }

    fun tabel(lebarKol: List<Float>, header: List<String>, isi: List<List<String>>, tengah: Set<Int>) {
        val semuaTengah = header.indices.toSet()
        val (bh, th) = ukur(lebarKol, header, tebal)
        pastikan(th + 30f)
        gambar(lebarKol, bh, th, tebal, semuaTengah, true)
        for (r in isi) {
            val (bk, t) = ukur(lebarKol, r, teks)
            if (y + t > tinggi - TEPI) {
                baru()
                gambar(lebarKol, bh, th, tebal, semuaTengah, true)
            }
            gambar(lebarKol, bk, t, teks, tengah, false)
        }
    }

    // ---------------------------------------------------------------- tabel rekap presensi (format Excel referensi)
    fun tabelPresensi(hari: List<String>, isi: List<BarisPresensi>) {
        val n = hari.size
        val tersedia = lebar - 2 * TEPI
        val wNo = 22f
        val wNis = 56f
        val wJk = 22f
        val wJml = 20f
        val wPersen = 36f
        val sisa = tersedia - (wNo + wNis + wJk + 4 * wJml + wPersen)
        val wTgl = ((sisa - 110f) / n).coerceIn(10f, 26f)
        val wNama = sisa - n * wTgl

        fun kotak(x0: Float, w: Float, y0: Float, h: Float, t: String) {
            kanvas.drawRect(x0, y0, x0 + w, y0 + h, latarHeader)
            kanvas.drawRect(x0, y0, x0 + w, y0 + h, garis)
            kanvas.drawText(t, x0 + (w - kecilTebal.measureText(t)) / 2f, y0 + h / 2f + 3f, kecilTebal)
        }

        fun header() {
            val dua = TINGGI_HEADER * 2
            var x = TEPI
            kotak(x, wNo, y, dua, "No"); x += wNo
            kotak(x, wNis, y, dua, "NIS"); x += wNis
            kotak(x, wNama, y, dua, "Nama Siswa"); x += wNama
            kotak(x, wJk, y, dua, "L/P"); x += wJk
            kotak(x, n * wTgl, y, TINGGI_HEADER, "TANGGAL")
            hari.forEachIndexed { i, t -> kotak(x + i * wTgl, wTgl, y + TINGGI_HEADER, TINGGI_HEADER, t) }
            x += n * wTgl
            kotak(x, 4 * wJml, y, TINGGI_HEADER, "JUMLAH")
            listOf("H", "S", "I", "A").forEachIndexed { i, t -> kotak(x + i * wJml, wJml, y + TINGGI_HEADER, TINGGI_HEADER, t) }
            x += 4 * wJml
            kotak(x, wPersen, y, dua, "% Hadir")
            y += dua
        }

        pastikan(TINGGI_HEADER * 2 + 40f)
        header()
        for (b in isi) {
            val namaBaris = bungkus(b.nama, wNama - 2 * PAD_P - 1f, kecil)
            val tinggiBaris = namaBaris.size * GARIS_P + 2 * PAD_P
            if (y + tinggiBaris > tinggi - TEPI) {
                baru()
                header()
            }
            var x = TEPI
            val tengahY = y + tinggiBaris / 2f + 3f
            fun sel(w: Float, t: String, tengah: Boolean) {
                kanvas.drawRect(x, y, x + w, y + tinggiBaris, garis)
                val tx = if (tengah) x + (w - kecil.measureText(t)) / 2f else x + PAD_P
                kanvas.drawText(t, tx, tengahY, kecil)
                x += w
            }
            sel(wNo, "${b.no}", true)
            sel(wNis, b.nis, false)
            // kolom nama boleh lebih dari satu baris
            kanvas.drawRect(x, y, x + wNama, y + tinggiBaris, garis)
            namaBaris.forEachIndexed { j, s ->
                kanvas.drawText(s, x + PAD_P, y + PAD_P + (j + 1) * GARIS_P - 1.5f, kecil)
            }
            x += wNama
            sel(wJk, b.jk, true)
            b.sel.forEach { sel(wTgl, it, true) }
            sel(wJml, "${b.h}", true)
            sel(wJml, "${b.s}", true)
            sel(wJml, "${b.i}", true)
            sel(wJml, "${b.a}", true)
            sel(wPersen, b.persen, true)
            y += tinggiBaris
        }
    }
}

object LaporanPdf {
    private fun ym(tgl: Long): YearMonth = YearMonth.from(LocalDate.ofEpochDay(tgl))

    private fun huruf(status: String?): String = when (status) {
        "Hadir" -> "H"
        "Sakit" -> "S"
        "Izin" -> "I"
        "Alpa" -> "A"
        else -> ""
    }

    fun buat(d: DataLaporanAgenda): ByteArray {
        val doc = PdfDocument()
        val p = Pena(doc)

        // ============================================================ BAGIAN 1: AGENDA MENGAJAR
        p.baris("LAPORAN AGENDA MENGAJAR", p.judul, 22f)
        p.info(
            listOf(
                "Sekolah" to d.sekolah,
                "Guru" to "${d.guru} (NIP ${d.nip})",
                "Tahun Ajaran" to d.tahun,
                "Kelas" to d.kelas,
                "Mata Pelajaran" to d.mapel,
                "Periode" to d.periode
            )
        )
        p.spasi(10f)
        val lebarAgenda = listOf(26f, 80f, 64f, 190f, 155f)
        val barisAgenda = d.agenda.mapIndexed { i, a ->
            listOf("${i + 1}", Fmt.tanggal(a.tanggal, "d MMM yyyy"), Fmt.rentang(a.mulai, a.selesai), a.topik, a.catatan.ifBlank { "-" })
        }
        p.tabel(lebarAgenda, listOf("No", "Tanggal", "Waktu", "Topik Pembelajaran", "Catatan"), barisAgenda, setOf(0, 1, 2))
        p.tandaTangan(d.guru, d.nip)

        // ============================================================ BAGIAN 2: REKAP PRESENSI (tiap bulan = halaman baru)
        val bulanList = d.agenda.map { ym(it.tanggal) }.distinct().sorted()
        if (d.siswa.isEmpty()) {
            p.baru(false)
            p.baris("REKAP PRESENSI SISWA", p.judul, 22f)
            p.baris("Belum ada siswa terdaftar pada kelas ini.")
        } else {
            val peta = HashMap<Pair<Long, Long>, String>()
            for (r in d.presensi) peta[Pair(r.agendaId, r.siswaId)] = r.status

            for (bulan in bulanList) {
                val ag = d.agenda.filter { ym(it.tanggal) == bulan }.sortedWith(compareBy({ it.tanggal }, { it.mulai }))
                // banyak pertemuan -> halaman mendatar agar semua kolom tanggal muat
                p.baru(ag.size > 18)
                p.baris("REKAP PRESENSI SISWA", p.judul, 22f)
                p.info(
                    listOf(
                        "Sekolah" to d.sekolah,
                        "Tahun Ajaran" to d.tahun,
                        "Kelas" to d.kelas,
                        "Mata Pelajaran" to d.mapel,
                        "Bulan" to Fmt.bulan(bulan)
                    )
                )
                p.spasi(8f)

                val hari = ag.map { LocalDate.ofEpochDay(it.tanggal).dayOfMonth.toString() }
                val isi = d.siswa.mapIndexed { i, s ->
                    val st = ag.map { a -> peta[Pair(a.id, s.id)] }
                    val h = st.count { it == "Hadir" }
                    val persen = Math.round(h * 100f / ag.size)
                    BarisPresensi(
                        no = i + 1, nis = s.nis, nama = s.nama, jk = if (s.jk == "Laki-laki") "L" else "P",
                        sel = st.map { huruf(it) }, h = h, s = st.count { it == "Sakit" },
                        i = st.count { it == "Izin" }, a = st.count { it == "Alpa" }, persen = "$persen%"
                    )
                }
                p.tabelPresensi(hari, isi)
                p.spasi(4f)
                p.baris("Keterangan: H = Hadir, S = Sakit, I = Izin, A = Alpa", p.kecil, 12f)
                p.tandaTangan(d.guru, d.nip)
            }
        }

        p.selesai()
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
