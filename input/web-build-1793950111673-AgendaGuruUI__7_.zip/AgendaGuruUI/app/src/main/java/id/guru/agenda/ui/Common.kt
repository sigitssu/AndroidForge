package id.guru.agenda.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.core.content.ContextCompat
import id.guru.agenda.data.Profil
import id.guru.agenda.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun Context.toast(pesan: String) = Toast.makeText(this, pesan, Toast.LENGTH_SHORT).show()

// ------------------------------------------------------------------ kerangka halaman
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageScaffold(
    title: String,
    pop: () -> Unit,
    fab: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = AppBg,
        topBar = {
            TopAppBar(
                title = { Text(title, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Gray800) },
                navigationIcon = {
                    IconButton(onClick = pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CardBg)
            )
        },
        floatingActionButton = fab,
        content = content
    )
}

@Composable
fun FormScaffold(
    title: String,
    pop: () -> Unit,
    onSimpan: () -> Unit,
    menyimpan: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    PageScaffold(title, pop) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            content()
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onSimpan,
                enabled = !menyimpan,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                if (menyimpan) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = OnPrimary)
                else Text("Simpan")
            }
        }
    }
}

@Composable
fun AddFab(onClick: () -> Unit) {
    FloatingActionButton(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        containerColor = MdPrimary,
        contentColor = OnPrimary
    ) { Icon(Icons.Filled.Add, contentDescription = "Tambah") }
}

@Composable
fun PesanGalat(pesan: String, modifier: Modifier = Modifier) {
    Text(pesan, modifier.padding(start = 16.dp, top = 4.dp), fontSize = 12.sp, color = MdError)
}

// ------------------------------------------------------------------ isian teks
@Composable
fun AppTextField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    error: String? = null,
    number: Boolean = false,
    multiline: Boolean = false,
    maxLength: Int = 200,
    enabled: Boolean = true
) {
    Column(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = { if (it.length <= maxLength) onChange(it) },
            label = { Text(label) },
            singleLine = !multiline,
            minLines = if (multiline) 3 else 1,
            isError = error != null,
            enabled = enabled,
            shape = RoundedCornerShape(12.dp),
            keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text),
            modifier = Modifier.fillMaxWidth()
        )
        if (error != null) PesanGalat(error)
    }
}

// ------------------------------------------------------------------ dropdown
@Composable
private fun DropdownShell(
    label: String,
    tampil: String,
    modifier: Modifier,
    enabled: Boolean,
    error: String?,
    isi: @Composable ColumnScope.(tutup: () -> Unit) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    var ukuran by remember { mutableStateOf(IntSize.Zero) }
    Column(modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().onSizeChanged { ukuran = it }) {
            OutlinedTextField(
                value = tampil,
                onValueChange = {},
                readOnly = true,
                enabled = enabled,
                singleLine = true,
                isError = error != null,
                label = { Text(label) },
                shape = RoundedCornerShape(12.dp),
                trailingIcon = {
                    Icon(Icons.Outlined.ArrowDropDown, contentDescription = null, modifier = Modifier.rotate(if (open) 180f else 0f))
                },
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = if (open) MdPrimary else MaterialTheme.colorScheme.outline,
                    unfocusedLabelColor = if (open) MdPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    disabledTextColor = Gray500,
                    disabledBorderColor = Gray200,
                    disabledLabelColor = Gray500,
                    disabledTrailingIconColor = Gray500
                ),
                modifier = Modifier.fillMaxWidth()
            )
            if (enabled) Box(Modifier.matchParentSize().clickable { open = true })
            if (open && enabled) {
                Popup(
                    alignment = Alignment.TopStart,
                    offset = IntOffset(0, ukuran.height + 4),
                    onDismissRequest = { open = false },
                    properties = PopupProperties(focusable = true)
                ) {
                    Surface(
                        modifier = Modifier.width(with(density) { ukuran.width.toDp() }).heightIn(max = 260.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = CardBg,
                        shadowElevation = 6.dp,
                        border = BorderStroke(1.dp, Gray200)
                    ) {
                        Column(Modifier.verticalScroll(rememberScrollState())) { this.isi { open = false } }
                    }
                }
            }
        }
        if (error != null) PesanGalat(error)
    }
}

/** Dropdown pilihan tunggal. Daftar pilihan selalu selebar kolom. */
@Composable
fun <T> PilihField(
    label: String,
    items: List<T>,
    terpilih: T?,
    nama: (T) -> String,
    onPilih: (T) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    error: String? = null,
    kosong: String = "Tidak ada pilihan"
) {
    val dipilih = terpilih?.let { nama(it) }
    DropdownShell(label, dipilih.orEmpty(), modifier, enabled, error) { tutup ->
        if (items.isEmpty()) {
            Text(kosong, Modifier.padding(16.dp), fontSize = 15.sp, color = Gray500)
        }
        items.forEach { item ->
            val teks = nama(item)
            Box(
                Modifier.fillMaxWidth()
                    .background(if (teks == dipilih) MdSurfaceVariant.copy(alpha = 0.5f) else Color.Transparent)
                    .clickable { onPilih(item); tutup() }
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) { Text(teks, fontSize = 16.sp, color = Gray800) }
        }
    }
}

/** Dropdown pilihan ganda (daftar tetap terbuka saat memilih). */
@Composable
fun <T> MultiPilihField(
    label: String,
    items: List<T>,
    id: (T) -> Long,
    nama: (T) -> String,
    terpilih: Set<Long>,
    onUbah: (Set<Long>) -> Unit,
    modifier: Modifier = Modifier,
    error: String? = null,
    kosong: String = "Tidak ada pilihan"
) {
    val tampil = items.filter { id(it) in terpilih }.joinToString(", ") { nama(it) }
    DropdownShell(label, tampil, modifier, true, error) { _ ->
        if (items.isEmpty()) {
            Text(kosong, Modifier.padding(16.dp), fontSize = 15.sp, color = Gray500)
        }
        items.forEach { item ->
            val ada = id(item) in terpilih
            Row(
                Modifier.fillMaxWidth()
                    .clickable { onUbah(if (ada) terpilih - id(item) else terpilih + id(item)) }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = ada, onCheckedChange = null)
                Spacer(Modifier.width(12.dp))
                Text(nama(item), fontSize = 16.sp, color = Gray800)
            }
        }
    }
}

// ------------------------------------------------------------------ segmented control
@Composable
fun SegmentedControl(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    selectedColors: Map<String, Color> = emptyMap()
) {
    Row(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(50))
            .background(MdSurfaceVariant.copy(alpha = 0.6f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { opt ->
            val dipilih = opt == selected
            val bg by animateColorAsState(
                targetValue = if (dipilih) (selectedColors[opt] ?: MdPrimary) else Color.Transparent,
                label = "segmen"
            )
            Box(
                Modifier.weight(1f)
                    .clip(RoundedCornerShape(50))
                    .background(bg)
                    .clickable { onSelect(opt) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    opt, fontSize = 13.sp,
                    fontWeight = if (dipilih) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (dipilih) OnPrimary else Gray600
                )
            }
        }
    }
}

@Composable
fun SegmentedField(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column {
        Text(label, fontSize = 12.sp, color = Gray500)
        Spacer(Modifier.height(6.dp))
        SegmentedControl(options, selected, onSelect)
    }
}

// ------------------------------------------------------------------ tanggal & waktu
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(
    label: String,
    epochDay: Long?,
    onChange: (Long) -> Unit,
    error: String? = null,
    pola: String = "d MMMM yyyy",
    modifier: Modifier = Modifier
) {
    var tampil by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = epochDay?.let { Fmt.tanggal(it, pola) } ?: "",
                onValueChange = {},
                readOnly = true,
                singleLine = true,
                isError = error != null,
                label = { Text(label) },
                shape = RoundedCornerShape(12.dp),
                trailingIcon = { Icon(Icons.Outlined.CalendarMonth, contentDescription = null) },
                modifier = Modifier.fillMaxWidth()
            )
            Box(Modifier.matchParentSize().clickable { tampil = true })
        }
        if (error != null) PesanGalat(error)
    }
    if (tampil) {
        val state = rememberDatePickerState(initialSelectedDateMillis = epochDay?.let { it * 86_400_000L })
        DatePickerDialog(
            onDismissRequest = { tampil = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(Math.floorDiv(it, 86_400_000L)) }
                    tampil = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { tampil = false }) { Text("Batal") } }
        ) { DatePicker(state = state) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeField(
    label: String,
    menit: Int?,
    onChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    error: String? = null
) {
    var tampil by remember { mutableStateOf(false) }
    Column(modifier) {
        Box(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = menit?.let { Fmt.jam(it) } ?: "",
                onValueChange = {},
                readOnly = true,
                singleLine = true,
                isError = error != null,
                label = { Text(label) },
                shape = RoundedCornerShape(12.dp),
                trailingIcon = { Icon(Icons.Outlined.Schedule, contentDescription = null) },
                modifier = Modifier.fillMaxWidth()
            )
            Box(Modifier.matchParentSize().clickable { tampil = true })
        }
        if (error != null) PesanGalat(error)
    }
    if (tampil) {
        val state = rememberTimePickerState(
            initialHour = (menit ?: 420) / 60,
            initialMinute = (menit ?: 420) % 60,
            is24Hour = true
        )
        Dialog(onDismissRequest = { tampil = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MdSurface,
                tonalElevation = 6.dp,
                modifier = Modifier.width(IntrinsicSize.Min)
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text("Pilih waktu", fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(bottom = 20.dp))
                    TimePicker(state = state)
                    Row(Modifier.fillMaxWidth()) {
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { tampil = false }) { Text("Batal") }
                        TextButton(onClick = {
                            onChange(state.hour * 60 + state.minute)
                            tampil = false
                        }) { Text("OK") }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ menu bawah, dialog, kartu pengaturan
class SheetAction(val icon: ImageVector, val label: String, val onClick: () -> Unit)

/** Menu aksi yang naik dari bawah (seperti YouTube). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActionSheet(onDismiss: () -> Unit, actions: List<SheetAction>) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MdSurface) {
        actions.forEach { a ->
            Row(
                Modifier.fillMaxWidth().clickable(onClick = a.onClick).padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(a.icon, contentDescription = null, tint = Gray600)
                Spacer(Modifier.width(24.dp))
                Text(a.label, fontSize = 16.sp, color = Gray800)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun KonfirmasiDialog(
    judul: String,
    pesan: String,
    onOk: () -> Unit,
    onBatal: () -> Unit,
    labelOk: String = "Hapus",
    berbahaya: Boolean = true
) {
    AlertDialog(
        onDismissRequest = onBatal,
        title = { Text(judul) },
        text = { Text(pesan) },
        confirmButton = {
            TextButton(onClick = onOk) { Text(labelOk, color = if (berbahaya) MdError else MdPrimary) }
        },
        dismissButton = { TextButton(onClick = onBatal) { Text("Batal") } }
    )
}

@Composable
fun InfoDialog(
    judul: String,
    pesan: String,
    onTutup: () -> Unit,
    aksi: String? = null,
    onAksi: (() -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onTutup,
        title = { Text(judul) },
        text = { Text(pesan) },
        confirmButton = {
            if (aksi != null && onAksi != null) TextButton(onClick = onAksi) { Text(aksi) }
            else TextButton(onClick = onTutup) { Text("OK") }
        },
        dismissButton = if (aksi != null && onAksi != null) ({ TextButton(onClick = onTutup) { Text("Tutup") } }) else null
    )
}

class SettingItem(val icon: ImageVector, val label: String, val onClick: () -> Unit)

@Composable
fun SettingsCard(items: List<SettingItem>) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column {
            items.forEachIndexed { index, item ->
                Row(
                    Modifier.fillMaxWidth().clickable(onClick = item.onClick).padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(item.icon, contentDescription = null, tint = Gray600)
                    Spacer(Modifier.width(16.dp))
                    Text(item.label, Modifier.weight(1f), fontWeight = FontWeight.Medium, color = Gray800)
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Gray500)
                }
                if (index < items.lastIndex) HorizontalDivider(color = Gray100)
            }
        }
    }
}

@Composable
fun KeadaanKosong(
    icon: ImageVector,
    judul: String,
    deskripsi: String,
    modifier: Modifier = Modifier,
    labelAksi: String? = null,
    onAksi: (() -> Unit)? = null
) {
    Column(
        modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(88.dp).clip(CircleShape).background(MdPrimaryContainer),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = MdPrimary, modifier = Modifier.size(44.dp)) }
        Spacer(Modifier.height(16.dp))
        Text(judul, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Gray800, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(deskripsi, fontSize = 14.sp, color = Gray600, textAlign = TextAlign.Center)
        if (labelAksi != null && onAksi != null) {
            Spacer(Modifier.height(20.dp))
            Button(onClick = onAksi) { Text(labelAksi) }
        }
    }
}

// ------------------------------------------------------------------ avatar & izin
/** Foto profil bila ada, jika tidak tampil inisial nama. */
@Composable
fun Avatar(
    profil: Profil,
    ukuran: Dp,
    modifier: Modifier = Modifier,
    ukuranTeks: TextUnit = 14.sp,
    bingkai: Dp = 2.dp
) {
    val bmp by produceState<ImageBitmap?>(null, profil.fotoPath) {
        val path = profil.fotoPath
        value = if (path == null) null else withContext(Dispatchers.IO) { BitmapFactory.decodeFile(path)?.asImageBitmap() }
    }
    Box(
        modifier.size(ukuran).border(bingkai, MdPrimary, CircleShape).clip(CircleShape).background(MdPrimaryContainer),
        contentAlignment = Alignment.Center
    ) {
        val gambar = bmp
        if (gambar != null) {
            Image(bitmap = gambar, contentDescription = "Foto profil", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(Fmt.inisial(profil.nama), fontWeight = FontWeight.Bold, fontSize = ukuranTeks, color = MdOnPrimaryContainer)
        }
    }
}

/** Android 8-9 butuh izin menulis ke Download. Android 10+ tidak perlu. */
@Composable
fun rememberMintaIzinSimpan(): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var tertunda by remember { mutableStateOf<(() -> Unit)?>(null) }
    val peluncur = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val aksi = tertunda
        tertunda = null
        if (ok) aksi?.invoke() else ctx.toast("Izin penyimpanan diperlukan untuk menyimpan file")
    }
    return { aksi ->
        val punyaIzin = Build.VERSION.SDK_INT >= 29 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (punyaIzin) {
            aksi()
        } else {
            tertunda = aksi
            peluncur.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }
}
