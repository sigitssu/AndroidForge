package id.guru.agenda.util

import id.guru.agenda.data.Nilai
import id.guru.agenda.data.NilaiSiswa
import id.guru.agenda.data.Siswa
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** gaya: 0 biasa, 1 header, 2 bertepi (teks), 3 bertepi (angka 0.00), 4 judul */
class SelXlsx(val teks: String? = null, val angka: Double? = null, val gaya: Int = 0)

object XlsxWriter {
    private fun esc(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch.code < 32 && ch != '\n' && ch != '\t' -> Unit
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun kol(i: Int): String {
        var n = i
        val sb = StringBuilder()
        do {
            sb.insert(0, 'A' + n % 26)
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    fun buat(namaSheet: String, lebarKolom: List<Double>, baris: List<List<SelXlsx>>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            fun tulis(nama: String, isi: String) {
                z.putNextEntry(ZipEntry(nama))
                z.write(isi.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            tulis(
                "[Content_Types].xml",
                head + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                    "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                    "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                    "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                    "</Types>"
            )
            tulis(
                "_rels/.rels",
                head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                    "</Relationships>"
            )
            tulis(
                "xl/workbook.xml",
                head + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                    "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                    "<sheets><sheet name=\"" + esc(namaSheet) + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
            )
            tulis(
                "xl/_rels/workbook.xml.rels",
                head + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                    "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                    "</Relationships>"
            )
            tulis(
                "xl/styles.xml",
                head + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                    "<fonts count=\"3\">" +
                    "<font><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
                    "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
                    "<font><b/><sz val=\"14\"/><name val=\"Calibri\"/></font></fonts>" +
                    "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>" +
                    "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFD9E1F2\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
                    "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border>" +
                    "<border><left style=\"thin\"><color auto=\"1\"/></left><right style=\"thin\"><color auto=\"1\"/></right>" +
                    "<top style=\"thin\"><color auto=\"1\"/></top><bottom style=\"thin\"><color auto=\"1\"/></bottom><diagonal/></border></borders>" +
                    "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                    "<cellXfs count=\"5\">" +
                    "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                    "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" +
                    "<alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>" +
                    "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +
                    "<xf numFmtId=\"2\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\"/>" +
                    "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
                    "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"
            )
            val sb = StringBuilder()
            sb.append(head)
            sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
            sb.append("<cols>")
            lebarKolom.forEachIndexed { i, w ->
                sb.append("<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"$w\" customWidth=\"1\"/>")
            }
            sb.append("</cols><sheetData>")
            baris.forEachIndexed { r, sel ->
                sb.append("<row r=\"${r + 1}\">")
                sel.forEachIndexed { c, s ->
                    val ref = kol(c) + (r + 1)
                    if (s.teks != null) {
                        sb.append("<c r=\"$ref\" t=\"inlineStr\" s=\"${s.gaya}\"><is><t xml:space=\"preserve\">${esc(s.teks)}</t></is></c>")
                    } else if (s.angka != null) {
                        sb.append("<c r=\"$ref\" s=\"${s.gaya}\"><v>${s.angka}</v></c>")
                    } else {
                        sb.append("<c r=\"$ref\" s=\"${s.gaya}\"/>")
                    }
                }
                sb.append("</row>")
            }
            sb.append("</sheetData></worksheet>")
            tulis("xl/worksheets/sheet1.xml", sb.toString())
        }
        return out.toByteArray()
    }
}

object LaporanExcel {
    /** Rekap penilaian siswa untuk satu kelas dan satu mata pelajaran. */
    fun nilai(
        sekolah: String, guru: String, nip: String, tahun: String, kelas: String, mapel: String,
        daftarNilai: List<Nilai>, siswa: List<Siswa>, skor: List<NilaiSiswa>
    ): ByteArray {
        val peta = HashMap<String, Double>()
        for (s in skor) peta[s.nilaiId.toString() + ":" + s.siswaId] = s.skor

        val baris = mutableListOf<List<SelXlsx>>()
        baris.add(listOf(SelXlsx(teks = "REKAP PENILAIAN SISWA", gaya = 4)))
        baris.add(listOf(SelXlsx(teks = "Sekolah: $sekolah")))
        baris.add(listOf(SelXlsx(teks = "Guru: $guru (NIP $nip)")))
        baris.add(listOf(SelXlsx(teks = "Tahun Ajaran: $tahun")))
        baris.add(listOf(SelXlsx(teks = "Kelas: $kelas")))
        baris.add(listOf(SelXlsx(teks = "Mata Pelajaran: $mapel")))
        baris.add(emptyList())

        val header = mutableListOf(SelXlsx(teks = "No", gaya = 1), SelXlsx(teks = "NIS", gaya = 1), SelXlsx(teks = "Nama Siswa", gaya = 1), SelXlsx(teks = "JK", gaya = 1))
        daftarNilai.forEach { header.add(SelXlsx(teks = it.nama, gaya = 1)) }
        header.add(SelXlsx(teks = "Rata-rata", gaya = 1))
        baris.add(header)

        siswa.forEachIndexed { i, s ->
            val row = mutableListOf(
                SelXlsx(angka = (i + 1).toDouble(), gaya = 2), SelXlsx(teks = s.nis, gaya = 2),
                SelXlsx(teks = s.nama, gaya = 2), SelXlsx(teks = if (s.jk == "Laki-laki") "L" else "P", gaya = 2)
            )
            val ada = mutableListOf<Double>()
            daftarNilai.forEach { n ->
                val v = peta[n.id.toString() + ":" + s.id]
                if (v != null) {
                    ada.add(v)
                    row.add(SelXlsx(angka = v, gaya = 3))
                } else {
                    row.add(SelXlsx(gaya = 2))
                }
            }
            row.add(if (ada.isEmpty()) SelXlsx(gaya = 2) else SelXlsx(angka = Math.round(ada.average() * 100) / 100.0, gaya = 3))
            baris.add(row)
        }

        fun ringkas(judul: String, f: (List<Double>) -> Double): List<SelXlsx> {
            val row = mutableListOf(SelXlsx(gaya = 2), SelXlsx(gaya = 2), SelXlsx(teks = judul, gaya = 2), SelXlsx(gaya = 2))
            val semua = mutableListOf<Double>()
            daftarNilai.forEach { n ->
                val kolom = siswa.mapNotNull { peta[n.id.toString() + ":" + it.id] }
                semua.addAll(kolom)
                row.add(if (kolom.isEmpty()) SelXlsx(gaya = 2) else SelXlsx(angka = Math.round(f(kolom) * 100) / 100.0, gaya = 3))
            }
            row.add(if (semua.isEmpty()) SelXlsx(gaya = 2) else SelXlsx(angka = Math.round(f(semua) * 100) / 100.0, gaya = 3))
            return row
        }
        if (siswa.isNotEmpty()) {
            baris.add(ringkas("Rata-rata kelas") { it.average() })
            baris.add(ringkas("Tertinggi") { it.max() })
            baris.add(ringkas("Terendah") { it.min() })
        }

        val lebar = mutableListOf(6.0, 14.0, 32.0, 6.0)
        daftarNilai.forEach { lebar.add(12.0) }
        lebar.add(12.0)
        return XlsxWriter.buat("Rekap Nilai", lebar, baris)
    }
}
