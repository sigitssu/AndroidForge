package id.guru.agenda

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import id.guru.agenda.ui.AgendaGuruApp
import id.guru.agenda.ui.AgendaGuruTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel()
            AgendaGuruTheme(vm.tema) { AgendaGuruApp(vm) }
        }
    }
}
