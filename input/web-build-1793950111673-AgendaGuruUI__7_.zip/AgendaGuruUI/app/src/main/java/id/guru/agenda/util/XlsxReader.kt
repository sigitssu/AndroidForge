package id.guru.agenda.util

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.math.BigDecimal
import java.util.zip.ZipInputStream

/** Pembaca .xlsx ringan tanpa library tambahan. Membaca sheet pertama menjadi baris-baris teks. */
object XlsxReader {
    fun baca(input: InputStream): List<List<String>> {
        var shared = emptyList<String>()
        val sheets = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val n = e.name
                if (n == "xl/sharedStrings.xml") shared = bacaShared(zip.readBytes())
                else if (n.startsWith("xl/worksheets/") && n.endsWith(".xml")) sheets[n] = zip.readBytes()
            }
        }
        val dipilih = sheets["xl/worksheets/sheet1.xml"] ?: sheets.toSortedMap().values.firstOrNull() ?: return emptyList()
        return bacaSheet(dipilih, shared)
    }

    private fun parser(b: ByteArray): XmlPullParser =
        Xml.newPullParser().apply { setInput(ByteArrayInputStream(b), "UTF-8") }

    private fun bacaShared(b: ByteArray): List<String> {
        val p = parser(b)
        val hasil = mutableListOf<String>()
        var sb = StringBuilder()
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name == "si") sb = StringBuilder()
            else if (p.eventType == XmlPullParser.START_TAG && p.name == "t") sb.append(p.nextText())
            else if (p.eventType == XmlPullParser.END_TAG && p.name == "si") hasil.add(sb.toString())
        }
        return hasil
    }

    private fun bacaSheet(b: ByteArray, shared: List<String>): List<List<String>> {
        val p = parser(b)
        val baris = mutableListOf<List<String>>()
        var row = mutableMapOf<Int, String>()
        var kol = 0
        var tipe: String? = null
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG) {
                when (p.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> {
                        tipe = p.getAttributeValue(null, "t")
                        val ref = p.getAttributeValue(null, "r") ?: "A"
                        kol = ref.takeWhile { it.isLetter() }.fold(0) { a, ch -> a * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                    }
                    "v" -> {
                        val v = p.nextText()
                        row[kol] = if (tipe == "s") shared.getOrElse(v.toIntOrNull() ?: -1) { "" } else v
                    }
                    "t" -> if (tipe == "inlineStr") row[kol] = p.nextText()
                }
            } else if (p.eventType == XmlPullParser.END_TAG && p.name == "row") {
                val lebar = (row.keys.maxOrNull() ?: -1) + 1
                baris.add(List(lebar) { row[it].orEmpty().trim() })
            }
        }
        return baris
    }

    /** NIS yang tersimpan sebagai angka di Excel (mis. 2026001.0 atau 1.2E9) dijadikan teks biasa. */
    fun normalNis(raw: String?): String {
        val t = raw.orEmpty().trim()
        if (t.isEmpty()) return ""
        val angka = Regex("^[0-9]+([.,][0-9]+)?([eE][+-]?[0-9]+)?$").matches(t)
        if (angka && (t.contains('.') || t.contains(',') || t.contains('E') || t.contains('e'))) {
            return try {
                BigDecimal(t.replace(',', '.')).stripTrailingZeros().toPlainString()
            } catch (e: Exception) {
                t
            }
        }
        return t
    }

    fun normalJk(raw: String?): String? = when (raw.orEmpty().trim().lowercase()) {
        "l", "lk", "laki-laki", "laki laki", "pria", "male", "m" -> "Laki-laki"
        "p", "pr", "perempuan", "wanita", "female", "f" -> "Perempuan"
        else -> null
    }
}
