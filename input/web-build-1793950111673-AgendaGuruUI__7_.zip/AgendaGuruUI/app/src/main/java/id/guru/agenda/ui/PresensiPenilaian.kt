package id.guru.agenda.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import id.guru.agenda.MainViewModel
import id.guru.agenda.data.*
import id.guru.agenda.util.Fmt

// ------------------------------------------------------------------ Presensi siswa
@Composable
fun PresensiScreen(vm: MainViewModel, a: AgendaView, pop: () -> Unit) {
    val ctx = LocalContext.current
    val siswa by remember(a.kelasId) { vm.siswaFlow(a.kelasId) }.collectAsState(initial = emptyList<Siswa>())
    val status = remember { mutableStateMapOf<Long, String>() }
    var menyimpan by remember { mutableStateOf(false) }
    val opsi = listOf("Hadir", "Sakit", "Izin", "Alpa")
    val warna = mapOf("Hadir" to MdPrimary, "Sakit" to MdError, "Izin" to MdTertiary, "Alpa" to AlpaRed)

    LaunchedEffect(a.id) {
        val tersimpan = vm.presensiAgenda(a.id)
        status.clear()
        status.putAll(tersimpan)
    }

    PageScaffold("Presensi Siswa", pop) { padding ->
        if (siswa.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                KeadaanKosong(
                    icon = Icons.Outlined.Group,
                    judul = "Belum ada siswa",
                    deskripsi = "Kelas ${a.kelasNama} belum memiliki siswa. Impor atau tambahkan siswa dari menu Daftar Siswa."
                )
            }
        } else {
            Column(Modifier.padding(padding).fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(
                                    a.kelasNama + " • " + Fmt.rentang(a.mulai, a.selesai),
                                    fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer
                                )
                                Text(a.mapelNama + " • " + Fmt.tanggal(a.tanggal, "d MMM yyyy"), fontSize = 13.sp, color = Gray600)
                                Text(a.topik, fontSize = 13.sp, color = Gray600)
                                Spacer(Modifier.height(12.dp))
                                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    opsi.forEach { o ->
                                        val jumlah = siswa.count { s -> (status[s.id] ?: "Hadir") == o }
                                        Stat(jumlah, o, warna.getValue(o))
                                    }
                                }
                            }
                        }
                    }
                    items(siswa, key = { it.id }) { s ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBg),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(s.nama, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray800)
                                Text("NIS ${s.nis}", fontSize = 12.sp, color = Gray500)
                                Spacer(Modifier.height(12.dp))
                                SegmentedControl(
                                    options = opsi,
                                    selected = status[s.id] ?: "Hadir",
                                    onSelect = { status[s.id] = it },
                                    selectedColors = warna
                                )
                            }
                        }
                    }
                }
                Surface(color = CardBg, shadowElevation = 8.dp) {
                    Button(
                        onClick = {
                            menyimpan = true
                            val data = siswa.associate { it.id to (status[it.id] ?: "Hadir") }
                            vm.simpanPresensi(a.id, data) { err ->
                                menyimpan = false
                                if (err == null) {
                                    ctx.toast("Presensi disimpan")
                                    pop()
                                } else {
                                    ctx.toast(err)
                                }
                            }
                        },
                        enabled = !menyimpan,
                        modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
                    ) {
                        if (menyimpan) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = OnPrimary)
                        else Text("Simpan")
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Penilaian siswa
@Composable
fun PenilaianScreen(vm: MainViewModel, n: NilaiView, pop: () -> Unit) {
    val ctx = LocalContext.current
    val siswa by remember(n.kelasId) { vm.siswaFlow(n.kelasId) }.collectAsState(initial = emptyList<Siswa>())
    val teks = remember { mutableStateMapOf<Long, String>() }
    val galat = remember { mutableStateMapOf<Long, String>() }
    var menyimpan by remember { mutableStateOf(false) }

    LaunchedEffect(n.id) {
        val tersimpan = vm.nilaiSiswaMap(n.id)
        teks.clear()
        tersimpan.forEach { (sid, skor) -> teks[sid] = Fmt.desimal(skor) }
    }

    fun parse(t: String?): Double? = t?.trim()?.replace(',', '.')?.takeIf { it.isNotEmpty() }?.toDoubleOrNull()

    val angka = siswa.mapNotNull { s -> parse(teks[s.id])?.takeIf { it in 0.0..100.0 } }
    val terbesar = angka.maxOrNull()?.let { Fmt.desimal(it) } ?: "-"
    val terkecil = angka.minOrNull()?.let { Fmt.desimal(it) } ?: "-"
    val rataRata = if (angka.isEmpty()) "-" else Fmt.desimal(angka.average())

    PageScaffold("Penilaian", pop) { padding ->
        if (siswa.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                KeadaanKosong(
                    icon = Icons.Outlined.Group,
                    judul = "Belum ada siswa",
                    deskripsi = "Kelas ${n.kelasNama} belum memiliki siswa. Impor atau tambahkan siswa dari menu Daftar Siswa."
                )
            }
        } else {
            Column(Modifier.padding(padding).fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MdPrimaryContainer)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(n.nama + " • " + n.kelasNama, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                                Text(n.mapelNama, fontSize = 13.sp, color = Gray600)
                                Spacer(Modifier.height(12.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    StatText(terbesar, "Terbesar", MdPrimary)
                                    StatText(terkecil, "Terkecil", MdError)
                                    StatText(rataRata, "Rata-rata", MdTertiary)
                                }
                            }
                        }
                    }
                    items(siswa, key = { it.id }) { s ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBg),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top) {
                                Column(Modifier.weight(1f).padding(top = 8.dp)) {
                                    Text(s.nama, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray800)
                                    Text("NIS ${s.nis}", fontSize = 12.sp, color = Gray500)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    OutlinedTextField(
                                        value = teks[s.id] ?: "",
                                        onValueChange = { v ->
                                            if (v.length <= 6 && v.all { c -> c.isDigit() || c == '.' || c == ',' }) {
                                                teks[s.id] = v
                                                galat.remove(s.id)
                                            }
                                        },
                                        placeholder = { Text("Nilai", Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
                                        singleLine = true,
                                        isError = galat[s.id] != null,
                                        shape = RoundedCornerShape(12.dp),
                                        textStyle = TextStyle(textAlign = TextAlign.Center, fontSize = 16.sp, color = Gray800),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier.width(96.dp)
                                    )
                                    galat[s.id]?.let { Text(it, fontSize = 11.sp, color = MdError) }
                                }
                            }
                        }
                    }
                }
                Surface(color = CardBg, shadowElevation = 8.dp) {
                    Button(
                        onClick = {
                            galat.clear()
                            val hasil = HashMap<Long, Double?>()
                            var ada = false
                            for (s in siswa) {
                                val mentah = teks[s.id]?.trim().orEmpty()
                                if (mentah.isEmpty()) {
                                    hasil[s.id] = null
                                } else {
                                    val v = parse(mentah)
                                    if (v == null) {
                                        galat[s.id] = "Tidak valid"
                                        ada = true
                                    } else if (v < 0.0 || v > 100.0) {
                                        galat[s.id] = "0 - 100"
                                        ada = true
                                    } else {
                                        hasil[s.id] = v
                                    }
                                }
                            }
                            if (ada) {
                                ctx.toast("Periksa kembali nilai yang dimasukkan (0 - 100)")
                            } else {
                                menyimpan = true
                                vm.simpanNilaiSiswa(n.id, hasil) { err ->
                                    menyimpan = false
                                    if (err == null) {
                                        ctx.toast("Nilai disimpan")
                                        pop()
                                    } else {
                                        ctx.toast(err)
                                    }
                                }
                            }
                        },
                        enabled = !menyimpan,
                        modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)
                    ) {
                        if (menyimpan) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = OnPrimary)
                        else Text("Simpan")
                    }
                }
            }
        }
    }
}
