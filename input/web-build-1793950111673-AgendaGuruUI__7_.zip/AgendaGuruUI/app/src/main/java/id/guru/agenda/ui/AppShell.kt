package id.guru.agenda.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment as AssignmentFilled
import androidx.compose.material.icons.automirrored.outlined.Assignment as AssignmentOutlined
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.CalendarToday as CalendarFilled
import androidx.compose.material.icons.filled.Home as HomeFilled
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Class
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Grade
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import id.guru.agenda.MainViewModel
import id.guru.agenda.data.*
import kotlinx.coroutines.launch

sealed interface Route {
    data object Profil : Route
    data object Pengaturan : Route
    data object Tema : Route
    data object Tentang : Route
    data class Master(val title: String) : Route
    data class TahunForm(val item: TahunAjaran?) : Route
    data class KelasForm(val item: KelasView?) : Route
    data class SiswaForm(val item: Siswa?, val kelasId: Long) : Route
    data class MapelForm(val item: MapelView?) : Route
    data class AgendaForm(val item: AgendaView?) : Route
    data class Presensi(val item: AgendaView) : Route
    data class NilaiForm(val item: NilaiView?) : Route
    data class Penilaian(val item: NilaiView) : Route
}

private class NavItem(val label: String, val on: ImageVector, val off: ImageVector)

private val navItems = listOf(
    NavItem("Beranda", Icons.Filled.HomeFilled, Icons.Outlined.Home),
    NavItem("Agenda", Icons.Filled.CalendarFilled, Icons.Outlined.CalendarToday),
    NavItem("Laporan", Icons.AutoMirrored.Filled.AssignmentFilled, Icons.AutoMirrored.Outlined.AssignmentOutlined),
    NavItem("Pengaturan", Icons.Outlined.Settings, Icons.Outlined.Settings)
)

private val drawerItems: List<Pair<String, ImageVector>> = listOf(
    "Tahun Ajaran" to Icons.Outlined.DateRange,
    "Daftar Kelas" to Icons.Outlined.Class,
    "Daftar Siswa" to Icons.Outlined.Group,
    "Daftar Mata Pelajaran" to Icons.AutoMirrored.Outlined.MenuBook,
    "Daftar Nilai" to Icons.Outlined.Grade,
    "Backup & Restore" to Icons.Outlined.CloudSync
)

private data class NavEntry(val route: Route, val depth: Int)

@Composable
fun AgendaGuruApp(vm: MainViewModel) {
    val siap by vm.siap.collectAsState()
    if (!siap) {
        Box(Modifier.fillMaxSize().background(AppBg))
    } else {
        Aplikasi(vm)
    }
}

@Composable
private fun Aplikasi(vm: MainViewModel) {
    val ctx = LocalContext.current
    val profil by vm.profil.collectAsState()
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    val mapel by vm.mapel.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Route>() }
    val push: (Route) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    val tambahAgenda: () -> Unit = {
        when {
            tahun == null -> ctx.toast("Buat tahun ajaran terlebih dahulu")
            kelas.isEmpty() -> ctx.toast("Tambahkan kelas terlebih dahulu")
            mapel.none { it.kelas.isNotEmpty() } -> ctx.toast("Tambahkan mata pelajaran terlebih dahulu")
            else -> push(Route.AgendaForm(null))
        }
    }

    Box(Modifier.fillMaxSize()) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier.width(300.dp),
                    drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                    drawerContainerColor = MdSurface
                ) {
                    Column(Modifier.fillMaxWidth().background(MdPrimaryContainer).padding(24.dp)) {
                        Text("Menu Utama", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MdOnPrimaryContainer)
                        Text(profil.sekolah, fontSize = 14.sp, color = MdOnPrimaryContainer.copy(alpha = 0.8f))
                        Spacer(Modifier.height(4.dp))
                        Text(
                            tahun?.let { "TA " + it.label() } ?: "Belum ada tahun ajaran",
                            fontSize = 12.sp, color = MdOnPrimaryContainer.copy(alpha = 0.7f)
                        )
                    }
                    drawerItems.forEachIndexed { index, item ->
                        if (index == drawerItems.lastIndex) {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Gray200)
                        }
                        NavigationDrawerItem(
                            label = { Text(item.first) },
                            icon = { Icon(item.second, contentDescription = null, tint = Gray600) },
                            selected = false,
                            shape = RectangleShape,
                            onClick = {
                                scope.launch { drawerState.close() }
                                push(Route.Master(item.first))
                            }
                        )
                    }
                }
            }
        ) {
            MainScaffold(
                vm = vm,
                profil = profil,
                tab = tab,
                onTab = { tab = it },
                onMenu = { scope.launch { drawerState.open() } },
                push = push,
                tambahAgenda = tambahAgenda
            )
        }

        val atas = stack.lastOrNull()?.let { NavEntry(it, stack.size) }
        AnimatedContent(
            targetState = atas,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                val masuk = (targetState?.depth ?: 0) > (initialState?.depth ?: 0)
                if (masuk) {
                    slideInHorizontally { it } togetherWith slideOutHorizontally { -it / 3 }
                } else {
                    slideInHorizontally { -it / 3 } togetherWith slideOutHorizontally { it }
                }
            },
            label = "nav"
        ) { entry ->
            if (entry != null) RouteScreen(vm, entry.route, push, pop) else Box(Modifier.fillMaxSize())
        }
    }
    BackHandler(enabled = stack.isNotEmpty()) { pop() }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
}

@Composable
private fun RouteScreen(vm: MainViewModel, route: Route, push: (Route) -> Unit, pop: () -> Unit) {
    when (route) {
        Route.Profil -> ProfilScreen(vm, pop)
        Route.Pengaturan -> PengaturanScreen(push, pop)
        Route.Tema -> TemaScreen(vm, pop)
        Route.Tentang -> TentangScreen(pop)
        is Route.Master -> MasterScreen(vm, route.title, push, pop)
        is Route.TahunForm -> TahunForm(vm, route.item, pop)
        is Route.KelasForm -> KelasForm(vm, route.item, pop)
        is Route.SiswaForm -> SiswaForm(vm, route.item, route.kelasId, pop)
        is Route.MapelForm -> MapelForm(vm, route.item, pop)
        is Route.AgendaForm -> AgendaForm(vm, route.item, pop)
        is Route.Presensi -> PresensiScreen(vm, route.item, pop)
        is Route.NilaiForm -> NilaiForm(vm, route.item, pop)
        is Route.Penilaian -> PenilaianScreen(vm, route.item, pop)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(
    vm: MainViewModel,
    profil: Profil,
    tab: Int,
    onTab: (Int) -> Unit,
    onMenu: () -> Unit,
    push: (Route) -> Unit,
    tambahAgenda: () -> Unit
) {
    var menuProfil by remember { mutableStateOf(false) }
    val judul = listOf("Agenda Hari Ini", "Agenda", "Laporan")
    Scaffold(
        containerColor = AppBg,
        topBar = {
            TopAppBar(
                title = { Text(judul[tab], fontSize = 20.sp, fontWeight = FontWeight.Medium) },
                navigationIcon = {
                    IconButton(onClick = onMenu) { Icon(Icons.Filled.Menu, contentDescription = "Menu") }
                },
                actions = {
                    Box(Modifier.padding(end = 16.dp)) {
                        Avatar(profil, 40.dp, Modifier.clip(CircleShape).clickable { menuProfil = true })
                        DropdownMenu(
                            expanded = menuProfil,
                            onDismissRequest = { menuProfil = false },
                            modifier = Modifier.width(160.dp)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Ubah Profil") },
                                leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                                onClick = { menuProfil = false; push(Route.Profil) }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MdPrimaryContainer,
                    titleContentColor = MdOnPrimaryContainer,
                    navigationIconContentColor = MdOnPrimaryContainer,
                    actionIconContentColor = MdOnPrimaryContainer
                )
            )
        },
        floatingActionButton = { if (tab <= 1) AddFab(tambahAgenda) },
        bottomBar = {
            Column {
                HorizontalDivider(color = Gray200)
                NavigationBar(containerColor = MdSurface) {
                    navItems.forEachIndexed { i, item ->
                        val dipilih = i < 3 && tab == i
                        NavigationBarItem(
                            selected = dipilih,
                            onClick = { if (i == 3) push(Route.Pengaturan) else onTab(i) },
                            icon = { Icon(if (dipilih) item.on else item.off, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MdOnSurface,
                                selectedTextColor = MdOnSurface,
                                indicatorColor = MdSecondaryContainer,
                                unselectedIconColor = Gray600,
                                unselectedTextColor = Gray600
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> BerandaTab(vm, push, tambahAgenda)
                1 -> AgendaTab(vm, push, tambahAgenda)
                else -> LaporanTab(vm, push)
            }
        }
    }
}
