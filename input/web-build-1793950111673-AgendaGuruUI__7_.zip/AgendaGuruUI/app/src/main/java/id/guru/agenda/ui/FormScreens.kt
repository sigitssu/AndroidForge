package id.guru.agenda.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.*
import id.guru.agenda.MainViewModel
import id.guru.agenda.data.*
import id.guru.agenda.util.Fmt
import java.time.LocalDate

// ------------------------------------------------------------------ Profil
@Composable
fun ProfilScreen(vm: MainViewModel, pop: () -> Unit) {
    val ctx = LocalContext.current
    val profil by vm.profil.collectAsState()
    var nama by remember { mutableStateOf(profil.nama) }
    var nip by remember { mutableStateOf(profil.nip) }
    var sekolah by remember { mutableStateOf(profil.sekolah) }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.ubahFoto(uri) { err -> if (err != null) ctx.toast("Gagal mengubah foto: $err") }
    }

    val eNama = when {
        nama.isBlank() -> "Nama lengkap wajib diisi"
        nama.trim().length < 3 -> "Nama minimal 3 karakter"
        else -> null
    }
    val eNip = when {
        nip.isBlank() -> "NIP wajib diisi"
        nip.length < 8 -> "NIP minimal 8 digit"
        else -> null
    }
    val eSekolah = if (sekolah.isBlank()) "Nama sekolah wajib diisi" else null

    FormScaffold(
        title = "Ubah Profil",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            if (eNama == null && eNip == null && eSekolah == null) {
                menyimpan = true
                vm.simpanProfil(nama, nip, sekolah) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Profil disimpan")
                        pop()
                    } else {
                        ctx.toast(err)
                    }
                }
            }
        }
    ) {
        Box(Modifier.align(Alignment.CenterHorizontally).size(120.dp)) {
            Avatar(profil, 120.dp, Modifier.fillMaxSize(), 36.sp, 3.dp)
            Box(
                Modifier.align(Alignment.BottomEnd).size(38.dp).clip(CircleShape).background(MdPrimary)
                    .border(2.dp, CardBg, CircleShape).clickable { picker.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Edit, contentDescription = "Ubah foto", tint = OnPrimary, modifier = Modifier.size(18.dp))
            }
        }
        if (profil.fotoPath != null) {
            TextButton(
                onClick = { vm.hapusFoto { err -> if (err != null) ctx.toast(err) } },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) { Text("Hapus foto") }
        } else {
            Text(
                "Belum ada foto. Inisial nama ditampilkan sebagai pengganti.",
                Modifier.align(Alignment.CenterHorizontally), fontSize = 12.sp, color = Gray500
            )
        }
        AppTextField("Nama Lengkap", nama, { nama = it }, error = if (coba) eNama else null, maxLength = 60)
        AppTextField("NIP", nip, { nip = it.filter { c -> c.isDigit() } }, error = if (coba) eNip else null, number = true, maxLength = 20)
        AppTextField("Nama Sekolah", sekolah, { sekolah = it }, error = if (coba) eSekolah else null, maxLength = 80)
    }
}

// ------------------------------------------------------------------ Tahun ajaran
@Composable
fun TahunForm(vm: MainViewModel, item: TahunAjaran?, pop: () -> Unit) {
    val ctx = LocalContext.current
    var awal by remember { mutableStateOf<Long?>(item?.awal) }
    var akhir by remember { mutableStateOf<Long?>(item?.akhir) }
    var semester by remember { mutableStateOf(item?.semester ?: "Ganjil") }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    var galat by remember { mutableStateOf<String?>(null) }

    val a = awal
    val b = akhir
    val eAwal = if (a == null) "Awal tahun ajaran wajib diisi" else null
    val eAkhir = when {
        b == null -> "Akhir tahun ajaran wajib diisi"
        a != null && b <= a -> "Akhir tahun ajaran harus setelah awal tahun ajaran"
        else -> null
    }
    val tampilAkhir = if (coba || (a != null && b != null)) eAkhir else null

    FormScaffold(
        title = if (item == null) "Tambah Tahun Ajaran" else "Ubah Tahun Ajaran",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            galat = null
            if (a != null && b != null && eAkhir == null) {
                menyimpan = true
                vm.simpanTahun(item, a, b, semester) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Tahun ajaran disimpan")
                        pop()
                    } else {
                        galat = err
                    }
                }
            }
        }
    ) {
        DateField("Awal Tahun Ajaran", a, { awal = it }, error = if (coba) eAwal else null)
        DateField("Akhir Tahun Ajaran", b, { akhir = it }, error = tampilAkhir)
        SegmentedField("Semester", listOf("Ganjil", "Genap"), semester) { semester = it }
        if (a != null) {
            Text(
                "Tahun ajaran: " + TahunAjaran(awal = a, akhir = b ?: a, semester = semester).label(),
                fontSize = 13.sp, color = Gray600
            )
        }
        if (item == null) {
            Text("Tahun ajaran baru otomatis menjadi tahun ajaran aktif dan menjadi acuan data lainnya.", fontSize = 12.sp, color = Gray500)
        }
        galat?.let { PesanGalat(it, Modifier.padding(start = 0.dp)) }
    }
}

// ------------------------------------------------------------------ Kelas
@Composable
fun KelasForm(vm: MainViewModel, item: KelasView?, pop: () -> Unit) {
    val ctx = LocalContext.current
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    var galat by remember { mutableStateOf<String?>(null) }
    val eNama = if (nama.isBlank()) "Nama kelas wajib diisi" else null

    FormScaffold(
        title = if (item == null) "Tambah Daftar Kelas" else "Ubah Daftar Kelas",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            galat = null
            if (eNama == null) {
                menyimpan = true
                vm.simpanKelas(item, nama) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Kelas disimpan")
                        pop()
                    } else {
                        galat = err
                    }
                }
            }
        }
    ) {
        AppTextField("Nama Kelas", nama, { nama = it; galat = null }, error = galat ?: (if (coba) eNama else null), maxLength = 30)
    }
}

// ------------------------------------------------------------------ Siswa
@Composable
fun SiswaForm(vm: MainViewModel, item: Siswa?, kelasId: Long, pop: () -> Unit) {
    val ctx = LocalContext.current
    val kelas by vm.kelas.collectAsState()
    var nis by remember { mutableStateOf(item?.nis ?: "") }
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    var jk by remember { mutableStateOf(item?.jk ?: "Laki-laki") }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    var galat by remember { mutableStateOf<String?>(null) }
    val eNis = if (nis.isBlank()) "NIS wajib diisi" else null
    val eNama = if (nama.isBlank()) "Nama siswa wajib diisi" else null

    FormScaffold(
        title = if (item == null) "Tambah Siswa" else "Ubah Siswa",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            galat = null
            if (eNis == null && eNama == null) {
                menyimpan = true
                vm.simpanSiswa(item, kelasId, nis, nama, jk) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Siswa disimpan")
                        pop()
                    } else {
                        galat = err
                    }
                }
            }
        }
    ) {
        AppTextField("Kelas", kelas.firstOrNull { it.id == kelasId }?.nama ?: "", {}, enabled = false)
        AppTextField("NIS", nis, { nis = it.filter { c -> c.isDigit() }; galat = null }, error = galat ?: (if (coba) eNis else null), number = true, maxLength = 20)
        AppTextField("Nama Siswa", nama, { nama = it }, error = if (coba) eNama else null, maxLength = 100)
        SegmentedField("Jenis Kelamin", listOf("Laki-laki", "Perempuan"), jk) { jk = it }
    }
}

// ------------------------------------------------------------------ Mata pelajaran
@Composable
fun MapelForm(vm: MainViewModel, item: MapelView?, pop: () -> Unit) {
    val ctx = LocalContext.current
    val kelas by vm.kelas.collectAsState()
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    var ids by remember { mutableStateOf<Set<Long>>(item?.kelas?.map { it.kelasId }?.toSet() ?: emptySet()) }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    var galat by remember { mutableStateOf<String?>(null) }
    val eNama = if (nama.isBlank()) "Nama mata pelajaran wajib diisi" else null
    val eKelas = if (ids.isEmpty()) "Pilih minimal satu kelas" else null

    FormScaffold(
        title = if (item == null) "Tambah Daftar Mata Pelajaran" else "Ubah Daftar Mata Pelajaran",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            galat = null
            if (eNama == null && eKelas == null) {
                menyimpan = true
                vm.simpanMapel(item, nama, ids) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Mata pelajaran disimpan")
                        pop()
                    } else {
                        galat = err
                    }
                }
            }
        }
    ) {
        AppTextField("Nama Mata Pelajaran", nama, { nama = it; galat = null }, error = if (coba) eNama else null, maxLength = 80)
        MultiPilihField(
            label = "Kelas",
            items = kelas,
            id = { it.id },
            nama = { it.nama },
            terpilih = ids,
            onUbah = { ids = it },
            error = if (coba) eKelas else null,
            kosong = "Belum ada kelas. Tambahkan kelas terlebih dahulu."
        )
        Text("Satu mata pelajaran dapat diajarkan di lebih dari satu kelas.", fontSize = 12.sp, color = Gray500)
        galat?.let { PesanGalat(it, Modifier.padding(start = 0.dp)) }
    }
}

// ------------------------------------------------------------------ Agenda
@Composable
fun AgendaForm(vm: MainViewModel, item: AgendaView?, pop: () -> Unit) {
    val ctx = LocalContext.current
    val tahun by vm.tahunAktif.collectAsState()
    val kelas by vm.kelas.collectAsState()
    val mapel by vm.mapel.collectAsState()
    var tanggal by remember { mutableStateOf<Long?>(item?.tanggal ?: LocalDate.now().toEpochDay()) }
    var mulai by remember { mutableStateOf<Int?>(item?.mulai) }
    var selesai by remember { mutableStateOf<Int?>(item?.selesai) }
    var topik by remember { mutableStateOf(item?.topik ?: "") }
    var kelasId by remember { mutableStateOf<Long?>(item?.kelasId) }
    var mapelId by remember { mutableStateOf<Long?>(item?.mapelId) }
    var catatan by remember { mutableStateOf(item?.catatan ?: "") }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    var galat by remember { mutableStateOf<String?>(null) }

    val tg = tanggal
    val mu = mulai
    val se = selesai
    val th = tahun
    val kelasPilih = kelas.firstOrNull { it.id == kelasId }
    val opsiMapel = mapel.filter { m -> m.kelas.any { it.kelasId == kelasId } }
    val mapelPilih = mapel.firstOrNull { it.id == mapelId }

    val eTanggal = when {
        tg == null -> "Tanggal wajib diisi"
        th != null && (tg < th.awal || tg > th.akhir) ->
            "Tanggal harus dalam rentang tahun ajaran (${Fmt.tanggal(th.awal)} - ${Fmt.tanggal(th.akhir)})"
        else -> null
    }
    val eMulai = if (mu == null) "Wajib diisi" else null
    val eSelesai = when {
        se == null -> "Wajib diisi"
        mu != null && se <= mu -> "Harus lebih besar dari jam mulai"
        else -> null
    }
    val tampilSelesai = if (coba || (mu != null && se != null)) eSelesai else null
    val eTopik = if (topik.isBlank()) "Topik pembelajaran wajib diisi" else null
    val eKelas = if (kelasId == null) "Kelas wajib dipilih" else null
    val eMapel = if (mapelId == null) "Mata pelajaran wajib dipilih" else null

    FormScaffold(
        title = if (item == null) "Tambah Agenda" else "Ubah Agenda",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            galat = null
            val ok = eTanggal == null && eMulai == null && eSelesai == null && eTopik == null && eKelas == null && eMapel == null
            if (ok && tg != null && mu != null && se != null && kelasId != null && mapelId != null) {
                menyimpan = true
                vm.simpanAgenda(item, kelasId!!, mapelId!!, tg, mu, se, topik, catatan) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Agenda disimpan")
                        pop()
                    } else {
                        galat = err
                    }
                }
            }
        }
    ) {
        DateField("Tanggal", tg, { tanggal = it }, error = if (coba) eTanggal else null, pola = "EEEE, d MMMM yyyy")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            TimeField("Mulai", mu, { mulai = it }, Modifier.weight(1f), error = if (coba) eMulai else null)
            TimeField("Selesai", se, { selesai = it }, Modifier.weight(1f), error = tampilSelesai)
        }
        AppTextField("Topik Pembelajaran", topik, { topik = it }, error = if (coba) eTopik else null, maxLength = 150)
        PilihField(
            label = "Kelas",
            items = kelas,
            terpilih = kelasPilih,
            nama = { it.nama },
            onPilih = { k ->
                if (k.id != kelasId) {
                    kelasId = k.id
                    mapelId = null
                }
            },
            enabled = item == null,
            error = if (coba) eKelas else null,
            kosong = "Belum ada kelas"
        )
        PilihField(
            label = "Mata Pelajaran",
            items = opsiMapel,
            terpilih = mapelPilih,
            nama = { it.nama },
            onPilih = { mapelId = it.id },
            error = if (coba) eMapel else null,
            kosong = if (kelasId == null) "Pilih kelas terlebih dahulu" else "Kelas ini belum memiliki mata pelajaran"
        )
        AppTextField("Catatan (opsional)", catatan, { catatan = it }, multiline = true, maxLength = 300)
        galat?.let { PesanGalat(it, Modifier.padding(start = 0.dp)) }
    }
}

// ------------------------------------------------------------------ Daftar nilai
@Composable
fun NilaiForm(vm: MainViewModel, item: NilaiView?, pop: () -> Unit) {
    val ctx = LocalContext.current
    val kelas by vm.kelas.collectAsState()
    val mapel by vm.mapel.collectAsState()
    var nama by remember { mutableStateOf(item?.nama ?: "") }
    var kelasId by remember { mutableStateOf<Long?>(item?.kelasId) }
    var mapelId by remember { mutableStateOf<Long?>(item?.mapelId) }
    var coba by remember { mutableStateOf(false) }
    var menyimpan by remember { mutableStateOf(false) }
    var galat by remember { mutableStateOf<String?>(null) }

    val kelasPilih = kelas.firstOrNull { it.id == kelasId }
    val opsiMapel = mapel.filter { m -> m.kelas.any { it.kelasId == kelasId } }
    val mapelPilih = mapel.firstOrNull { it.id == mapelId }
    val eNama = if (nama.isBlank()) "Nama wajib diisi" else null
    val eKelas = if (kelasId == null) "Kelas wajib dipilih" else null
    val eMapel = if (mapelId == null) "Mata pelajaran wajib dipilih" else null

    FormScaffold(
        title = if (item == null) "Tambah Daftar Nilai" else "Ubah Daftar Nilai",
        pop = pop,
        menyimpan = menyimpan,
        onSimpan = {
            coba = true
            galat = null
            val kid = kelasId
            val mid = mapelId
            if (eNama == null && kid != null && mid != null) {
                menyimpan = true
                vm.simpanNilai(item, nama, kid, mid) { err ->
                    menyimpan = false
                    if (err == null) {
                        ctx.toast("Daftar nilai disimpan")
                        pop()
                    } else {
                        galat = err
                    }
                }
            }
        }
    ) {
        AppTextField("Nama (mis. Tugas 1, UTS)", nama, { nama = it; galat = null }, error = if (coba) eNama else null, maxLength = 60)
        PilihField(
            label = "Kelas",
            items = kelas,
            terpilih = kelasPilih,
            nama = { it.nama },
            onPilih = { k ->
                if (k.id != kelasId) {
                    kelasId = k.id
                    mapelId = null
                }
            },
            enabled = item == null,
            error = if (coba) eKelas else null,
            kosong = "Belum ada kelas"
        )
        PilihField(
            label = "Mata Pelajaran",
            items = opsiMapel,
            terpilih = mapelPilih,
            nama = { it.nama },
            onPilih = { mapelId = it.id },
            error = if (coba) eMapel else null,
            kosong = if (kelasId == null) "Pilih kelas terlebih dahulu" else "Kelas ini belum memiliki mata pelajaran"
        )
        galat?.let { PesanGalat(it, Modifier.padding(start = 0.dp)) }
    }
}
