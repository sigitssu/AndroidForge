package id.guru.agenda.util

import id.guru.agenda.data.TahunAjaran
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

object Fmt {
    val locale: Locale = Locale.forLanguageTag("id-ID")

    fun tanggal(epochDay: Long, pola: String = "d MMMM yyyy"): String =
        LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern(pola, locale))

    fun jam(menit: Int): String = String.format(Locale.US, "%02d:%02d", menit / 60, menit % 60)

    fun rentang(mulai: Int, selesai: Int): String = jam(mulai) + " - " + jam(selesai)

    /** Angka desimal dengan titik, maksimal 2 digit, tanpa nol di belakang. */
    fun desimal(d: Double): String = DecimalFormat("0.##", DecimalFormatSymbols(Locale.US)).format(d)

    fun bulan(ym: YearMonth): String = ym.atDay(1).format(DateTimeFormatter.ofPattern("MMMM yyyy", locale))

    fun inisial(nama: String): String {
        val kata = nama.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return when {
            kata.isEmpty() -> "?"
            kata.size == 1 -> kata[0].take(2).uppercase()
            else -> (kata[0].take(1) + kata[1].take(1)).uppercase()
        }
    }

    fun aman(teks: String): String = teks.trim().replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
}

class Periode(val label: String, val dari: Long, val sampai: Long)

/** Pilihan periode laporan: seluruh semester, lalu tiap bulan dalam rentang tahun ajaran. */
fun daftarPeriode(t: TahunAjaran): List<Periode> {
    val hasil = mutableListOf(Periode("Seluruh Semester", t.awal, t.akhir))
    var ym = YearMonth.from(LocalDate.ofEpochDay(t.awal))
    val akhir = YearMonth.from(LocalDate.ofEpochDay(t.akhir))
    while (!ym.isAfter(akhir)) {
        val dari = maxOf(ym.atDay(1).toEpochDay(), t.awal)
        val sampai = minOf(ym.atEndOfMonth().toEpochDay(), t.akhir)
        hasil.add(Periode(Fmt.bulan(ym), dari, sampai))
        ym = ym.plusMonths(1)
    }
    return hasil
}
