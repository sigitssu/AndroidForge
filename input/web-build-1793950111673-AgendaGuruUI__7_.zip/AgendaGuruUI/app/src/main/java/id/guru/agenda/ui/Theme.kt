package id.guru.agenda.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat

// ------------------------------------------------------------------ pengaturan tema (tersimpan)
const val INDEKS_KUSTOM = 5
const val INDEKS_DEFAULT = 4
val WarnaPreset = listOf(
    Color(0xFFFF5A6E), Color(0xFFFFD54F), Color(0xFF66CC8A), Color(0xFF3B82F6), Color(0xFF6750A4)
)

class ThemePrefs(context: Context) {
    private val sp = context.getSharedPreferences("tema", Context.MODE_PRIVATE)

    /** 0 = Terang, 1 = Gelap, 2 = Sistem */
    var mode by mutableIntStateOf(sp.getInt("mode", 0))
        private set
    var warnaIndex by mutableIntStateOf(sp.getInt("warna", INDEKS_DEFAULT))
        private set
    var warnaKustom by mutableIntStateOf(sp.getInt("kustom", 0))
        private set

    fun aturMode(m: Int) {
        mode = m
        sp.edit().putInt("mode", m).apply()
    }

    fun aturWarna(i: Int) {
        warnaIndex = i
        sp.edit().putInt("warna", i).apply()
    }

    fun aturKustom(argb: Int) {
        warnaKustom = argb
        warnaIndex = INDEKS_KUSTOM
        sp.edit().putInt("kustom", argb).putInt("warna", INDEKS_KUSTOM).apply()
    }

    fun seed(): Color =
        if (warnaIndex == INDEKS_KUSTOM && warnaKustom != 0) Color(warnaKustom)
        else WarnaPreset[warnaIndex.coerceIn(0, WarnaPreset.size - 1)]
}

// ------------------------------------------------------------------ palet aplikasi
class AppColors(
    val dark: Boolean,
    val primary: Color,
    val onPrimary: Color,
    val primaryContainer: Color,
    val onPrimaryContainer: Color,
    val secondaryContainer: Color,
    val tertiary: Color,
    val error: Color,
    val alpa: Color,
    val background: Color,
    val surface: Color,
    val card: Color,
    val onSurface: Color,
    val surfaceVariant: Color,
    val text: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val divider: Color,
    val subtle: Color,
    val outline: Color,
    val bannerStart: Color,
    val bannerEnd: Color,
    val onBanner: Color
)

/** Palet asli desain (ungu Material 3) untuk mode terang. */
private val TerangAsli = AppColors(
    dark = false,
    primary = Color(0xFF6750A4), onPrimary = Color.White,
    primaryContainer = Color(0xFFEADDFF), onPrimaryContainer = Color(0xFF21005D),
    secondaryContainer = Color(0xFFE8DEF8), tertiary = Color(0xFF7D5260),
    error = Color(0xFFB3261E), alpa = Color(0xFF991B1B),
    background = Color(0xFFFDF8FD), surface = Color(0xFFFEF7FF), card = Color.White,
    onSurface = Color(0xFF1D1B20), surfaceVariant = Color(0xFFE7E0EC),
    text = Color(0xFF1F2937), textSecondary = Color(0xFF4B5563), textMuted = Color(0xFF6B7280),
    divider = Color(0xFFE5E7EB), subtle = Color(0xFFF3F4F6), outline = Color(0xFF79747E),
    bannerStart = Color(0xFF6750A4), bannerEnd = Color(0xFF6366F1), onBanner = Color.White
)

private fun hslDari(c: Color): FloatArray {
    val a = FloatArray(3)
    ColorUtils.colorToHSL(c.toArgb(), a)
    return a
}

fun buatWarna(seed: Color, gelap: Boolean): AppColors {
    val v = hslDari(seed)
    val h = v[0]
    val s = v[1].coerceIn(0.25f, 0.95f)
    val h2 = (h + 40f) % 360f
    val h3 = (h + 35f) % 360f
    if (!gelap) {
        if (seed.toArgb() == WarnaPreset[INDEKS_DEFAULT].toArgb()) return TerangAsli
        val putihCukup = ColorUtils.calculateContrast(Color.White.toArgb(), seed.toArgb()) >= 3.0
        return AppColors(
            dark = false,
            primary = seed, onPrimary = if (putihCukup) Color.White else Color(0xFF1D1B20),
            primaryContainer = Color.hsl(h, (s * 0.9f).coerceAtMost(0.9f), 0.90f),
            onPrimaryContainer = Color.hsl(h, s, 0.14f),
            secondaryContainer = Color.hsl(h, s * 0.35f, 0.91f),
            tertiary = Color.hsl(h2, 0.30f, 0.40f),
            error = Color(0xFFB3261E), alpa = Color(0xFF991B1B),
            background = Color.hsl(h, 0.30f, 0.985f), surface = Color.hsl(h, 0.30f, 0.975f), card = Color.White,
            onSurface = Color(0xFF1D1B20), surfaceVariant = Color.hsl(h, 0.20f, 0.90f),
            text = Color(0xFF1F2937), textSecondary = Color(0xFF4B5563), textMuted = Color(0xFF6B7280),
            divider = Color(0xFFE5E7EB), subtle = Color(0xFFF3F4F6), outline = Color(0xFF79747E),
            bannerStart = seed, bannerEnd = Color.hsl(h3, s, 0.55f),
            onBanner = if (putihCukup) Color.White else Color(0xFF1D1B20)
        )
    }
    val primer = Color.hsl(h, s.coerceIn(0.40f, 0.90f), 0.78f)
    return AppColors(
        dark = true,
        primary = primer, onPrimary = Color.hsl(h, s, 0.15f),
        primaryContainer = Color.hsl(h, s * 0.6f, 0.28f),
        onPrimaryContainer = Color.hsl(h, s * 0.9f, 0.90f),
        secondaryContainer = Color.hsl(h, s * 0.25f, 0.28f),
        tertiary = Color.hsl(h2, 0.45f, 0.75f),
        error = Color(0xFFF2B8B5), alpa = Color(0xFFFF8A80),
        background = Color.hsl(h, 0.10f, 0.09f), surface = Color.hsl(h, 0.10f, 0.12f), card = Color.hsl(h, 0.10f, 0.15f),
        onSurface = Color.hsl(h, 0.08f, 0.90f), surfaceVariant = Color.hsl(h, 0.12f, 0.25f),
        text = Color(0xFFEDEDF0), textSecondary = Color(0xFFC9CAD0), textMuted = Color(0xFFA0A3AB),
        divider = Color.hsl(h, 0.10f, 0.25f), subtle = Color.hsl(h, 0.10f, 0.20f), outline = Color(0xFF938F99),
        bannerStart = Color.hsl(h, s * 0.6f, 0.28f), bannerEnd = Color.hsl(h3, s * 0.8f, 0.38f),
        onBanner = Color.hsl(h, s * 0.9f, 0.92f)
    )
}

private fun AppColors.skema(): ColorScheme =
    if (dark) {
        darkColorScheme(
            primary = primary, onPrimary = onPrimary, primaryContainer = primaryContainer, onPrimaryContainer = onPrimaryContainer,
            secondary = primary, onSecondary = onPrimary, secondaryContainer = secondaryContainer, onSecondaryContainer = onSurface,
            tertiary = tertiary, error = error, background = background, onBackground = onSurface,
            surface = surface, onSurface = onSurface, surfaceVariant = surfaceVariant, onSurfaceVariant = textSecondary,
            outline = outline, outlineVariant = divider, surfaceTint = primary,
            surfaceContainerLowest = background, surfaceContainerLow = card, surfaceContainer = card,
            surfaceContainerHigh = card, surfaceContainerHighest = surfaceVariant
        )
    } else {
        lightColorScheme(
            primary = primary, onPrimary = onPrimary, primaryContainer = primaryContainer, onPrimaryContainer = onPrimaryContainer,
            secondary = primary, onSecondary = onPrimary, secondaryContainer = secondaryContainer, onSecondaryContainer = onSurface,
            tertiary = tertiary, error = error, background = background, onBackground = onSurface,
            surface = surface, onSurface = onSurface, surfaceVariant = surfaceVariant, onSurfaceVariant = textSecondary,
            outline = outline, outlineVariant = divider, surfaceTint = primary,
            surfaceContainerLowest = background, surfaceContainerLow = card, surfaceContainer = card,
            surfaceContainerHigh = card, surfaceContainerHighest = surfaceVariant
        )
    }

val LocalAppColors = staticCompositionLocalOf { TerangAsli }

// Nama-nama warna yang dipakai di seluruh tampilan (mengikuti tema yang dipilih)
val MdPrimary: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.primary
val OnPrimary: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.onPrimary
val MdPrimaryContainer: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.primaryContainer
val MdOnPrimaryContainer: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.onPrimaryContainer
val MdSecondaryContainer: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.secondaryContainer
val MdTertiary: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.tertiary
val MdError: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.error
val AlpaRed: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.alpa
val AppBg: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.background
val MdSurface: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.surface
val CardBg: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.card
val MdOnSurface: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.onSurface
val MdSurfaceVariant: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.surfaceVariant
val Gray800: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.text
val Gray600: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.textSecondary
val Gray500: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.textMuted
val Gray200: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.divider
val Gray100: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.subtle
val BannerStart: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.bannerStart
val BannerEnd: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.bannerEnd
val OnBanner: Color @androidx.compose.runtime.Composable get() = LocalAppColors.current.onBanner

private fun Context.aktivitas(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun AgendaGuruTheme(tema: ThemePrefs, content: @Composable () -> Unit) {
    val sistemGelap = isSystemInDarkTheme()
    val gelap = when (tema.mode) {
        0 -> false
        1 -> true
        else -> sistemGelap
    }
    val seed = tema.seed()
    val warna = remember(seed, gelap) { buatWarna(seed, gelap) }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.aktivitas()?.window
            if (window != null) {
                window.statusBarColor = warna.primaryContainer.toArgb()
                window.navigationBarColor = warna.surface.toArgb()
                val pengendali = WindowCompat.getInsetsController(window, view)
                pengendali.isAppearanceLightStatusBars = !gelap
                pengendali.isAppearanceLightNavigationBars = !gelap
            }
        }
    }
    CompositionLocalProvider(LocalAppColors provides warna) {
        MaterialTheme(colorScheme = warna.skema(), content = content)
    }
}
