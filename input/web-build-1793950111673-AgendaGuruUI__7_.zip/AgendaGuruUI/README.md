# Agenda Guru
Aplikasi Android (Kotlin, Jetpack Compose, Material 3, Room) untuk agenda mengajar, presensi, dan penilaian guru.

Build: buka folder ini di Android Studio (Koala 2024.1+, JDK 17), tunggu Gradle sync, lalu Run / Build > Build APK(s).

Rancangan database: lihat DATABASE.md.
Format Excel impor siswa: kolom A = NIS, B = Nama Siswa, C = Jenis Kelamin (L/P atau Laki-laki/Perempuan), baris judul opsional.
Laporan agenda -> PDF, laporan penilaian -> Excel (.xlsx); keduanya langsung disimpan ke folder Download.
